/*
 * config.h - SLS email application configuration file
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 * All rights reserved. Property of Texas Instruments Incorporated.
 * Restricted rights to use, duplicate or disclose this code are
 * granted through contract.
 *
 * The program may not be used without the written permission of
 * Texas Instruments Incorporated or against the terms and conditions
 * stipulated in the agreement under which this program has been supplied,
 * and under no circumstances can it be used with non-TI connectivity device.
 *
 */

#ifndef DEMO_CONFIG_H
#define DEMO_CONFIG_H

#ifdef __cplusplus
extern "C"{
#endif /* __cplusplus */

/* Modify the following settings as necessary to run the email application */
#define SMTP_BUF_LEN            100
#define GMAIL_HOST_NAME         "smtp.gmail.com"
#define GMAIL_HOST_PORT         465
#define YAHOO_HOST_NAME         "smtp.mail.yahoo.com"
#define YAHOO_HOST_PORT         25

#define USER                    "cc3100.apps@gmail.com"
#define PASS                    "cc3100demo"

#define SSID_NAME               "<ap-name>"         /* Access point name to connect to */
#define SEC_TYPE                SL_SEC_TYPE_OPEN    /* Security type of the Access point */
#define PASSKEY                 ""                  /* Password in case of secure AP */
#define PASSKEY_LEN             strlen(PASSKEY)     /* Password length in case of secure AP */

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* DEMO_CONFIG_H */
