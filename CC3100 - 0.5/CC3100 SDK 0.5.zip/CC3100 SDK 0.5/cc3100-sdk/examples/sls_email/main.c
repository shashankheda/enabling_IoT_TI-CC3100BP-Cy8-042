/*
 * main.c - sample application to send email
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 * All rights reserved. Property of Texas Instruments Incorporated.
 * Restricted rights to use, duplicate or disclose this code are
 * granted through contract.
 *
 * The program may not be used without the written permission of
 * Texas Instruments Incorporated or against the terms and conditions
 * stipulated in the agreement under which this program has been supplied,
 * and under no circumstances can it be used with non-TI connectivity device.
 *
 */

#include <windows.h>
#include <stdio.h>
#include <string.h>
#include "email.h"
#include "config.h"

#define UART_COMMAND_CC31xx_SIMPLE_CONFIG_START (0x31)
#define UART_COMMAND_CC31xx_EMAIL_HEADER        (0x33)
#define UART_COMMAND_CC31xx_EMAIL_MESSAGE       (0x34)
#define UART_COMMAND_CC31xx_EMAIL_SEND          (0x35)

#define INPUT_BUF_SIZE          65
#define BAUD_RATE               115200

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02

}e_Status;
UINT8 g_Status = 0;

#ifdef SL_IF_TYPE_UART
#define COMM_PORT_NUM 10
SlUartIfParams_t params;
#endif /* SL_IF_TYPE_UART */

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
            g_Status |= CONNECTED;
        break;

        case SL_WLAN_DISCONNECT_EVENT:
            g_Status &= ~(1 << CONNECTION_STATUS_BIT | 1 << IP_AQUIRED_STATUS_BIT);
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_AQUIRED;
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    The function will return only once we are connected and have acquired IP
    address

    \param[in]      None

    \return         none

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, we will be stuck in this function forever.
*/
static void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = PASSKEY;
    secParams.KeyLen = PASSKEY_LEN;
    secParams.Type = SEC_TYPE;

    sl_WlanConnect(SSID_NAME, strlen(SSID_NAME), 0, &secParams, 0);

    while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
        ;
}

/*!
    \brief This function displays the menu over the application uart terminal

    \param[in]      none

    \return         None

    \note

    \warning
*/
void OutputMenu(void)
{
    printf("\n\r*****************************\n\r");
    printf("CC31xx Email App Version\n");
    printf("\n\r*****************************\n\r");

    /* Display Menu Options for Application */
    printf("\n\rCOMMAND MENU\n\r");
    printf("\n\r============================\n\r");
    printf("01 to connect\n\r");
    printf("03,<to>,<subject>\n\r");
    printf("04,<message>\n\r");
    printf("05 to send message\n\r\n\r");
}

/*!
    \brief This function Process the commands received over application uart

    \param[in]      usBuffer - pointer to the command

    \return         none

    \note

    \warning
*/
void UARTCommandHandler(unsigned char *usBuffer)
{
    INT32 index = -1;
    INT32 status1 = -1;
    INT32 status2 = -1;
    INT8  connectStatus = -1;

    UINT32 paramcount = 0;

    switch(usBuffer[1])
    {
        /* Case 01: Start a smart configuration process    */
        case UART_COMMAND_CC31xx_SIMPLE_CONFIG_START:
            WlanConnect();
            printf("\rOK\n\r");
        break;

        /* Case 03: Configure sender (source) email */
        case UART_COMMAND_CC31xx_EMAIL_HEADER:
        {
            SlNetAppDestination_t destEmailAdd;
            SlNetAppEmailSubject_t emailSubject;
            unsigned char *pcOfemailto, *pcOfemailsubject;

            memset(destEmailAdd.Email, '\0', MAX_DEST_EMAIL_LEN);
            memset(emailSubject.Value, '\0', MAX_SUBJECT_LEN);

            pcOfemailto = (unsigned char *)(destEmailAdd.Email);
            pcOfemailsubject = (unsigned char *)(emailSubject.Value);
            /* '<' To maintain RFC 2821 format */
            *pcOfemailto++= '<';
            index = 2;
            while ((int)usBuffer[index] != 0x0D  && usBuffer[index] != '\0')
            {
                /* look for comma ',' for separation of params */
                if((int)usBuffer[index] == 44)
                {
                    paramcount++;
                }
                else
                {
                    if(paramcount==1)
                    {
                        /* Enter destination email address */
                        *pcOfemailto++ = usBuffer[index];
                    }

                    if(paramcount==2)
                    {
                        /* Enter email subject */
                        *pcOfemailsubject++ = usBuffer[index];
                    }
                }
                index++;
            }
            /* '>' To maintain RFC 2821 format */
            *pcOfemailto++= '>';
            *pcOfemailto++= '\0';
            *pcOfemailsubject= '\0';

            status1 = sl_NetAppEmailSet(NETAPP_DEST_EMAIL,
            strlen((const char *)destEmailAdd.Email), destEmailAdd.Email);

            status2 = sl_NetAppEmailSet(NETAPP_SUBJECT,
            strlen((const char *)emailSubject.Value), emailSubject.Value);

            /* Check for Error in setting the variables */
            if(status1 == 0 && status2 == 0)
            {
                printf("\rOK\n\r");
            }
            else
            {
                printf("\rError in input\n\r");
            }
        }
        break;

        /* Case 04: Record email message */
        case UART_COMMAND_CC31xx_EMAIL_MESSAGE:
        {
            UINT8 *pcOfemailmessage;
            pcOfemailmessage = (usBuffer + 3);
            /* Enter "Message" */
            index =0;
            if((int)(*pcOfemailmessage) == 60)
                pcOfemailmessage++;

            while ((int)(*pcOfemailmessage) != 0x0D && (*pcOfemailmessage) != '\0')
            {
                if((int)(*pcOfemailmessage) == 62)
                {
                    break;
                }
                index++;
                pcOfemailmessage++;
            }

            if(sl_NetAppEmailSet(NETAPP_MESSAGE,index,(usBuffer + 3)) < 0)
            {
                printf("\n\rError:Message Length Exceeded\n\r");
            }
            else
            {
                printf("\rOK\n\r");
            }
        }
        break;

        /* Case 05: Send email message using configurations    */
        case UART_COMMAND_CC31xx_EMAIL_SEND:
        {
            connectStatus = sl_NetAppEmailConnect();
            /* If return -1, throw connect error */
            if(connectStatus == -1)
            {
                printf("\n\rError in socket create\n\r");
            }
            /* If return -2, throw socket option error */
            if(connectStatus == -2)
            {
                printf("\n\rError in socket option\n\r");
            }

            if(connectStatus == 0)
            {
                if(sl_NetAppEmailSend() == 0)
                {
                    printf("\n\rMessage Sent\n\r");
                    break;
                }
            }
        }
        break;

        default:
        printf("\n\rERROR\n\r");
        break;
    }

}

/*!
    \brief This function configures the source email using parameters defined
           in "config.h" file

    \param[in]      none

    \return         none

    \note

    \warning
*/
static void SetEmail()
{
    SlNetAppSourceEmail_t sourceEmailId;
    SlNetAppSourcePassword_t sourceEmailPwd;
    SlNetAppEmailOpt_t eMailServerSetting;

    memcpy(sourceEmailId.Username,USER,strlen(USER)+1);
    sl_NetAppEmailSet(NETAPP_SOURCE_EMAIL,strlen(USER)+1,
                                            (unsigned char*)&sourceEmailId);

    memcpy(sourceEmailPwd.Password,PASS,strlen(PASS)+1);
    sl_NetAppEmailSet(NETAPP_PASSWORD,strlen(PASS)+1,
                                            (unsigned char*)&sourceEmailPwd);

    eMailServerSetting.Family = SL_AF_INET;
    eMailServerSetting.Port = GMAIL_HOST_PORT;
    eMailServerSetting.Ip = SL_IPV4_VAL(74,125,129,108);
    eMailServerSetting.SecurityMethod = SL_SO_SEC_METHOD_SSLV3;
    eMailServerSetting.SecurityCypher = SL_SEC_MASK_SSL_RSA_WITH_RC4_128_MD5;

    sl_NetAppEmailSet(NETAPP_ADVANCED_OPT,sizeof(SlNetAppEmailOpt_t),
                                        (unsigned char*)&eMailServerSetting);
}

/*!
    \brief Send the email to the preconfigured email ID

    \param[in]      none

    \return         0 for success , -1 otherwise

    \note

    \warning
*/
void ReadAndProcessInput()
{
    /* Main loop. Waits for commands from PC. */
    UINT8 inputBuff[INPUT_BUF_SIZE] = {'\0'};

    while(1)
    {
        memset(inputBuff, 0x00, sizeof(inputBuff));

        scanf_s("%[^\n]%*c", inputBuff, _countof(inputBuff));
        UARTCommandHandler(inputBuff);

        if(!strncmp((const char*)inputBuff, "05", 2))
            break;
    }
}

int main(void)
{
    INT8 *pConfig = NULL;
#ifdef SL_IF_TYPE_UART
    params.BaudRate = BAUD_RATE;
    params.FlowControlEnable = 1;
    params.CommPort = COMM_PORT_NUM;

    pConfig = (char *)&params;
#endif /* SL_IF_TYPE_UART */

    /*This line is for Eclipse CDT only due to a known bug in console buffering
    * See https://bugs.eclipse.org/bugs/show_bug.cgi?id=173732 */
    setvbuf(stdout, NULL, _IONBF, 0);

    /* Initializing the CC3100 device */
    sl_Start(0,pConfig,0);

    /* configure the Source email */
    SetEmail();

    /* Generate Output Menu for Application */
    OutputMenu();

    /* Read the command over Application UART and proces it */
    ReadAndProcessInput();

    printf("\n\rThank you!\n\r");

    system("PAUSE");

    return 0;
}
