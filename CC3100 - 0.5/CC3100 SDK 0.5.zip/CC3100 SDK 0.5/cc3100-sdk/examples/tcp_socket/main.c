/*
 * main.c - TCP socket sample application
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/



#include "simplelink.h"

#define SSID_NAME       "<ap-name>"     /* Open AP name to connect to */

/* IP addressed of server side socket. Should be in long format,
 * E.g: 0xc0a8010a == 192.168.1.10 */
#define IP_ADDR         0xc0a80164
#define PORT_NUM        5001            /* Port number to be used */

#define BUF_SIZE 1400
#define NO_OF_PACKETS 1000

union
{
    UINT8 BsdBuf[BUF_SIZE];
    UINT32 demobuf[BUF_SIZE/4];
} uBuf;

enum
{
    CONNECTED = 0x1,
    IP_ACQUIRED = 0x2
}e_Stauts;

UINT8 g_Status = 0;


/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
      case SL_WLAN_CONNECT_EVENT:
          g_Status |= CONNECTED;
        break;
      case SL_WLAN_DISCONNECT_EVENT:
          g_Status &= ~(CONNECTED + IP_ACQUIRED);
        break;
      default:
        break;
    }
}


/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
      case SL_NETAPP_IPV4_ACQUIRED:
          g_Status |= IP_ACQUIRED;
        break;
      default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this application */
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    This code example assumes the AP doesn't use WIFI security.
    The function will return only once we are connected and have acquired IP
    address

    \param[in]      None

    \return         None

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
static void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = "";
    secParams.KeyLen = 0;
    secParams.Type = SL_SEC_TYPE_OPEN;

    sl_WlanConnect(SSID_NAME, strlen(SSID_NAME), 0,&secParams,0);

    while (!(g_Status & IP_ACQUIRED ) || !(g_Status & CONNECTED))
    {
        _SlNonOsMainLoopTask();
    }
}


/*!
    \brief Opening a client side socket and sending data

    This function opens a TCP socket and tries to connect to a Server IP_ADDR
    waiting on port PORT_NUM. If the socket connection is successful then the
    function will send 1000 TCP packets to the server.

    \param[in]      port number on which the server will be listening on

    \return         0 on success, -1 on Error.

    \note

    \warning        A server must be waiting with an open TCP socket on the
                    right port number before calling this function.
                    Otherwise the socket creation will fail.
*/
static INT16 BsdTcpClient(UINT16 Port)
{
    SlSockAddrIn_t  Addr;

    UINT16          idx = 0;
    UINT16          AddrSize = 0;
    INT16           SockID = 0;
    INT16           Status = 0;
    UINT16          LoopCount = 0;

    for (idx=0 ; idx<BUF_SIZE ; idx++)
    {
        uBuf.BsdBuf[idx] = (char)(idx % 10);
    }

    Addr.sin_family = SL_AF_INET;
    Addr.sin_port = sl_Htons((UINT16)Port);
    Addr.sin_addr.s_addr = sl_Htonl((UINT32)IP_ADDR);
    AddrSize = sizeof(SlSockAddrIn_t);

    SockID = sl_Socket(SL_AF_INET,SL_SOCK_STREAM, 0);
    if( SockID < 0 )
    {
        /* error */
        return -1;
    }

    Status = sl_Connect(SockID, ( SlSockAddr_t *)&Addr, AddrSize);
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    while (LoopCount < NO_OF_PACKETS)
    {
        Status = sl_Send(SockID, uBuf.BsdBuf, BUF_SIZE, 0 );
        if( Status <= 0 )
        {
            sl_Close(SockID);
            return -1;
        }
        LoopCount++;
    }

    sl_Close(SockID);

    return 0;
}

/*!
    \brief Opening a server side socket and receiving data

    This function opens a TCP socket in Listen mode and waits for an incoming
    TCP connection. If a socket connection is established then the function
    will try to read 1000 TCP packets from the connected client.

    \param[in]      port number on which the server will be listening on

    \return         0 on success, -1 on Error.

    \note           This function will wait for an incoming connection till one
                    is established

    \warning
*/
static INT16 BsdTcpServer(UINT16 Port)
{
    SlSockAddrIn_t  Addr;
    SlSockAddrIn_t  LocalAddr;

    UINT16          idx = 0;
    UINT16          AddrSize = 0;
    INT16           SockID = 0;
    INT16           Status = 0;
    INT16           newSockID = 0;
    UINT16          LoopCount = 0;
    INT32           nonBlocking = 1;

    for (idx=0 ; idx<BUF_SIZE ; idx++)
    {
        uBuf.BsdBuf[idx] = (char)(idx % 10);
    }

    LocalAddr.sin_family = SL_AF_INET;
    LocalAddr.sin_port = sl_Htons((UINT16)Port);
    LocalAddr.sin_addr.s_addr = 0;

    SockID = sl_Socket(SL_AF_INET,SL_SOCK_STREAM, 0);
    if( SockID < 0 )
    {
        /* error */
        return -1;
    }

    AddrSize = sizeof(SlSockAddrIn_t);
    Status = sl_Bind(SockID, (SlSockAddr_t *)&LocalAddr, AddrSize);
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    Status = sl_Listen(SockID, 0);
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    Status = sl_SetSockOpt(SockID, SL_SOL_SOCKET, SL_SO_NONBLOCKING,
                           &nonBlocking, sizeof(nonBlocking));
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    newSockID = SL_EAGAIN;
    while( newSockID < 0 )
    {
        newSockID = sl_Accept(SockID, ( struct SlSockAddr_t *)&Addr,
                              (SlSocklen_t*)&AddrSize);
        if( newSockID == SL_EAGAIN )
        {
            /* Wait for 1 ms */
            Delay(1);
        }
        else if( newSockID < 0 )
        {
            sl_Close(SockID);
            return -1;
        }
    }

    while (LoopCount < NO_OF_PACKETS)
    {
        Status = sl_Recv(newSockID, uBuf.BsdBuf, BUF_SIZE, 0);
        if( Status <= 0 )
        {
            sl_Close(newSockID);
            sl_Close(SockID);
            return -1;
        }

        LoopCount++;
    }

    sl_Close(newSockID);
    sl_Close(SockID);

    return 0;
}


int main(void)
{
    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* Connecting to WLAN AP - Set with static parameters defined at the top */
    /* After this call we will be connected and have IP address */
    WlanConnect();

    /*Before proceeding, please make sure to have a server waiting on PORT_NUM*/
    BsdTcpClient(PORT_NUM);

    /*After calling this function, you can start sending data to CC3100 IP
    * address on PORT_NUM */
    BsdTcpServer(PORT_NUM);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
