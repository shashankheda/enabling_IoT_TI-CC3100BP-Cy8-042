For information on this example refer to:
docs\examples\tcp_socket.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_TCP_Socket_Application