For information on this example refer to:
docs\examples\sls_xmpp_client.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_SLS_Reference_Application