/*
 * main.c - sample messaging application via xmpp server
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 * All rights reserved. Property of Texas Instruments Incorporated.
 * Restricted rights to use, duplicate or disclose this code are
 * granted through contract.
 *
 * The program may not be used without the written permission of
 * Texas Instruments Incorporated or against the terms and conditions
 * stipulated in the agreement under which this program has been supplied,
 * and under no circumstances can it be used with non-TI connectivity device.
 *
 */

#include <windows.h>
#include <stdio.h>
#include "simplelink.h"

#include "xmpp.h"

#define SSID_NAME   "<ap-name>"        /* Open AP name to connect to */

#define XMPP_USER       "slcc3100"
#define XMPP_PWD        "3100slcc"
#define XMPP_DOMAIN     "gmail.com"
#define XMPP_RESOURCE   "work"

/* IP addressed of XMPP server. Should be in long format,
 * E.g: 0xadc2467d == 173.194.70.125 */
#define XMPP_IP_ADDR    0xadc2467d
#define XMPP_DST_PORT   5223

#define MAX_RCV_BUF_SIZE 50

#ifdef SL_IF_TYPE_UART
#define COMM_PORT_NUM 10
SlUartIfParams_t params;
#endif

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02

}e_Status;

UINT8 g_Status = 0;
UINT8 g_BSSID[SL_BSSID_LENGTH];

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
          g_Status |= CONNECTED;
        break;

        case SL_WLAN_DISCONNECT_EVENT:
          g_Status &= ~(1 << CONNECTION_STATUS_BIT | 1 << IP_AQUIRED_STATUS_BIT);
        break;

          default:
        break;
    }
}


/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_AQUIRED;
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    This code example assumes the AP doesn't use WIFI security.
    The function will return only once we are connected and have acquired IP
    address

    \param[in]      None

    \return         None

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = "";
    secParams.KeyLen = 0;
    secParams.Type = SL_SEC_TYPE_OPEN;

    sl_WlanConnect(SSID_NAME, strlen(SSID_NAME), 0, &secParams, 0);

    while((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)));
}


int main(void)
{
    SlNetAppXmppOpt_t XmppOption;
    SlNetAppXmppUserName_t UserName;
    SlNetAppXmppPassword_t Password;
    SlNetAppXmppDomain_t Domain;
    SlNetAppXmppResource_t Resource;
    UINT8 pRemoteJid[MAX_RCV_BUF_SIZE] = {'\0'};
    UINT8 pRecvMessage[MAX_RCV_BUF_SIZE] = {'\0'};
    INT32 Status = 0;

    INT8 *pConfig = 0;

#ifdef SL_IF_TYPE_UART
    params.BaudRate = 115200;
    params.FlowControlEnable = 1;
    params.CommPort = COMM_PORT_NUM;

    pConfig = (char *)&params;
#endif /**SL_IF_TYPE_UART /

    /*This line is for Eclipse CDT only due to a known bug in console buffering
    * See https://bugs.eclipse.org/bugs/show_bug.cgi?id=173732 */
    setvbuf(stdout, NULL, _IONBF, 0);

    /* Initialzing the CC3100 device */
    sl_Start(0, pConfig, 0);

    /* Connecting to WLAN AP - Set with static parameters defined at the top
       After this call we will be connected and have IP address */
    WlanConnect();

    /* Configuring parameters required for XMPP connection*/
    XmppOption.Port = XMPP_DST_PORT;
    XmppOption.Family = SL_AF_INET;
    XmppOption.SecurityMethod = SO_SECMETHOD_SSLV3;
    XmppOption.SecurityCypher = SECURE_MASK_SSL_RSA_WITH_RC4_128_SHA;
    XmppOption.Ip = XMPP_IP_ADDR;
    sl_NetAppXmppSet(SL_NET_APP_XMPP_ID, NETAPP_XMPP_ADVANCED_OPT,
                     sizeof(SlNetAppXmppOpt_t), (unsigned char *)&XmppOption);

    memcpy(UserName.UserName, XMPP_USER, strlen(XMPP_USER));
    UserName.Length = strlen(XMPP_USER);
    sl_NetAppXmppSet(SL_NET_APP_XMPP_ID, NETAPP_XMPP_USER_NAME,
                     UserName.Length, (unsigned char *)&UserName);

    memcpy(Password.Password, XMPP_PWD, strlen(XMPP_PWD));
    Password.Length = strlen(XMPP_PWD);
    sl_NetAppXmppSet(SL_NET_APP_XMPP_ID, NETAPP_XMPP_PASSWORD,
                     Password.Length, (unsigned char *)&Password);

    memcpy(Domain.DomainName, XMPP_DOMAIN, strlen(XMPP_DOMAIN));
    Domain.Length = strlen(XMPP_DOMAIN);
    sl_NetAppXmppSet(SL_NET_APP_XMPP_ID, NETAPP_XMPP_DOMAIN,
                     Domain.Length, (unsigned char *)&Domain);

    memcpy(Resource.Resource,XMPP_RESOURCE, strlen(XMPP_RESOURCE));
    Resource.Length = strlen(XMPP_RESOURCE);
    sl_NetAppXmppSet(SL_NET_APP_XMPP_ID, NETAPP_XMPP_RESOURCE,
                     Resource.Length, (unsigned char *)&Resource);

    sl_NetAppXmppConnect();
    Status = sl_NetAppXmppRecv(pRemoteJid, MAX_RCV_BUF_SIZE, pRecvMessage, MAX_RCV_BUF_SIZE );
    while ( Status < 0)
    {
        Status = sl_NetAppXmppRecv(pRemoteJid, MAX_RCV_BUF_SIZE, pRecvMessage, MAX_RCV_BUF_SIZE );
    }

    /* Send back the received message */
    Status = sl_NetAppXmppSend(pRemoteJid, strlen((const char *)pRemoteJid),
                               pRecvMessage, strlen((const char *)pRecvMessage));

    while(1);
}
