For information on this example refer to:
docs\examples\xmpp_client.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_XMPP_Reference_Application