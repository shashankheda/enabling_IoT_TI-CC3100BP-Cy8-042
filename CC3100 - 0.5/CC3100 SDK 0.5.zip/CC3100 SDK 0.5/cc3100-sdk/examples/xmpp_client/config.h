/*
 * config.h - xmpp application configuration file
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 * All rights reserved. Property of Texas Instruments Incorporated.
 * Restricted rights to use, duplicate or disclose this code are
 * granted through contract.
 *
 * The program may not be used without the written permission of
 * Texas Instruments Incorporated or against the terms and conditions
 * stipulated in the agreement under which this program has been supplied,
 * and under no circumstances can it be used with non-TI connectivity device.
 *
 */

#ifndef DEMO_CONFIG_H
#define DEMO_CONFIG_H

#ifdef __cplusplus
extern "C"{
#endif /* __cplusplus */

/* Modify the following settings as necessary to run the xmpp application */
#define SSID_NAME   "<ap-name>"        /* Open AP name to connect to */

#define XMPP_USER       "slcc3100"
#define XMPP_PWD        "3100slcc"
#define XMPP_DOMAIN     "gmail.com"
#define XMPP_RESOURCE   "work"

/* IP addressed of XMPP server. Should be in long format,
 * E.g: 0xadc2467d == 173.194.70.125 */
#define XMPP_IP_ADDR    0xadc2467d
#define XMPP_DST_PORT   5223

#define MAX_RCV_BUF_SIZE 250+1

#ifdef __cplusplus
}
#endif /* __cplusplus */
#endif /* DEMO_CONFIG_H */
