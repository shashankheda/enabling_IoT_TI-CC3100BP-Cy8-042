/*
 * xmpp.c - function implementation to communicate with xmpp server
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 * All rights reserved. Property of Texas Instruments Incorporated.
 * Restricted rights to use, duplicate or disclose this code are
 * granted through contract.
 *
 * The program may not be used without the written permission of
 * Texas Instruments Incorporated or against the terms and conditions
 * stipulated in the agreement under which this program has been supplied,
 * and under no circumstances can it be used with non-TI connectivity device.
 *
 */

#include "xmpp.h"
#include "base64.h"


#define SO_SECMETHOD    25  /* security method */
#define SO_SECURE_MASK  26  /* security mask 0 and mask 1 */
#define SL_SECURITY_ANY     (100)

#define PRESENCE_MESSAGE "<presence><priority>4</priority><status>Online</status><c xmlns='http://jabber.org/protocol/caps' node='http://jajc.jrudevels.org/caps' ver='0.0.8.125 (04.01.2012)'/></presence>"
#define JABBER_XMLNS_INFO "version='1.0' xmlns:stream='http://etherx.jabber.org/streams' xmlns='jabber:client'>"

#define XMPP_STATUS_SOCKET     (1 << 0)
#define XMPP_STATUS_USERNAME   (1 << 1)
#define XMPP_STATUS_PASSWORD   (1 << 2)
#define XMPP_STATUS_DOMAIN     (1 << 3)
#define XMPP_STATUS_RESOURCE   (1 << 4)

typedef enum
{
    XMPP_INACTIVE = 0,
    XMPP_INIT,
    FIRST_STREAM_SENT,
    FIRST_STREAM_RECV,
    STARTTLS_RESPONSE_RECV,
    AUTH_QUERY_SET,
    AUTH_RESULT_RECV,
    BIND_FEATURE_REQUEST,
    BIND_FEATURE_RESPONSE,
    BIND_CONFIG_SET,
    BIND_CONFIG_RECV,
    XMPP_SESSION_SET,
    XMPP_SESSION_RECV,
    PRESENCE_SET,
    CONNECTION_ESTABLISHED,
    ROSTER_REQUEST,
    ROSTER_RESPONSE
}_SlXMPPStatus_e;

#define MAX_BUFF_SIZE 1024
#define BUF_SIZE 128

unsigned int g_XMPPStatus = XMPP_INIT;

union
{
    char Buf[2*MAX_BUFF_SIZE];
    UINT32 demobuf[MAX_BUFF_SIZE/2];
} g_RecvBuf;

union
{
    char Buf[MAX_BUFF_SIZE/2];
    UINT32 demobuf[MAX_BUFF_SIZE/8];
} g_SendBuf;

union
{
    char Buf[BUF_SIZE];
    UINT32 demobuf[BUF_SIZE/4];
} g_MyBaseKey;

union
{
    char Buf[BUF_SIZE];
    UINT32 demobuf[BUF_SIZE/4];
} MyJid;

union
{
    char Buf[BUF_SIZE];
    UINT32 demobuf[BUF_SIZE/4];
} RemoteJid;

union
{
    char Buf[BUF_SIZE];
    UINT32 demobuf[BUF_SIZE/4];
} g_RosterJid;

union
{
    SlNetAppXmppOpt_t Buf;
    UINT32 demobuf[9];
} g_XmppOpt;

union
{
    SlNetAppXmppUserName_t Buf;
    UINT32 demobuf[9];
} g_XmppUserName;

union
{
    SlNetAppXmppPassword_t Buf;
    UINT32 demobuf[9];
} g_XmppPassword;

union
{
    SlNetAppXmppDomain_t Buf;
    UINT32 demobuf[9];
} g_XmppDomain;

union
{
    SlNetAppXmppResource_t Buf;
    UINT32 demobuf[9];
} g_XmppResource;

short           g_SockID;
unsigned int    g_XmppSetStatus = 0;

/* Static fucntiion declarations */
static void SlXmppConnectionSM(void);
static int SlValidateServerInfo(void);
static int SlValidateQueryResult(void);
static int SlValidateBindFeature(void);
static int SlBindingConfigure(void);
static int SlValidateRoster(void);
static int SlXMPPSessionConfig(void);

/*!
    \brief     A function for setting XMPP configurations

    \return    On success, zero is returned. On error, -1 is
               returned

    \param[in] AppId -  application id, should be SL_NET_APP_XMPP_ID

    \param[in] SetOptions - set option, could be one of the following: \n
                            NETAPP_XMPP_ADVANCED_OPT,\n
                            NETAPP_XMPP_USER_NAME,\n
                            NETAPP_XMPP_PASSWORD,\n
                            NETAPP_XMPP_DOMAIN,\n
                            NETAPP_XMPP_RESOURCE,\n
                            NETAPP_XMPP_ROSTER\n

    \param[in] OptionLen - option structure length

    \param[in] pOptionValues -   pointer to the option structure

    \sa

    \note

    \warning
*/
long sl_NetAppXmppSet(unsigned char AppId ,unsigned char Option,
                       unsigned char OptionLen, unsigned char *pOptionValue)
{
    SlNetAppXmppOpt_t* pXmppOpt = 0;
    SlNetAppXmppUserName_t* pXmppUserName = 0;
    SlNetAppXmppPassword_t* pXmppPassword = 0;
    SlNetAppXmppDomain_t* pXmppDomain = 0;
    SlNetAppXmppResource_t* pXmppResource = 0;

    if (AppId != SL_NET_APP_XMPP_ID)
    {
        return -1;
    }

    switch (Option)
    {
      case NETAPP_XMPP_ADVANCED_OPT:
        pXmppOpt = (SlNetAppXmppOpt_t*)pOptionValue;

        g_XmppOpt.Buf.Port = pXmppOpt->Port;
        g_XmppOpt.Buf.Family = pXmppOpt->Family;
        g_XmppOpt.Buf.SecurityMethod = pXmppOpt->SecurityMethod;
        g_XmppOpt.Buf.SecurityCypher = pXmppOpt->SecurityCypher;
        g_XmppOpt.Buf.Ip = pXmppOpt->Ip;

        g_XmppSetStatus+=XMPP_STATUS_SOCKET;
        break;

      case NETAPP_XMPP_USER_NAME:
        pXmppUserName = (SlNetAppXmppUserName_t*)pOptionValue;

        memcpy(g_XmppUserName.Buf.UserName, pXmppUserName->UserName, OptionLen);
        g_XmppUserName.Buf.Length = OptionLen;

        g_XmppSetStatus+=XMPP_STATUS_USERNAME;
        break;

      case NETAPP_XMPP_PASSWORD:
        pXmppPassword = (SlNetAppXmppPassword_t*)pOptionValue;

        memcpy(g_XmppPassword.Buf.Password, pXmppPassword->Password, OptionLen);
        g_XmppPassword.Buf.Length = OptionLen;

        g_XmppSetStatus+=XMPP_STATUS_PASSWORD;
        break;

      case NETAPP_XMPP_DOMAIN:
        pXmppDomain = (SlNetAppXmppDomain_t*)pOptionValue;

        memcpy(g_XmppDomain.Buf.DomainName, pXmppDomain->DomainName, OptionLen);
        g_XmppDomain.Buf.Length = OptionLen;

        g_XmppSetStatus+=XMPP_STATUS_DOMAIN;
        break;

      case NETAPP_XMPP_RESOURCE:
        pXmppResource = (SlNetAppXmppResource_t*)pOptionValue;
        memcpy(g_XmppResource.Buf.Resource, pXmppResource->Resource, OptionLen);
        g_XmppResource.Buf.Length = OptionLen;
        g_XmppSetStatus+=XMPP_STATUS_RESOURCE;
        break;
      default:
        return -1;
    }

    return 0;
}

/*!
    \brief Initiates the XMPP connection process

    Connect to an XMPP server using all the predefined XMPP parameters.

    \return         On success, positive is returned.
                    On error, negative is returned

    \sa
    \note
    \warning
*/
int sl_NetAppXmppConnect()
{
    SlSockAddrIn_t  Addr;
    INT16            AddrSize = 0;
    INT16            Status = 0;
    UINT8            method = 0;
    INT32            cipher = 0;

    if (g_XmppSetStatus != 0x1F)
    {
        return -1;
    }

    method = g_XmppOpt.Buf.SecurityMethod;
    cipher = g_XmppOpt.Buf.SecurityCypher;

    Addr.sin_family = g_XmppOpt.Buf.Family;
    Addr.sin_port = sl_Htons(g_XmppOpt.Buf.Port);
    Addr.sin_addr.s_addr = sl_Htonl(g_XmppOpt.Buf.Ip);

    AddrSize = sizeof(SlSockAddrIn_t);

    /* opens a secure socket */
    g_SockID = sl_Socket(SL_AF_INET,SL_SOCK_STREAM, SL_SECURITY_ANY);

    if( g_SockID < 0 )
    {
        return -1;
    }

    /*configure the socket security method */
    Status = sl_SetSockOpt(g_SockID, SL_SOL_SOCKET, SO_SECMETHOD,
                           &method, sizeof(method));
    if( Status < 0 )
    {
        sl_Close(g_SockID);
        return -1;
    }

     /*configure the socket cipher */
    Status = sl_SetSockOpt(g_SockID, SL_SOL_SOCKET, SO_SECURE_MASK,
                           &cipher, sizeof(cipher));
    if( Status < 0 )
    {
        sl_Close(g_SockID);
        return -1;
    }

    /* connect to the peer device */
    Status = sl_Connect(g_SockID, ( SlSockAddr_t *)&Addr, AddrSize);
    if( (Status < 0 ) && (SL_ESECSNOVERIFY != Status))
    {
        sl_Close(g_SockID);
        return -1;
    }

    SlXmppConnectionSM();
    return g_SockID;
}

/*!
    \brief Validate the server

    \param[in]      none

    \return         0 for success, -1 otherwise

    \sa
    \note
    \warning
*/
static int SlValidateServerInfo(void)
{
    char *pServerStr = 0;

    if(!strstr(g_RecvBuf.Buf, "stream:stream"))
    {
        return -1;
    }

    pServerStr = strstr(g_RecvBuf.Buf, "from=");
    if(strncmp((const char *)pServerStr+6,
               (const char *)g_XmppDomain.Buf.DomainName, g_XmppDomain.Buf.Length))
    {
        return -1;
    }

    return 0;
}

/*!
    \brief Validate the authentication query response

    \param[in]      none

    \return         0 for success, -1 otherwise

    \sa
    \note
    \warning
*/
static int SlValidateQueryResult(void)
{
    if(strstr(g_RecvBuf.Buf, "<success"))
        return 0;
    else
        return -1;
}

/*!
    \brief Validate the bind feature query response

    \param[in]      none

    \return         0 for success, -1 otherwise

    \sa
    \note
    \warning
*/
static int SlValidateBindFeature(void)
{
    if(!strstr(g_RecvBuf.Buf, "xmpp-bind"))
    {
        return -1;
    }

    return 0;
}

/*!
    \brief Validate the bind configuration query response

    \param[in]      none

    \return         0 for success, -1 otherwise

    \sa
    \note
    \warning
*/
static int SlBindingConfigure(void)
{
    char *pJid = 0;
    char *pMyJid = MyJid.Buf;
    int idx = 0;

    if(!strstr(g_RecvBuf.Buf, "result") || !strstr(g_RecvBuf.Buf, "bind"))
    {
        return -1;
    }

    pJid = strstr(g_RecvBuf.Buf, "<jid>");
    if(!pJid)
        return -1;

    pJid += 5;

    while(*pJid != '<')
    {
        pMyJid[idx++] = *pJid;
        pJid ++;
    }

    pMyJid[idx] = '\0';
    return 0;
}

/*!
    \brief Validate the roster request query response

    \param[in]      none

    \return         0 for success, -1 otherwise

    \sa
    \note
    \warning
*/
static int SlValidateRoster(void)
{
    char *pJid = 0;
    char *pMyJid = g_RosterJid.Buf;
    int  idx = 0;

    if(!strstr(g_RecvBuf.Buf, "jabber:iq:roster") ||
       !strstr(g_RecvBuf.Buf, "roster_1"))
    {
        return -1;
    }

    pJid = strstr(g_RecvBuf.Buf, "item jid=");
    while (pJid != NULL)
    {
        pJid += 10;

        while(*pJid != ' ')
        {
            pMyJid[idx++] = *pJid;
            pJid ++;
        }

        pMyJid[idx-1] = '\0';
        idx = 0;
        pJid = strstr(pJid, "item jid=");
    }

    return 0;
}

/*!
    \brief Validate the Session query response

    \param[in]      none

    \return         0 for success, -1 otherwise

    \sa
    \note
    \warning
*/
static int SlXMPPSessionConfig(void)
{
    if(!strstr(g_RecvBuf.Buf, "result"))
    {
        return -1;
    }

    return 0;
}

/*!
    \brief Send a XMPP message


    \param[in] pRemoteJid -  The remote user ID that sent us the XMPP message

    \param[in] Jidlen - The size of the pRemoteJid buffer

    \param[in] pMessage - The buffer which will hold the retreived message

    \param[in] Msglen - The maximal size of the message buffer


    \return         On success, positive is returned.
                    On error, negative is returned
    \sa
    \note
    \warning    The Send function doesn't check the Jid validity or its' status
                (online, off line, etc.)
*/
int sl_NetAppXmppSend(UINT8* pRemoteJid, UINT16 Jidlen,
                      UINT8* pMessage, UINT16 Msglen)
{
    char *ccPtr = 0;
    int Status = 0;

    memset(g_SendBuf.Buf, 0, sizeof(g_SendBuf.Buf));
    ccPtr = g_SendBuf.Buf;

    memcpy(ccPtr, "<message to='", 13);
    ccPtr += 13;

    memcpy(ccPtr, pRemoteJid, Jidlen);
    ccPtr += Jidlen;

    memcpy(ccPtr, "' type='chat' from='", 20);
    ccPtr += 20;

    memcpy(ccPtr, MyJid.Buf, strlen(MyJid.Buf));
    ccPtr += strlen(MyJid.Buf);

    memcpy(ccPtr, "'><body>", 8);
    ccPtr += 8;

    memcpy(ccPtr, pMessage, Msglen);
    ccPtr += Msglen;

    memcpy(ccPtr, "</body><active xmlns='http://jabber.org/protocol/chatstates'/></message>", 72);
    ccPtr += 72;

    *ccPtr= '\0';

    Status = sl_Send(g_SockID, g_SendBuf.Buf, strlen(g_SendBuf.Buf), 0);

    return Status;
}

/*!
    \brief Retrieve XMPP message


    \param[out] pRemoteJid -  The remote user ID that sent us the XMPP message

    \param[in] Jidlen - The size of the pRemoteJid buffer

    \param[out] pMessage - The buffer which will hold the retreived message

    \param[in] Msglen - The maximal size of the message buffer


    \return         On success, positive is returned.
                    -1 - error, General error, problem in parsing XMPP buffer
                    -2 - error, Jid buffer too small to hold the remote user id
                    -3 - error, Message buffer too small to hold the received
                                message
    \sa
    \note
    \warning
*/
int sl_NetAppXmppRecv(UINT8* pRemoteJid, UINT16 Jidlen,
                      UINT8* pMessage, UINT16 Msglen)
{
    char *pBasePtr = 0;
    char *pBodyPtr = 0;
    char *pFromPtr = 0;
    short    nonBlocking = 1;
    int Status = 0;

    setsockopt(g_SockID, SOL_SOCKET, SO_NONBLOCKING,
                 &nonBlocking, sizeof(nonBlocking));

    memset(g_RosterJid.Buf, 0, sizeof(g_RosterJid.Buf));
    memset(g_RecvBuf.Buf,'\0',sizeof(g_RecvBuf.Buf));

    Status = sl_Recv(g_SockID, g_RecvBuf.Buf, sizeof(g_RecvBuf.Buf), 0);
    if (Status > 0)
    {
        if(Status == sizeof(g_RecvBuf.Buf))
            return -1;

        pBasePtr = strstr(g_RecvBuf.Buf, "<body>");
        if(!pBasePtr)
        {
            return -1;
        }

        pBasePtr += 6;
        pBodyPtr = pBasePtr;
        while(*pBodyPtr != '<')
        {
            pBodyPtr ++;
        }

        /* null the body string */
        *pBodyPtr = '\0';
        if (strlen(pBasePtr)+1 < Msglen)
        {
            memcpy(pMessage, pBasePtr, strlen(pBasePtr)+1);
        }
        else
        {
            return -3;
        }

        pBodyPtr = strstr(g_RecvBuf.Buf, "from=");

        /* Increment the pointer by 6 (from=") */
        pBodyPtr += 6;
        pFromPtr = pBodyPtr;
        while(*pBodyPtr != '"')
        {
            pBodyPtr ++;
        }

        /* null the body string */
        *pBodyPtr = '\0';

        if (strlen(pFromPtr)+1 < Jidlen)
        {
            memcpy(pRemoteJid, pFromPtr, strlen(pFromPtr)+1);
            memcpy(RemoteJid.Buf, pFromPtr, strlen(pFromPtr)+1);
            memcpy(g_RosterJid.Buf, RemoteJid.Buf, strlen(RemoteJid.Buf)+1);
        }
        else
        {
            return -2;
        }
    }

    return Status;
}

/*!
    \brief Flushes the xmpp receive buffer

    \param[in]      none

    \return         none

    \sa
    \note
    \warning
*/
void FlushSendRecvBuffer(void)
{
    memset(g_RecvBuf.Buf, '\0', sizeof(g_RecvBuf.Buf));
    g_RecvBuf.Buf[0] = '\0';

    memset(g_SendBuf.Buf, '\0', sizeof(g_SendBuf.Buf));
    g_SendBuf.Buf[0] = '\0';
}

/*!
    \brief Convert the string to Base64 format needed for authentication

    \param[in]      none

    \return         none

    \sa
    \note
    \warning
*/
void GenerateBase64Key(void)
{
    char OneByteArray[1] = {0x00};
    char InputStr[BUF_SIZE] = {'\0'};
    char *pIn = (char *)InputStr;
    int length = 0;

    /* Generate Base64 Key. The orginal key is "username@domain" +
    *  '\0' + "username" + '\0' + "password" */
    memcpy(pIn, g_XmppUserName.Buf.UserName, g_XmppUserName.Buf.Length);
    pIn += g_XmppUserName.Buf.Length;

    memcpy(pIn, "@", 1);
    pIn ++;

    memcpy(pIn, g_XmppDomain.Buf.DomainName, g_XmppDomain.Buf.Length);
    pIn += g_XmppDomain.Buf.Length;

    memcpy(pIn, OneByteArray, 1);
    pIn ++;

    memcpy(pIn,  g_XmppUserName.Buf.UserName, g_XmppUserName.Buf.Length);
    pIn +=  g_XmppUserName.Buf.Length;

    memcpy(pIn, OneByteArray, 1);
    pIn ++;

    memcpy(pIn, g_XmppPassword.Buf.Password, g_XmppPassword.Buf.Length);
    length = g_XmppUserName.Buf.Length*2;
    length += 3 + g_XmppDomain.Buf.Length +  g_XmppPassword.Buf.Length;

    ConvertToBase64(g_MyBaseKey.Buf, (void *)InputStr, length);
}

/*!
    \brief XMPP connection station machine

    \param[in]      none

    \return         none

    \sa
    \note
    \warning
*/
static void SlXmppConnectionSM(void)
{
    int NeedToSend = 0;
    int RecvRetVal = 0;
    int NeedToReceive = 0;
    char *ccPtr = 0;
    int len =0;

    /* 3 steps for XMPP connection establishment
            1) initialization
            2) authentication
            3) binding
    */

    memset(g_MyBaseKey.Buf, '\0', sizeof(g_MyBaseKey.Buf));
    memset(MyJid.Buf, '\0', sizeof(MyJid.Buf));
    memset(RemoteJid.Buf, '\0', sizeof(RemoteJid.Buf));
    memset(g_RosterJid.Buf, '\0', sizeof(g_RosterJid.Buf));

    if(g_XMPPStatus == XMPP_INACTIVE)
    {
        return;
    }

    /* encode the username, password and domain in Base64 */
    GenerateBase64Key();

    while(g_XMPPStatus != CONNECTION_ESTABLISHED)
    {
        FlushSendRecvBuffer();

        ccPtr = (char*)g_SendBuf.Buf;

        if(NeedToReceive == 1)
        {
            memset(g_RecvBuf.Buf, '\0', sizeof(g_RecvBuf.Buf));
            RecvRetVal = sl_Recv(g_SockID, g_RecvBuf.Buf,
                                 sizeof(g_RecvBuf.Buf), 0);
        }

        if(NeedToReceive == 1 && strlen(g_RecvBuf.Buf) <= 0)
            continue;

        switch(g_XMPPStatus)
        {
          case XMPP_INIT:
            memcpy(ccPtr, "<stream:stream to='", 19);
            ccPtr += 19;
            memcpy(ccPtr, g_XmppDomain.Buf.DomainName, g_XmppDomain.Buf.Length);
            ccPtr += g_XmppDomain.Buf.Length;
            memcpy(ccPtr, "' ", 2);
            ccPtr += 2;
            memcpy(ccPtr, JABBER_XMLNS_INFO, strlen(JABBER_XMLNS_INFO));
            ccPtr += strlen(JABBER_XMLNS_INFO);
            *ccPtr= '\0';

            NeedToSend = 1;
            NeedToReceive = 1;

            g_XMPPStatus = FIRST_STREAM_SENT;
            break;

          case FIRST_STREAM_SENT:
            if(RecvRetVal > 0 && SlValidateServerInfo() == 0)
            {
                NeedToReceive = 0;
                g_XMPPStatus = FIRST_STREAM_RECV;
            }
            else
            {
                NeedToReceive = 1;
            }
            break;

          case FIRST_STREAM_RECV:
            g_XMPPStatus = STARTTLS_RESPONSE_RECV;
            break;

          case STARTTLS_RESPONSE_RECV:
            memcpy(ccPtr, "<auth xmlns='urn:ietf:params:xml:ns:xmpp-sasl' mechanism='PLAIN'>", 65);
            ccPtr += 65;
            memcpy(ccPtr, g_MyBaseKey.Buf, strlen(g_MyBaseKey.Buf));
            ccPtr += strlen(g_MyBaseKey.Buf);
            memcpy(ccPtr, "</auth>", 7);
            ccPtr += 7;
            *ccPtr= '\0';

            NeedToSend = 1;
            NeedToReceive = 1;

            g_XMPPStatus = AUTH_QUERY_SET;
            break;

          case AUTH_QUERY_SET:
            if((RecvRetVal > 0) && (SlValidateQueryResult() == 0))
            {
                NeedToReceive = 0;

                g_XMPPStatus = AUTH_RESULT_RECV;
            }
            else
            {
                NeedToReceive = 1;
            }
            break;

          case AUTH_RESULT_RECV:
            memcpy(ccPtr, "<stream:stream to='", 19);
            ccPtr += 19;
            memcpy(ccPtr, g_XmppDomain.Buf.DomainName, g_XmppDomain.Buf.Length);
            ccPtr += g_XmppDomain.Buf.Length;
            memcpy(ccPtr, "' ", 2);
            ccPtr += 2;
            memcpy(ccPtr, JABBER_XMLNS_INFO, strlen(JABBER_XMLNS_INFO));
            ccPtr += strlen(JABBER_XMLNS_INFO);
            *ccPtr= '\0';

            NeedToSend = 1;
            NeedToReceive = 1;

            g_XMPPStatus = BIND_FEATURE_RESPONSE;
            break;

          case BIND_FEATURE_REQUEST:
            NeedToSend = 0;
            NeedToReceive = 0;

            g_XMPPStatus = BIND_FEATURE_RESPONSE;
            break;

          case BIND_FEATURE_RESPONSE:
            if(RecvRetVal > 0 && SlValidateBindFeature() == 0)
            {
                NeedToReceive = 0;
                g_XMPPStatus = BIND_CONFIG_SET;
            }
            else
            {
                NeedToReceive = 1;
            }
            break;

          case BIND_CONFIG_SET:
            memcpy(ccPtr, "<iq id='JAJSBind' type='set'><bind xmlns='urn:ietf:params:xml:ns:xmpp-bind'><resource>", 86);
            ccPtr += 86;
            memcpy(ccPtr,g_XmppResource.Buf.Resource,g_XmppResource.Buf.Length);
            ccPtr += g_XmppResource.Buf.Length;
            memcpy(ccPtr, "</resource></bind></iq>", 23);
            ccPtr += 23;
            *ccPtr= '\0';

            NeedToSend = 1;
            NeedToReceive = 1;

            g_XMPPStatus = BIND_CONFIG_RECV;
            break;

          case BIND_CONFIG_RECV:
            if(RecvRetVal > 0 && SlBindingConfigure() == 0)
            {
                NeedToReceive = 0;

                g_XMPPStatus = XMPP_SESSION_SET;
            }
            else
            {
                NeedToSend = 0;
                NeedToReceive = 0;
                g_XMPPStatus = XMPP_INIT;
            }
            break;

          case XMPP_SESSION_SET:
            memcpy(ccPtr, "<iq type='set' id='2'><session xmlns='urn:ietf:params:xml:ns:xmpp-session'/></iq>", 81);
            ccPtr += 81;
            *ccPtr= '\0';

            NeedToSend = 1;
            NeedToReceive = 1;

            g_XMPPStatus = XMPP_SESSION_RECV;
            break;

          case XMPP_SESSION_RECV:
            if(RecvRetVal > 0 && SlXMPPSessionConfig() == 0)
            {
                NeedToReceive = 0;
                g_XMPPStatus = PRESENCE_SET;
            }
            else
            {
                NeedToReceive = 1;
            }
            break;

          case PRESENCE_SET:

            NeedToSend = 1;
            NeedToReceive = 0;

            memcpy(ccPtr, PRESENCE_MESSAGE, strlen(PRESENCE_MESSAGE));
            ccPtr += strlen(PRESENCE_MESSAGE);
            *ccPtr= '\0';

            g_XMPPStatus = ROSTER_REQUEST;
            break;

          case ROSTER_REQUEST:

            memcpy(ccPtr, "<iq type='get' id='roster_1' from='", 35);
            ccPtr += 35;
            memcpy(ccPtr, MyJid.Buf, strlen(MyJid.Buf));
            ccPtr += strlen(MyJid.Buf);
            memcpy(ccPtr, "'> <query xmlns='jabber:iq:roster'/></iq>", 50);
            ccPtr += 50;
            *ccPtr= '\0';

            NeedToSend = 1;
            NeedToReceive = 0;

            g_XMPPStatus = ROSTER_RESPONSE;

            break;

          case ROSTER_RESPONSE:
            NeedToSend = 1;
            NeedToReceive = 1;

            if (SlValidateRoster() == 0)
            {
                g_XMPPStatus = CONNECTION_ESTABLISHED;
                NeedToReceive = 0;
                NeedToSend = 0;
            }

            break;
        }

        if(NeedToSend ==  1)
        {
            NeedToSend = 0;
            len = strlen(g_SendBuf.Buf);

            sl_Send(g_SockID, g_SendBuf.Buf, len, 0);
        }
    }
    memset(g_RecvBuf.Buf,'\0',sizeof(g_RecvBuf.Buf));
}
