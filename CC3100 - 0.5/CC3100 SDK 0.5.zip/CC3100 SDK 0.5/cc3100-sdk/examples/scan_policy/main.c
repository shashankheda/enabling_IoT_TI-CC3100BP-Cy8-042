/*
 * main.c - sample application for AP scanning
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/ 
 * 
 * 
 *  Redistribution and use in source and binary forms, with or without 
 *  modification, are permitted provided that the following conditions 
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright 
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the 
 *    documentation and/or other materials provided with the   
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT 
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT 
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, 
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT 
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT 
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE 
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "simplelink.h"

#define SCAN_TABLE_SIZE  20
#define SCAN_INTERVAL    10

Sl_WlanNetworkEntry_t netEntries[SCAN_TABLE_SIZE];

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
		SlHttpServerResponse_t *pHttpResponse)
{
}

/*!

    \brief  the aim of this example code is to demonstrate how scan policy is
            set in the device.
            The procedure includes the following steps:
            1) make sure the connection policy is not set (so no scan is run in
               the background)
            2) enable scan, set scan cycle to 10 seconds and set scan policy
               This starts the scan
            3) get scan results - all 20 entries in one transaction
            4) get scan results - 4 transactions of 5 entries
            5) disable scan

    \param  None

    \return -1 in case of error, 0 otherwise
              Also, LED1 is turned solid in case of success
              LED8 is turned solid in case of failure

    \warning  make sure the connection policy is not set (so no scan is run in
              the background)

*/

int main(void)
{
    UINT8   policyOpt = 0;
    UINT16  runningIdx = 0;
    UINT32  numOfEntries = 0;
    INT16   retVal = 0;
    UINT32  policyVal = 0;


    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initialize the LEDs */
    initLEDs();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /** make sure the connection policy is not set (so no scan is run in the
      * background) */
    policyOpt = SL_CONNECTION_POLICY(0, 0, 0, 0, 0);
    retVal = sl_WlanPolicySet(SL_POLICY_CONNECTION , policyOpt, NULL, 0);
    if (retVal < 0)
    {
        turnLedOn(LED1);
        return -1;
    }

    /* enable scan */
    policyOpt = SL_SCAN_POLICY(1);

    /* set scan cycle to 10 seconds */
    policyVal = SCAN_INTERVAL;

    /* set scan policy - this starts the scan */
    retVal = sl_WlanPolicySet(SL_POLICY_SCAN , policyOpt,
                            (UINT8 *)&policyVal, sizeof(policyVal));

    /* delay 1 second to verify scan is started */
    Delay(1000);

    /* get scan results - all 20 entries in one transaction */
    runningIdx = 0;
    numOfEntries = SCAN_TABLE_SIZE;

    /* retVal indicates the valid number of entries */
    /* The scan results are occupied in netEntries[] */
    retVal = sl_WlanGetNetworkList(runningIdx, numOfEntries,
                                   &netEntries[runningIdx]);

    /* get scan results - 4 transactions of 5 entries */
    runningIdx = 0;
    numOfEntries = 5;
    memset(netEntries, 0, sizeof(netEntries));

    do
    {
        retVal = sl_WlanGetNetworkList(runningIdx, numOfEntries,
                                       &netEntries[runningIdx]);
        runningIdx += retVal;
    }while ((retVal == numOfEntries) && (runningIdx < SCAN_TABLE_SIZE));

    /* disable scan */
    policyOpt = SL_SCAN_POLICY(0);
    retVal = sl_WlanPolicySet(SL_POLICY_SCAN , policyOpt, NULL, 0);

    if (retVal < 0)
    {
        turnLedOn(LED1);
        return -1;
    }

    /* turn On the green LED */
    turnLedOn(LED2);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
