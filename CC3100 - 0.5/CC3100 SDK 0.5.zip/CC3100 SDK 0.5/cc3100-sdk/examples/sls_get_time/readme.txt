For information on this example refer to:
docs\examples\sls_get_time.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_SLS_Get_Time_Application