/*
 * main.c - get time sample application
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include <stdio.h>
#include <windows.h>
#include <string.h>

#include "simplelink.h"

#define TIME2013        3565987200         /* 43 years + 11 days of leap years */
#define YEAR2013        2013
#define SEC_IN_MIN      60
#define SEC_IN_HOUR     3600
#define SEC_IN_DAY      86400

#define BAUD_RATE       115200
#define MAX_BUF_SIZE    48
#define MAX_PASSKEY_LEN 32
#define MAX_SSID_LEN    32
#define SUCCESS         0

/*! ######################### List of SNTP servers ############################
 *! ##
 *! ##          hostname            |        IP        |       location
 *! ## ------------------------------------------------------------------------
 *! ## ntp.inode.at                 | 195.58.160.5     | Vienna
 *! ## ntp3.proserve.nl             | 212.204.198.85   | Amsterdam
 *! ## ntp1.madavi.de               | 194.50.97.12     | Stuttgart, Germany
 *! ## ntp.spadhausen.com           | 109.168.118.249  | Milano - Italy
 *! ## ntp3.tcpd.net                | 23.23.128.218    | London, UK
 *! ## dmz0.la-archdiocese.net      | 209.151.225.100  | Los Angeles, CA
 *! ## Optimussupreme.64bitVPS.com  | 216.128.88.62    | Brooklyn, New York
 *! ## ntp.mazzanet.id.au           | 203.206.205.83   | Australia
 *! ## a.ntp.br                     | 200.160.0.8      | Sao Paulo, Brazil
 *! ###########################################################################
 */
const char SNTPserver[MAX_SSID_LEN] = "ntp.inode.at"; /* Add one of the above servers */

/* Tuesday is the 1st day in 2013 - the relative year */
const char daysOfWeek2013[7][4] = {{"Tue"},
                                   {"Wed"},
                                   {"Thu"},
                                   {"Fri"},
                                   {"Sat"},
                                   {"Sun"},
                                   {"Mon"}};

const char monthOfYear[12][4] = {{"Jan"},
                                 {"Feb"},
                                 {"Mar"},
                                 {"Apr"},
                                 {"May"},
                                 {"Jun"},
                                 {"Jul"},
                                 {"Aug"},
                                 {"Sep"},
                                 {"Oct"},
                                 {"Nov"},
                                 {"Dec"}};

const char numOfDaysPerMonth[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
char hour_pending = TRUE;

const char digits[] = "0123456789";

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02

}e_Status;
UINT8 g_Status = 0;

#ifdef SL_IF_TYPE_UART
#define COMM_PORT_NUM 10
SlUartIfParams_t params;
#endif

struct
{
    UINT8 time[MAX_SSID_LEN];

    UINT32 DestinationIP;
    UINT32 elapsedSec;
    UINT32 uGeneralVar;
    UINT32 uGeneralVar1;

    INT32  SockID;
    INT32 sGeneralVar;

    UINT16 ccLen;

    UINT8 *ccPtr;
}appData;

typedef struct{
    UINT8 SSID[MAX_SSID_LEN];
    INT32 encryption;
    UINT8 password[MAX_PASSKEY_LEN];
}UserInfo;

/*!
    \brief Read option fron the user

    \param[in]      none

    \return         int - user option value

    \note

    \warning
*/
int GetUserNum()
{
    UINT8 flag = 0;
    UINT8 input[20] = {'\0'};
    INT32 value = 0;

    while (!flag)
    {
        if (scanf_s("%s",input,sizeof(input)) != 0)
        {
            value = atoi(input);
            if (value > 0 && value < 5 )
            {
                flag = 1;
            }
            else
            {
                printf("Invalid entry. Please try again:\n");
            }
        }
    }

    return value;
}

/*!
    \brief Get the AP parameters from the user

    \param[in]      none

    \return         UserInfo - structure containg SSID, encryption type and
                    pass key of AP

    \note

    \warning
*/
UserInfo GetUserInput ()
{
    UserInfo UserFunction;
    INT32 eflag = -1;
    INT32 wepflag = -1;
    INT32 length = -1;

    printf("Please input the SSID you wish to connect to: \n");
    scanf_s("%s",UserFunction.SSID,MAX_SSID_LEN);

    printf("Encryption Types:\n");
    printf("1:  Open\n");
    printf("2:  WEP\n");
    printf("3:  WPA\n");
    printf("Please enter the corresponding number for the encryption type: \n");
    UserFunction.encryption = GetUserNum();

    if (2 == UserFunction.encryption || /* WEP */
        3 == UserFunction.encryption)   /* WAP */
    {
        printf ("Please enter the password: \n");
        scanf_s("%s",UserFunction.password,MAX_PASSKEY_LEN);
    }

    return UserFunction;
}


/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         none

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
            g_Status |= CONNECTED;
        break;

        case SL_WLAN_DISCONNECT_EVENT:
            g_Status &= ~(1 << CONNECTION_STATUS_BIT | 1 << IP_AQUIRED_STATUS_BIT);
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_AQUIRED;
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}

/*!
    \brief Convert integer to ASCII in decimal base

    \param[in]      cNum - integer number to convert

    \param[OUT]     cString - output string

    \return         number of ASCII characters

    \warning
*/
static unsigned short Itoa(short cNum, char *cString)
{
    UINT16 length = 0;
    INT8 *ptr = NULL;
    INT16 uTemp = cNum;

    /* value 0 is a special case */
    if (cNum == 0)
    {
        length = 1;
        *cString = '0';

        return length;
    }

    /* Find out the length of the number, in decimal base */
    length = 0;
    while (uTemp > 0)
    {
        uTemp /= 10;
        length++;
    }

    /* Do the actual formatting, right to left */
    uTemp = cNum;
    ptr = cString + length;
    while (uTemp > 0)
    {
        --ptr;
        *ptr = digits[uTemp % 10];
        uTemp /= 10;
    }

    return length;
}

/*!
    \brief Get the required data from the server.

    \param[in]      gmt_hr - GMT offset hours

    \param[in]      gmt_min - GMT offset minutes

    \return         none

    \warning
*/
static void GetSNTPTime(int gmt_hr, int gmt_min)
{
    SlSockAddrIn_t  LocalAddr;
    SlSockAddr_t Addr;
    //unsigned long a = LocalAddr.sin_addr.s_addr;

    UINT8 dataBuf[MAX_BUF_SIZE];
    INT32 iRet = -1;
    INT32 AddrSize = -1;

    memset(dataBuf, 0, sizeof(dataBuf));
    dataBuf[0] = '\x1b';

    Addr.sa_family = SL_AF_INET;
    /* the source port */
    Addr.sa_data[0] = 0x00;
    Addr.sa_data[1] = 0x7B;    /* 123 */
    Addr.sa_data[2] = (char)((appData.DestinationIP >> 24) & 0xff);
    Addr.sa_data[3] = (char)((appData.DestinationIP >> 16) & 0xff);
    Addr.sa_data[4] = (char)((appData.DestinationIP >> 8) & 0xff);
    Addr.sa_data[5] = (char) (appData.DestinationIP & 0xff);

    iRet = sl_SendTo(appData.SockID, dataBuf, sizeof(dataBuf), 0,
                     &Addr, sizeof(Addr));
    if (iRet != sizeof(dataBuf))
    {
        /* could not send SNTP request */
        printf("Could not send SNTP request\n\r");
        return;
    }

    AddrSize = sizeof(SlSockAddrIn_t);
    LocalAddr.sin_family = SL_AF_INET;
    LocalAddr.sin_port = 0;
    LocalAddr.sin_addr.s_addr = 0;
    sl_Bind(appData.SockID,(SlSockAddr_t *)&LocalAddr, AddrSize);

    iRet = sl_RecvFrom(appData.SockID, dataBuf, sizeof(dataBuf), 0,
                       (SlSockAddr_t *)&LocalAddr,  (SlSocklen_t*)&AddrSize);
    if (iRet <= 0)
    {
        printf("Did not receive\n\r");
        return;
    }

    if ((dataBuf[0] & 0x7) != 4)    /* expect only server response */
    {
        /* MODE is not server, abort */
        printf("Expecting response from Server Only!\n\r");
        return;
    }
    else
    {
        INT8 index;

        appData.elapsedSec = dataBuf[40];
        appData.elapsedSec <<= 8;
        appData.elapsedSec += dataBuf[41];
        appData.elapsedSec <<= 8;
        appData.elapsedSec += dataBuf[42];
        appData.elapsedSec <<= 8;
        appData.elapsedSec += dataBuf[43];

        appData.elapsedSec -= TIME2013;

        /* correct the timezone */
        appData.elapsedSec += (gmt_hr * SEC_IN_HOUR);
        appData.elapsedSec += (gmt_min * SEC_IN_MIN);

        appData.ccPtr = &appData.time[0];

        /* day */
        appData.sGeneralVar = appData.elapsedSec/SEC_IN_DAY;
        memcpy(appData.ccPtr, daysOfWeek2013[appData.sGeneralVar%7], 3);
        appData.ccPtr += 3;
        *appData.ccPtr++ = '\x20';

        /* month */
        appData.sGeneralVar %= 365;
        for (index = 0; index < 12; index++)
        {
            appData.sGeneralVar -= numOfDaysPerMonth[index];
            if (appData.sGeneralVar < 0)
                break;
        }

        memcpy(appData.ccPtr, monthOfYear[index], 3);
        appData.ccPtr += 3;
        *appData.ccPtr++ = '\x20';

        /* date */
        /* restore the day in current month*/
        appData.sGeneralVar += numOfDaysPerMonth[index];
        appData.ccLen = Itoa(appData.sGeneralVar + 1, appData.ccPtr);
        appData.ccPtr += appData.ccLen;
        *appData.ccPtr++ = '\x20';

        /* year */
        /* number of days since beginning of 2013 */
        appData.uGeneralVar = appData.elapsedSec/SEC_IN_DAY;
        appData.uGeneralVar /= 365;
        appData.ccLen = Itoa(YEAR2013 + appData.uGeneralVar , appData.ccPtr);
        appData.ccPtr += appData.ccLen;
        *appData.ccPtr++ = '\x20';

        /* time */
        appData.uGeneralVar = appData.elapsedSec%SEC_IN_DAY;
        /* number of seconds per hour */
        appData.uGeneralVar1 = appData.uGeneralVar%SEC_IN_HOUR;
        appData.uGeneralVar /= SEC_IN_HOUR;                 /* number of hours */
        appData.ccLen = Itoa(appData.uGeneralVar, appData.ccPtr);
        appData.ccPtr += appData.ccLen;
        *appData.ccPtr++ = ':';
        /* number of minutes per hour */
        appData.uGeneralVar = appData.uGeneralVar1/SEC_IN_MIN;
        /* number of seconds per minute */
        appData.uGeneralVar1 %= SEC_IN_MIN;
        appData.ccLen = Itoa(appData.uGeneralVar, appData.ccPtr);
        appData.ccPtr += appData.ccLen;
        *appData.ccPtr++ = ':';
        appData.ccLen = Itoa(appData.uGeneralVar1, appData.ccPtr);
        appData.ccPtr += appData.ccLen;
        *appData.ccPtr++ = '\x20';

        *appData.ccPtr++ = '\0';

        printf("response from server: %s\n\r",SNTPserver);
        printf("%s\n\n",appData.time);
    }
}

/*!
    \brief Create UDP socket to communicate with server.

    \param[in]      none

    \return         Socket descriptor for success otherwise negative

    \warning
*/
int CreateConnection()
{
    INT32 sd = 0;

    sd = sl_Socket(SL_AF_INET, SL_SOCK_DGRAM, SL_IPPROTO_UDP);
    if( sd < 0 )
    {
        printf("Error creating socket\n\r");
    }

    return sd;
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the AP (SSID_NAME).
    The function will return once we are connected and have acquired IP address

    \param[in]  UserParams - Structure having SSID, security type and pass key
                of AP to connect

    \return         0 for success and negative for error

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
int WlanConnect(UserInfo UserParams)
{
    SlSecParams_t secParams;
    INT32 status = -1;

    if (UserParams.encryption == 1)
    {
        secParams.Key = "";
        secParams.KeyLen = 0;
        secParams.Type = SL_SEC_TYPE_OPEN;
    }
    else
    {
        secParams.Key = UserParams.password;
        secParams.KeyLen = strlen(UserParams.password);

        if (UserParams.encryption == 2) secParams.Type = SL_SEC_TYPE_WEP;
        if (UserParams.encryption == 3) secParams.Type = SL_SEC_TYPE_WPA;
    }

    status = sl_WlanConnect(UserParams.SSID,
                            strlen(UserParams.SSID),
                            0, &secParams, 0);
    if (status == SUCCESS )
    {
        printf("Connecting to AP %s...\n", UserParams.SSID  );
        while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
            ;
        printf("Connected to AP %s. IP acquired.\n", UserParams.SSID);
    }
    else
        printf("Can't establish connection to AP %s.\n", UserParams.SSID);

    return (status);
}

/*!
    \brief Gets the Server IP address

    \param[in]      none

    \return         zero for success and -1 for error

    \warning
*/
int GetHostIP()
{
    INT32 status = 0;
    appData.DestinationIP = 0;

    status = sl_NetAppDnsGetHostByName((char*)SNTPserver, strlen(SNTPserver),
                                       &appData.DestinationIP, SL_AF_INET);
    if (status != 0)
    {
        printf("Unable to reach Host\n");
        return -1;
    }

    return 0;
}

/*!
    \brief Get the time from server

    \param[in]      none

    \return         zero for success and -1 for error

    \warning
*/
int getTime()
{
    UserInfo User;
    UINT8 GMT_value[6];
    INT32 gmt_hr = 0;
    INT32 gmt_min = 0;

    INT8 *token = NULL;
    INT8 *next_token = NULL;

    memset(GMT_value, 0x00, _countof(GMT_value));

    User = GetUserInput();

    if( WlanConnect(User) != SUCCESS )
        return -1;

    if(GetHostIP() == 0)
    {
        if( (appData.SockID = CreateConnection()) < 0 )
        {
            return -1;
        }
        printf("Enter the GMT value of the Zone (HH:MM): \n");
        scanf_s("%s",GMT_value,6);

        token = strtok_s(GMT_value,":",&next_token);
        while (token != NULL)
        {
            if(hour_pending == TRUE)
            {
                gmt_hr = strtol(token, NULL, 10);
                hour_pending = FALSE;
            }
            else
            {
                gmt_min = strtol(token, NULL, 10);

                if(gmt_hr < 0)
                    gmt_min *= -1;
            }

            token = strtok_s(NULL, ":",&next_token);
        }

        GetSNTPTime(gmt_hr, gmt_min);

        sl_Close(appData.SockID);
    }
    printf("\n\rThank you!\n\r");

    return 0;
}

int main(void)
{
    INT32 ret = 0;
    INT8 *pConfig = NULL;

#ifdef SL_IF_TYPE_UART
    params.BaudRate = BAUD_RATE;
    params.FlowControlEnable = 1;
    params.CommPort = COMM_PORT_NUM;

    pConfig = (char *)&params;
#endif /* SL_IF_TYPE_UART */

    /*This line is for Eclipse CDT only due to a known bug in console buffering
    * See https://bugs.eclipse.org/bugs/show_bug.cgi?id=173732 */
    setvbuf(stdout, NULL, _IONBF, 0);

    /* Initializing the CC3100 device */
    sl_Start(0, pConfig, 0);

    printf("\n\rStarted Get-Time SimpleLink Application \n\r\n\r");

    ret = getTime();
    system("PAUSE");
    return ret;
}
