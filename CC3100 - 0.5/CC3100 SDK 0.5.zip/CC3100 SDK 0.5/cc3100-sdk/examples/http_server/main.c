/*
 * main.c - HTTP server sample example
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "simplelink.h"
#include "protocol.h"
#include "cli_uart.h"

#define SSID_NAME "<ap-name>"

#define HTTP_SERVER_ID      SL_NET_APP_HTTP_SERVER_ID
#define DEVICE_CONFIG_ID    SL_NET_APP_DEVICE_CONFIG_ID

UINT8 POST_token[] = "__SL_P_L.D";
UINT8 GET_token[]  = "__SL_G_LED";

enum
{
    IP_ACQUIRED = 0x1
}e_Stauts;

UINT8 g_Status = 0;

UINT8 g_auth_name[MAX_AUTH_NAME_LEN+1];
UINT8 g_auth_password[MAX_AUTH_PASSWORD_LEN+1];
UINT8 g_auth_realm[MAX_AUTH_REALM_LEN+1];

UINT8 g_domain_name[MAX_DOMAIN_NAME_LEN];
UINT8 g_device_urn[MAX_DEVICE_URN_LEN];

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         none

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEventHandler)
{
    /* Not used by the application */
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pEvent,
        SlHttpServerResponse_t *pResponse)
{
    switch (pEvent->Event)
    {
        case SL_NETAPP_HTTPGETTOKENVALUE:
        {
            UINT8 status = 0;
            UINT8 *ptr = 0;

            ptr = pResponse->ResponseData.token_value.data;
            pResponse->ResponseData.token_value.len = 0;
            if(memcmp(pEvent->EventData.httpTokenName.data, GET_token,
                                         strlen((const char *)GET_token)) == 0)
            {
                status = GetLEDStatus();
                memcpy(ptr, "LED1_", strlen("LED1_"));
                ptr += 5;
                pResponse->ResponseData.token_value.len += 5;
                if(status & 0x01)
                {
                    memcpy(ptr, "ON", strlen("ON"));
                    ptr += 2;
                    pResponse->ResponseData.token_value.len += 2;
                }
                else
                {
                    memcpy(ptr, "OFF", strlen("OFF"));
                    ptr += 3;
                    pResponse->ResponseData.token_value.len += 3;
                }
                memcpy(ptr,",LED2_", strlen(",LED2_"));
                ptr += 6;
                pResponse->ResponseData.token_value.len += 6;
                if(status & 0x02)
                {
                    memcpy(ptr, "ON", strlen("ON"));
                    ptr += 2;
                    pResponse->ResponseData.token_value.len += 2;
                }
                else
                {
                    memcpy(ptr, "OFF", strlen("OFF"));
                    ptr += 3;
                    pResponse->ResponseData.token_value.len += 3;
                }

                *ptr = '\0';
            }

        }
        break;

        case SL_NETAPP_HTTPPOSTTOKENVALUE:
        {
            UINT8 led = 0;
            UINT8 *ptr = pEvent->EventData.httpPostData.token_name.data;

            if(memcmp(ptr, POST_token, strlen((const char *)POST_token)) == 0)
            {
                ptr = pEvent->EventData.httpPostData.token_value.data;
                if(memcmp(ptr, "LED", 3) != 0)
                    break;

                ptr += 3;
                led = *ptr;
                ptr += 2;
                if(led == '1')
                {
                    if(memcmp(ptr, "ON", 2) == 0)
                    {
                        turnLedOn(LED1);
                    }
                    else
                    {
                        turnLedOff(LED1);
                    }
                }
                else if(led == '2')
                {
                    if(memcmp(ptr, "ON", 2) == 0)
                    {
                        turnLedOn(LED2);
                    }
                    else
                    {
                        turnLedOff(LED2);
                    }
                }
            }
        }
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_ACQUIRED;
            break;

        default:
            break;
    }
}

/*!
    \brief Set the HTTP port

    This function can be used to change the default port (80) for HTTP request

    \param[in]      num- contains the port number to be set

    \return         None

    \note

    \warning
*/
INT32 set_port_number(UINT16 num)
{
    _NetAppHttpServerGetSet_port_num_t port_num;
    INT32 status = -1;

    port_num.port_number = num;

    /*Need to restart the server in order for the new port number configuration
     *to take place */
    status = sl_NetAppStop(HTTP_SERVER_ID);
    if(status < 0)
        return status;
    status  = sl_NetAppSet (HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_PORT_NUMBER,
                  sizeof(_NetAppHttpServerGetSet_port_num_t), (UINT8 *)&port_num);
    if(status < 0)
        return status;
    status = sl_NetAppStart(HTTP_SERVER_ID);

    return status;
}

/*!
    \brief Get the HTTP port

    \param[in]      none

    \return         UINT16 - HTTP port number

    \note

    \warning
*/
INT32 get_port_num (_NetAppHttpServerGetSet_port_num_t *port_num)
{
    UINT8 len = sizeof(_NetAppHttpServerGetSet_port_num_t);
    INT32 status = -1;

    /* Get port number*/
    status = sl_NetAppGet(HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_PORT_NUMBER,
                 &len, (UINT8 *)port_num);

    return status;
}

/*!
    \brief Enable/Disable the authentication check for http server,
           By default authentication is disabled.

    \param[in]      enable - false to disable and true to enable the authentication

    \return         None

    \note

    \warning
*/
INT32 set_authentication_check (UINT8 enable)
{
    _NetAppHttpServerGetSet_auth_enable_t auth_enable;
    INT32 status = -1;

    auth_enable.auth_enable = enable;
    status = sl_NetAppSet(HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_AUTH_CHECK,
                 sizeof(_NetAppHttpServerGetSet_auth_enable_t), (UINT8 *)&auth_enable);

    return status;
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      none

    \return         False (0) if disabled, True if enabled

    \note

    \warning
*/
INT32 get_auth_check_status(_NetAppHttpServerGetSet_auth_enable_t *auth_status)
{
    UINT8 len = sizeof(_NetAppHttpServerGetSet_auth_enable_t);
    INT32 status = -1;

    status = sl_NetAppGet(HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_AUTH_CHECK,
                                                &len, (UINT8 *) auth_status);

    return status;
}

/*!
    \brief Sets the Authentication user name for http server,
           Default value is "admin"


    \param[in]      auth_name- Pointer to string containing user name
                    to be set

    \return         None

    \note

    \warning
*/
INT32 set_auth_name (UINT8 *auth_name)
{
    INT32 status = -1;
    status = sl_NetAppSet (HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_AUTH_NAME,
                  strlen((const char *)auth_name), (UINT8 *) auth_name);

    return status;
}

/*!
    \brief Sets the authentication password for http server,
           Default value is "admin"

    \param[in]      auth_password- Pointer to string containing password
                    to be set

    \return         None

    \note

    \warning
*/
INT32 set_auth_password (UINT8 *auth_password)
{
    INT32 status = -1;
    status = sl_NetAppSet (HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_AUTH_PASSWORD,
                  strlen((const char *)auth_password), (UINT8 *) auth_password);

    return status;
}

/*!
    \brief Sets the authentication realm, default value is
           "Simple Link CC31xx"

    \param[in]      auth_realm- Pointer to string containing authentication
                    realm to be set

    \return         None

    \note

    \warning
*/
INT32 set_auth_realm (UINT8 *auth_realm)
{
    INT32 status = -1;
    status = sl_NetAppSet (HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_AUTH_REALM,
                  strlen((const char *)auth_realm), (UINT8 *) auth_realm);

    return status;
}

/*!
    \brief Get the authentication user name

    \param[in]      auth_name - Pointer to the string to store authentication
                    name

    \return         None

    \note

    \warning
*/
INT32 get_auth_name (UINT8 *auth_name)
{
    UINT8 len = MAX_AUTH_NAME_LEN;
    INT32 status = -1;

    status = sl_NetAppGet(HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_AUTH_NAME,
                 &len, (UINT8 *) auth_name);
    auth_name[len] = '\0';

    return status;
}

/*!
    \brief Get the authentication password

    \param[in]      auth_password - Pointer to the string to store
                    authentication password

    \return         None

    \note

    \warning
*/
INT32 get_auth_password (UINT8 *auth_password)
{
    UINT8 len = MAX_AUTH_PASSWORD_LEN;
    INT32 status = -1;

    status = sl_NetAppGet(HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_AUTH_PASSWORD,
                                                &len, (UINT8 *) auth_password);
    auth_password[len] = '\0';

    return status;
}

/*!
    \brief Get the authentication realm

    \param[in]      auth_realm - Pointer to the string to store authentication
                    realm

    \return         None

    \note

    \warning
*/
INT32 get_auth_realm (UINT8 *auth_realm)
{
    UINT8 len = MAX_AUTH_REALM_LEN;
    INT32 status = -1;

    status = sl_NetAppGet(HTTP_SERVER_ID, NETAPP_SET_GET_HTTP_OPT_AUTH_REALM,
                 &len, (UINT8 *) auth_realm);
    auth_realm[len] = '\0';

    return status;
}

/*!
    \brief Set the device URN, default value is "mysimplelink"

    \param[in]      device_urn- Pointer to string containing urn to be set

    \return         None

    \note

    \warning
*/
INT32 set_device_urn (UINT8 *device_urn)
{
    INT32 status = -1;
    status = sl_NetAppSet (DEVICE_CONFIG_ID, NETAPP_SET_GET_DEV_CONF_OPT_DEVICE_URN,
                  strlen((const char *)device_urn), (UINT8 *) device_urn);

    return status;
}

/*!
    \brief Get the device URN

    \param[in]      device_urn - Pointer to the string to store device urn

    \return         None

    \note

    \warning
*/
INT32 get_device_urn (UINT8 *device_urn)
{
    UINT8 len = MAX_DEVICE_URN_LEN;
    INT32 status = -1;

    status = sl_NetAppGet(DEVICE_CONFIG_ID, NETAPP_SET_GET_DEV_CONF_OPT_DEVICE_URN,
                 &len, (UINT8 *) device_urn);
    device_urn[len] = '\0';

    return status;
}


/*!
    \brief Sets the domain Name, default value is "mysimplelink.net"

    \param[in]      domain_name- Pointer to string containing domain to be set

    \return         None

    \note

    \warning        Domain name is used only in AP mode.
*/
INT32 set_domain_name (UINT8 *domain_name)
{
    INT32 status = -1;
    status = sl_NetAppSet (DEVICE_CONFIG_ID, NETAPP_SET_GET_DEV_CONF_OPT_DOMAIN_NAME,
                  strlen((const char *)domain_name), (UINT8 *) domain_name);

    return status;
}

/*!
    \brief Get the domain Name

    \param[in]      domain_name - Pointer to the string to store domain name

    \return         None

    \note

    \warning        Domain name is used only in AP mode.
*/
INT32 get_domain_name (UINT8 *domain_name)
{
    UINT8 len = MAX_DOMAIN_NAME_LEN;
    INT32 status = -1;

    status = sl_NetAppGet(DEVICE_CONFIG_ID, NETAPP_SET_GET_DEV_CONF_OPT_DOMAIN_NAME,
                 &len, (UINT8 *)domain_name);
    domain_name[len] = '\0';

    return status;
}

int main()
{
    INT32 retVal;
    unsigned char SecType = 0;

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initialize the LED */
    initLEDs();

    /* Initialize the Application UART interface */
    CLI_Configure();

    /* Initializing the CC3100 device */
    retVal = sl_Start(0, 0, 0);

    if(retVal == ROLE_AP)
    {
        /* wait for the IP acquire event, Not handling this event may cause
         * the SPI communication to fail */
        while (!(g_Status & IP_ACQUIRED))
        {
            _SlNonOsMainLoopTask();
        }
        g_Status &= ~IP_ACQUIRED;
    }
    else
    {
        /* Configure CC3100 to start in AP mode */
        sl_WlanSetMode(ROLE_AP);
    }

    /* Configure AP mode without security */
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SSID,
               strlen(SSID_NAME), (unsigned char *)SSID_NAME);

    SecType = SL_SEC_TYPE_OPEN;
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SECURITY_TYPE,
                                    1, (unsigned char *)&SecType);

    /* Restart the CC3100 */
    sl_Stop(0x00FF);
    sl_Start(0, 0, 0);

    /* Wait for IP acquire event */
    while (!(g_Status & IP_ACQUIRED))
    {
        _SlNonOsMainLoopTask();
    }

    /* Get authentication parameters */
    retVal = get_auth_name(g_auth_name);
    if(retVal < 0)
        return -1;

    retVal = get_auth_password(g_auth_password);
    if(retVal < 0)
        return -1;

    retVal = get_auth_realm(g_auth_realm);
    if(retVal < 0)
        return -1;

    CLI_Write((UINT8 *)"\r\nAuthentication parameters: ");
    CLI_Write((UINT8 *)"\r\nName = ");
    CLI_Write(g_auth_name);
    CLI_Write((UINT8 *)"\r\nPassword = ");
    CLI_Write(g_auth_password);
    CLI_Write((UINT8 *)"\r\nRealm = ");
    CLI_Write(g_auth_realm);

    /* Enable the Authentication */
    retVal = set_authentication_check(TRUE);
    if(retVal < 0)
        return -1;

    /* Get the domain name */
    retVal = get_domain_name(g_domain_name);
    if(retVal < 0)
        return -1;

    CLI_Write((UINT8 *)"\r\n\r\nDomain name = ");
    CLI_Write(g_domain_name);

    /* Get URN */
    retVal = get_device_urn(g_device_urn);
    if(retVal < 0)
        return -1;

    CLI_Write((UINT8 *)"\r\nDevice URN = ");
    CLI_Write(g_device_urn);

    /* Process the async events from the NWP */
    while(1)
    {
        _SlNonOsMainLoopTask();
    }
}
