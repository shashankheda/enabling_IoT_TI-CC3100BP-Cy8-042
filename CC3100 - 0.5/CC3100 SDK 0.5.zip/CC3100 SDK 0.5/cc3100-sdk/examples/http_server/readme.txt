For information on this example refer to:
docs\examples\http_server.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_HTTP_Server