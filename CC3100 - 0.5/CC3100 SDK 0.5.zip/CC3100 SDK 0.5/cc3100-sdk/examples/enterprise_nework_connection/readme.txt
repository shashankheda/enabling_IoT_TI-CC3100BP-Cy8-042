For information on this example refer to:
docs\examples\enterprise_nework_connection.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Enterprise_Network_Connection