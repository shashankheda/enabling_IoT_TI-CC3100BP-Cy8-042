For information on this example refer to:
docs\examples\get_weather.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Get_Weather_Application