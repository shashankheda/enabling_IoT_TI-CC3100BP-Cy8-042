/*
 * main.c - get weather details sample application
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include <string.h>
#include "simplelink.h"
#include "cli_uart.h"

#define SSID_NAME       "<ap-name>"         /* Access point name to connect to. */
#define SEC_TYPE        SL_SEC_TYPE_OPEN    /* Security type of the Access point */
#define PASSKEY         ""                  /* Password in case of secure AP */
#define PASSKEY_LEN     strlen(PASSKEY)     /* Password length in case of secure AP */

#define CITY_NAME       "<city>"

#define WEATHER_SERVER  "openweathermap.org"

#define PREFIX_BUFFER   "GET /data/2.5/weather?q="
#define POST_BUFFER     "&mode=xml&units=imperial HTTP/1.1\r\nHost:api.openweathermap.org\r\nAccept: */"
#define POST_BUFFER2    "*\r\n\r\n"

#define SMALL_BUF           32
#define MAX_SEND_BUF_SIZE   512
#define MAX_SEND_RCV_SIZE   1024

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02

}e_Status;
UINT8 g_Status = 0;

struct
{
    char Recvbuff[MAX_SEND_RCV_SIZE];
    char SendBuff[MAX_SEND_BUF_SIZE];

    char HostName[SMALL_BUF];
    char CityName[SMALL_BUF];

    unsigned long DestinationIP;
    int SockID;
}appData;

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         none

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
            g_Status |= CONNECTED;
        break;

        case SL_WLAN_DISCONNECT_EVENT:
            g_Status &= ~(1 << CONNECTION_STATUS_BIT | 1 << IP_AQUIRED_STATUS_BIT);
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_AQUIRED;
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
        SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}

/*!
    \brief This function Obtains the required data from the server

    \param[in]      none

    \return         None

    \note

    \warning
*/
void GetData()
{
    char *p_startPtr = NULL;
    char *p_endPtr = NULL;
    char* p_bufLocation = NULL;

    memset(appData.Recvbuff, 0, sizeof(appData.Recvbuff));

    /* Puts together the HTTP GET string. */
    p_bufLocation = appData.SendBuff;
    strcpy(p_bufLocation, PREFIX_BUFFER);

    p_bufLocation += strlen(PREFIX_BUFFER);
    strcpy(p_bufLocation, appData.CityName);

    p_bufLocation += strlen(appData.CityName);
    strcpy(p_bufLocation, POST_BUFFER);

    p_bufLocation += strlen(POST_BUFFER);
    strcpy(p_bufLocation, POST_BUFFER2);

    /* Send the HTTP GET string to the open TCP/IP socket. */
    sl_Send(appData.SockID, appData.SendBuff, strlen(appData.SendBuff), 0);

    /* Receive response */
    sl_Recv(appData.SockID, &appData.Recvbuff[0], MAX_SEND_RCV_SIZE, 0);
    appData.Recvbuff[strlen(appData.Recvbuff)] = '\0';

    /*Get ticker name*/
    p_startPtr = strstr(appData.Recvbuff, "name=");
    if( NULL != p_startPtr )
    {
        p_startPtr = p_startPtr + strlen("name=") + 1;
        p_endPtr = strstr(p_startPtr, "\">");
        if( NULL != p_endPtr )
        {
            *p_endPtr = 0;
        }
    }

    CLI_Write((unsigned char *)"\n************************ \n\r\n\r");
    CLI_Write((unsigned char *)"City: ");
    if(p_startPtr == NULL)
    {
        CLI_Write((unsigned char *)"N/A\n\r\n\r");
    }
    else
    {
        CLI_Write((unsigned char *)p_startPtr);
        CLI_Write((unsigned char *)"\n\r\n\r");
    }

    if(p_endPtr == NULL)
    {
        CLI_Write((unsigned char *)"Error during parsing the data.\r\n");
        return;
    }

    /* Get Temperature Value */
    p_startPtr = strstr(p_endPtr+1, "temperature value");
    if( NULL != p_startPtr )
    {
        p_startPtr = p_startPtr + strlen("temperature value") + 2;
        p_endPtr = strstr(p_startPtr, "\" ");
        if( NULL != p_endPtr )
        {
            *p_endPtr = 0;
        }
    }

    CLI_Write((unsigned char *)"Temperature: ");
    if(p_startPtr == NULL)
    {
        CLI_Write((unsigned char *)"N/A\n\r\n\r");
    }
    else
    {
        CLI_Write((unsigned char *)p_startPtr);
        CLI_Write((unsigned char *)" F\n\r\n\r");
    }

    /* Get weather */
    p_startPtr = strstr(p_endPtr+1, "weather number");
    if( NULL != p_startPtr )
    {
        p_startPtr = p_startPtr + strlen("weather number") + 14;
        p_endPtr = strstr(p_startPtr, "\" ");
        if( NULL != p_endPtr )
        {
            *p_endPtr = 0;
        }
    }

    CLI_Write((unsigned char *)"Weather Condition: ");
    if(p_startPtr == NULL)
    {
        CLI_Write((unsigned char *)"N/A\n\r\n\r");
    }
    else
    {
        CLI_Write((unsigned char *)p_startPtr);
        CLI_Write((unsigned char *)"\n\r\n\r");
    }

    CLI_Write((unsigned char *)"\n************************ \n\r\n\r");
}

/*!
    \brief Create TCP connection with openweathermap.org

    \param[in]      none

    \return         Socket descriptor for success otherwise negative

    \warning
*/
int CreateConnection()
{
    SlSockAddrIn_t  Addr;

    long sd = 0;
    long AddrSize = 0;
    short ret_val = 0;

    Addr.sin_family = SL_AF_INET;
    Addr.sin_port = sl_Htons(80);

    /* Change the DestinationIP endianity, to big endian */
    Addr.sin_addr.s_addr = sl_Htonl(appData.DestinationIP);

    AddrSize = sizeof(SlSockAddrIn_t);

    sd = sl_Socket(SL_AF_INET,SL_SOCK_STREAM, 0);
    if( sd < 0 )
    {
        CLI_Write((unsigned char *)"Error creating socket\n\r\n\r");
        return sd;
    }

    ret_val = sl_Connect(sd, ( SlSockAddr_t *)&Addr, AddrSize);
    if( ret_val < 0 )
    {
        /* error */
        CLI_Write((unsigned char *)"Error connecting to socket\n\r\n\r");
        return ret_val;
    }

    return sd;
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    The function will return only once we are connected and have acquired IP
    address

    \param[in]      None

    \return         0 for success and negative for error

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
int WlanConnect()
{
    SlSecParams_t secParams;
    int status = 0;

    secParams.Key = PASSKEY;
    secParams.KeyLen = PASSKEY_LEN;
    secParams.Type = SEC_TYPE;

    status = sl_WlanConnect(SSID_NAME, strlen(SSID_NAME), 0, &secParams, 0);
    if (status == 0)
    {
        while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
        {
            _SlNonOsMainLoopTask();
        }

        CLI_Write((unsigned char *)"Connected to ");
        CLI_Write((unsigned char *)SSID_NAME);
    }
    else
    {
        CLI_Write((unsigned char *)"Could not connect to ");
        CLI_Write((unsigned char *)SSID_NAME);
    }

    CLI_Write((unsigned char *)"\n\r\n\r");
    return status;
}

/*!
    \brief This function obtains the server IP address

    \param[in]      none

    \return         zero for success and -1 for error

    \warning
*/
int GetHostIP()
{
    int status = -1;

    status = sl_NetAppDnsGetHostByName(appData.HostName,
                                       strlen(appData.HostName),
                                       &appData.DestinationIP, SL_AF_INET);
    if (status < 0)
    {
        CLI_Write((unsigned char *)"Unable to reach Host\n\r\n\r");
        return -1;
    }

    return 0;
}

/*!
    \brief Get the Weather from server

    \param[in]      none

    \return         zero for success and -1 for error

    \warning
*/
static int GetWeather()
{
    strcpy(appData.HostName, WEATHER_SERVER);
    if(0 == GetHostIP())
    {
        appData.SockID = CreateConnection();
        if(appData.SockID < 0 ) return -1;

        memset(appData.CityName, 0x00, sizeof(appData.CityName));
        memcpy(appData.CityName, CITY_NAME, strlen(CITY_NAME));
        appData.CityName[strlen(CITY_NAME)] = '\0';

        GetData();
        sl_Close(appData.SockID);
    }

    CLI_Write((unsigned char *)"\n\rThank you!\n\r\n\r");
    return 0;
}

int main(void)
{
    INT32 retVal = -1;

    memset(&appData, 0, sizeof(appData));

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initialize the Application UART interface */
    CLI_Configure();

    CLI_Write((unsigned char *)"\n\rStarted Get-Weather Application\n\r\n\r");

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* Connect w/ AP */
    retVal = WlanConnect();
    if(retVal < 0) return -1;

    retVal = GetWeather();
    if(retVal < 0) return -1;

    sl_WlanDisconnect();
    while (1 == (g_Status & CONNECTED))
    {
        _SlNonOsMainLoopTask();
    }

    CLI_Write((unsigned char *)"\n\rThank you!\n\r\n\r");
    return 0;
}

