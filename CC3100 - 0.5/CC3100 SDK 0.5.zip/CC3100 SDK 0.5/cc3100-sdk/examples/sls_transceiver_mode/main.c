/*
 * main.c - sample code for using transceiver mode
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
#include <windows.h>
#include <stdio.h>

#include "simplelink.h"

#define POWER_LEVEL_TONE    1   /* Power level tone valid range 0-15 */
#define PREAMBLE            1   /* Preamble value 0- short, 1- long */
#define MAX_BUF_SIZE        256
#define MAX_BUF_RX_STAT     1500
#define BYTES_TO_RECV       1470

#ifdef SL_IF_TYPE_UART
#define COMM_PORT_NUM       10
SlUartIfParams_t params;
#endif /* SL_IF_TYPE_UART */

typedef struct{
    INT32 choice;
    INT32 channel;
    INT32 packets;
}UserIn;

char RawData_Ping[] = {
                       0x88,   /* version , type sub type */
                       0x02,   /* Frame control flag */
                       0x2C, 0x00,
                       0x00, 0x23, 0x75, 0x55,0x55, 0x55,   /* destination */
                       0x00, 0x22, 0x75, 0x55,0x55, 0x55,   /* bssid */
                       0x00, 0x22, 0x75, 0x55,0x55, 0x55,   /* source */
                       0x80, 0x42, 0x00, 0x00,
                       0xAA, 0xAA, 0x03, 0x00, 0x00, 0x00, 0x08, 0x00, /* LLC */
                       /*---- ip header start -----*/
                       0x45, 0x00, 0x00, 0x54, 0x96, 0xA1, 0x00, 0x00, 0x40, 0x01,
                       0x57, 0xFA,                          /* checksum */
                       0xc0, 0xa8, 0x01, 0x64,              /* src ip */
                       0xc0, 0xa8, 0x01, 0x65,              /* dest ip  */
                       /* payload - ping/icmp */
                       0x08, 0x00, 0xA5, 0x51,
                       0x5E, 0x18, 0x00, 0x00, 0x41, 0x08, 0xBB, 0x8D, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                       0x00, 0x00, 0x00, 0x00
                       };

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEventHandler)
{
    /* Not used in this application */
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    /* Not used in this application */
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
    SlHttpServerResponse_t *pHttpResponse)
{
    /* Not used in this application */
}

/*!
    \brief Read option fron the user

    \param[in]      none

    \return         int - user option value

    \note

    \warning
*/
INT32 GetUserNum(INT32 boundlow, INT32 boundhigh, INT32 pack, INT32 *p_flag)
{
    UINT8 input[MAX_BUF_SIZE] = {'\0'};
    INT32 user = -1;

    if (fgets(input, sizeof(input), stdin) != NULL)
    {
        user = atoi(input);
        if( !pack)
        {
            if (user > boundlow && user < boundhigh)
                *p_flag = 1;
            else
                printf("\nInvalid choice.\n");
        }
        else
        {
            if (user > 0)
                *p_flag = 1;
            else
                printf("\nInvalid choice.\n");
        }
    }

    return user;
}

/*!
    \brief Get the Raw socket parameters from the user

    \param[in]      none

    \return         UserIn - structure containg Raw socket parameters

    \note

    \warning
*/
UserIn UserInput()
{
    UserIn User;
    INT32 flag = 0;

    memset(&User, 0, sizeof(User));

    while (!flag)
    {
        printf("Options:\n");
        printf("1. Send packets.\n");
        printf("2. Collect statistics about received packets.\n");
        printf("Please enter the option you would like to use: \n");
        User.choice = GetUserNum(0, 3, 0, &flag);
        printf("\n");
    }

    flag = 0;
    while (!flag)
    {
        printf("Enter a channel between 1 and 13 to use: \n");
        User.channel = GetUserNum(0, 14, 0, &flag);
        printf("\n");
    }

    flag = 0;

    if (User.choice == 1)
    {
        printf("Enter the number of packets to send : \n");
        User.packets = GetUserNum(0, 0, 1, &flag);
        printf("\n");
    };

    return User;
}

/*!
    \brief Entering raw Transmitter\Receiver mode in order to send raw data
           over the WLAN PHY

    This function shows how to send raw data, in this case ping packets over
    the air in transmitter mode.

    \param[in]      Channel - number on which the data will be sent
    \param[in]      rate    - Rate for tx
    \param[in]      numberOfPackets - packets to be send
    \param[in]      interval - interval between each packet, should be greater
                    than 50ms.

    \return         none

    \warning        We must be disconnected from WLAN AP in order to succeed
                    changing to transmitter mode
*/
void TxContinues(INT32 channel, SlRateIndex_e rate,
                 UINT32 numberOfPackets, DWORD interval)
{
    INT16 sd = -1;
    INT16 len = -1;
    UINT32 cnt = 0;

    sd = sl_Socket(SL_AF_RF, SL_SOCK_RAW, channel);
    if(sd < 0)
    {
        printf("Error In Creating the Socket\n");
        return;
    }

    printf("Transmitting pinging data...\n");
    len = sizeof(RawData_Ping);
    for(cnt = 0 ; cnt < numberOfPackets; cnt++)
    {
        sl_Send(sd, RawData_Ping, len,
                SL_RAW_RF_TX_PARAMS(channel, rate, POWER_LEVEL_TONE, PREAMBLE));
        Sleep(interval);
    }

    sl_Close(sd);
    printf("Transmitting complete.\n");
}

/*!
    \brief Entering raw Transmitter\Receiver mode in order to perform Rx
           statistic over a specific WLAN channel


    \param[in]      Channel number on which the statistics will be calculated

    \return         none

    \note

    \warning        We must be disconnected from WLAN AP in order to succeed
                    changing to Receiver mode
*/
void RxStatisticsCollect(int channel)
{
    SlGetRxStatResponse_t rxStatResp;
    UINT8 buffer[MAX_BUF_RX_STAT] = {'\0'};
    UINT8 var[MAX_BUF_SIZE] = {'\0'};

    INT32 idx = -1;
    INT16 sd = -1;

    memset(&rxStatResp, 0, sizeof(rxStatResp));

    sd = sl_Socket(SL_AF_RF,SL_SOCK_RAW,channel);
    if(sd < 0)
    {
        printf("Error In Creating the Socket\n");
        return;
    }

    sl_Recv(sd, buffer, BYTES_TO_RECV, 0);

    printf("Press \"Enter\" to start collecting statistics.\n");
    fgets(var, sizeof(var), stdin);
    sl_WlanRxStatStart();

    printf("Press \"Enter\" to get the statistics.\n");
    fgets(var, sizeof(var), stdin);
    sl_WlanRxStatGet(&rxStatResp, 0);

    printf("\n\n*********************Rx Statistics**********************\n\n");
    printf("Received Packets - %d\n",rxStatResp.ReceivedValidPacketsNumber);
    printf(" Received FCS - %d\n",rxStatResp.ReceivedFcsErrorPacketsNumber);
    printf(" Received PLCP - %d\n",rxStatResp.ReceivedPlcpErrorPacketsNumber);
    printf("Average Rssi for management: %d    Average Rssi for other packets: %d\n",
                    rxStatResp.AvarageMgMntRssi,rxStatResp.AvarageDataCtrlRssi);
    for(idx = 0 ; idx < SIZE_OF_RSSI_HISTOGRAM ; idx++)
    {
        printf("Rssi Histogram cell %d is %d\n", idx, rxStatResp.RssiHistogram[idx]);
    }

    printf("\n");
    for(idx = 0 ; idx < NUM_OF_RATE_INDEXES; idx++)
    {
        printf("Rate Histogram cell %d is %d\n", idx, rxStatResp.RateHistogram[idx]);
    }

    printf("The data was sampled in %u microseconds.\n",
          ((unsigned int)rxStatResp.GetTimeStamp - rxStatResp.StartTimeStamp));
    printf("\n\n*******************End Rx Statistics********************\n");

    sl_WlanRxStatStop();
    sl_Close(sd);
}

int main()
{
    UINT8 input[MAX_BUF_SIZE];
    UserIn User;

    INT32 flag = 1;
    INT32 first = 0;

    INT8 *pConfig = 0;

#ifdef SL_IF_TYPE_UART
    params.BaudRate = 115200;
    params.FlowControlEnable = 1;
    params.CommPort = COMM_PORT_NUM;

    pConfig = (char *)&params;
#endif /* SL_IF_TYPE_UART */

    /* This line is for Eclipse CDT only due to a known bug in console buffering
     * See https://bugs.eclipse.org/bugs/show_bug.cgi?id=173732 */
    setvbuf(stdout, NULL, _IONBF, 0);

    /* Initializing the CC3100 device */
    sl_Start(NULL, pConfig, NULL);

    while(flag)
    {
        User = UserInput();
        switch(User.choice)
        {
            case 1:
                TxContinues(User.channel, RATE_11M, User.packets, 100);
                break;
            case 2:
                RxStatisticsCollect(User.channel);
                break;
        }

        printf("\nEnter \"1\" to restart or \"0\" to quit: \n");
        fgets(input, sizeof(input), stdin);
        printf("\n");
        flag = atoi(input);

        first = 1;
    }
}
