For information on this example refer to:
docs\examples\sls_transceiver_mode.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_SLS_Transceiver_Mode_Application