For information on this example refer to:
docs\examples\out_of_box.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Out_of_Box_Application