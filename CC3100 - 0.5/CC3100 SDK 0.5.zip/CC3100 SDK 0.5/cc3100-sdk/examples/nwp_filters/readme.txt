For information on this example refer to:
docs\examples\nwp_filters.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_NWP_Filter_Application