/*
 * main.c - NWP filter application
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/



#include "simplelink.h"

#define SSID_NAME       "<ap-name>"  /* Open AP name to connect to. */
#define PORT_NUM        5001         /* Port number to be used by server socket */
#define IP_ADDR_LENGTH  4

#define NO_OF_PACKETS 1000
#define BUF_SIZE        1400
union
{
    UINT8 BsdBuf[BUF_SIZE];
    UINT32 demobuf[BUF_SIZE/4];
} uBuf;

enum
{
    CONNECTED = 0x1,
    IP_ACQUIRED = 0x2
}e_Stauts;

UINT8 g_Status = 0;

/* MAC address and IP address of the device to be filtered */
UINT8 g_MacAddress[SL_MAC_ADDR_LEN] = {0x00,0x00,0x00,0x00,0x00,0x00};
UINT8 g_IpAddress[IP_ADDR_LENGTH] = {0x00, 0x00, 0x00, 0x00};

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
      case SL_WLAN_CONNECT_EVENT:
        g_Status |= CONNECTED;
        break;

      case SL_WLAN_DISCONNECT_EVENT:
        g_Status &= ~(CONNECTED + IP_ACQUIRED);
        break;
      default:
        break;
    }
}


/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
      case SL_NETAPP_IPV4_ACQUIRED:
        g_Status |= IP_ACQUIRED;
        break;
      default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
        SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this application */
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    This code example assumes the AP doesn't use WIFI security.
    The function will return only once we are connected and have acquired IP
    address

    \param[in]      None

    \return         None

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
static void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = "";
    secParams.KeyLen = 0;
    secParams.Type = SL_SEC_TYPE_OPEN;

    sl_WlanConnect(SSID_NAME, strlen(SSID_NAME), 0, &secParams, 0);

    while (!(g_Status & IP_ACQUIRED ) || !(g_Status & CONNECTED))
    {
        _SlNonOsMainLoopTask();
    }
}

/*!
\brief Remove all pre-defined filters

This function removes all pre-defined rx filters. It's also possible to remove
a specific filter by assigning only the required indexes in FilterIdMask

\param[in]          None

\return             0 for success, -ve otherwise.

\note

\warning
*/
static INT16 RemoveAllFilters()
{
    _WlanRxFilterOperationCommandBuff_t     RxFilterIdMask;
    INT16 retVal;

    /* Remove  all 64 filters (8*8) */
    memset(RxFilterIdMask.FilterIdMask, 0xFF, 8);
    retVal = sl_WlanRxFilterSet(SL_REMOVE_RX_FILTER, (unsigned char *)&RxFilterIdMask,
                       sizeof(_WlanRxFilterOperationCommandBuff_t));

    return retVal;
}

/*!
\brief Enable/Activate all pre-defined filters

This function activates all pre-defined rx filters. It's also possible to
activate a specific filter by assigning only the required indexes in
FilterIdMask

\param[in]          None

\return             0 for success, -ve otherwise.

\note

\warning
*/
static INT16 EnableAllFilters()
{
    _WlanRxFilterOperationCommandBuff_t     RxFilterIdMask ;
    INT16 retVal;

    /* Enable all 64 filters (8*8) - bit=1 represents enabled filter */
    memset( RxFilterIdMask.FilterIdMask, 0xFF , 8);
    retVal = sl_WlanRxFilterSet(SL_ENABLE_DISABLE_RX_FILTER,
                       (unsigned char *)&RxFilterIdMask,
                       sizeof(_WlanRxFilterOperationCommandBuff_t));
    return retVal;
}

/*!
\brief Create/Define filters

This function creates rx filters. Two filters are defined in this example:
(1) Drop incoming packets according to source MAC address
(2) Drop incoming packets according to source IP address

\param[in]          None

\return             0 on success, -1 on failure

\note

\warning
*/
static INT16 CreateFilters()
{
    SlrxFilterFlags_t       FilterFlags;
    SlrxFilterRule_t        Rule;
    SlrxFilterTrigger_t     Trigger;
    SlrxFilterAction_t      Action;

    INT16                   RetVal = 0;
    SlrxFilterID_t          FilterId = 0;
    SlrxFilterRuleType_t    RuleType = 0;

    UINT8                   MacMAsk[SL_MAC_ADDR_LEN]  = {0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF};
    UINT8                   IPMask[IP_ADDR_LENGTH]   = {0xFF, 0xFF, 0xFF, 0xFF};

    /*************************************************************************/
    /* Build filter to drop incoming packets according to source MAC address */
    /*************************************************************************/

    /* define filter as parent.
     * further filters can be defined as nodes/leafs {1, 2,...} */
    Trigger.ParentFilterID = 0;

    /* no trigger to activate the filter.
     * will  be active upon connection state and role */
    Trigger.Trigger = NO_TRIGGER;

    /* connection state and role */
    Trigger.TriggerArgConnectionState.IntRepresentation = RX_FILTER_CONNECTION_STATE_STA_CONNECTED;
    Trigger.TriggerArgRoleStatus.IntRepresentation = RX_FILTER_ROLE_STA;

    /*header and Combination types are only supported.
    * Combination for logical AND/OR between two filters */
    RuleType = HEADER;

    Rule.HeaderType.RuleHeaderfield = MAC_SRC_ADDRESS_FIELD;
    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB6BytesRuleArgs[0],
                                        g_MacAddress , SL_MAC_ADDR_LEN);
    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                        MacMAsk , SL_MAC_ADDR_LEN);

    Rule.HeaderType.RuleCompareFunc = COMPARE_FUNC_EQUAL;

    /* Action */
    Action.ActionType.IntRepresentation = RX_FILTER_ACTION_DROP;

    FilterFlags.IntRepresentation = RX_FILTER_BINARY;

    RetVal = sl_WlanRxFilterAdd(RuleType, FilterFlags, &Rule, &Trigger,
                                                        &Action, &FilterId);
    if (RetVal < 0)
        return -1;

    /*************************************************************************/
    /* Build filter to drop incoming packets according to source IP address  */
    /*************************************************************************/

    /* define filter as parent.
     * further filters can be defined as nodes/leafs {1, 2,...} */
    Trigger.ParentFilterID = 0;

    /* no trigger to activate the filter.
    * will  be active upon connection state and role */
    Trigger.Trigger = NO_TRIGGER;

    /* connection state and role */
    Trigger.TriggerArgConnectionState.IntRepresentation = RX_FILTER_CONNECTION_STATE_STA_CONNECTED;
    Trigger.TriggerArgRoleStatus.IntRepresentation = RX_FILTER_ROLE_STA;

    /*header and Combination types are only supported.
    * Combination for logical AND/OR between two filters */
    RuleType = HEADER;

    Rule.HeaderType.RuleHeaderfield = IPV4_SRC_ADRRESS_FIELD;
    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB4BytesRuleArgs[0],
                                                    g_IpAddress , IP_ADDR_LENGTH);
    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                    IPMask, IP_ADDR_LENGTH);

    Rule.HeaderType.RuleCompareFunc = COMPARE_FUNC_EQUAL;

    /* Action */
    Action.ActionType.IntRepresentation = RX_FILTER_ACTION_DROP;

    FilterFlags.IntRepresentation = RX_FILTER_BINARY;

    RetVal = sl_WlanRxFilterAdd(RuleType, FilterFlags, &Rule, &Trigger,
                                                        &Action, &FilterId);
    if (RetVal < 0)
            return -1;

    return 0;
}


/*!
\brief Opening a server side socket and receiving data

This function opens a TCP socket in Listen mode and waits for an incoming TCP
connection. If a socket connection is established then the function will try to
read 1000 TCP packets from the connected client.

\param[in]          port number on which the server will be listening on

\return             0 on success, -1 on Error.

\note               This function will wait for an incoming connection till one
                    is established

\warning
*/
static INT16 BsdTcpServer(UINT16 Port)
{
    SlSockAddrIn_t  Addr;
    SlSockAddrIn_t  LocalAddr;
    SlTimeval_t     timeVal;

    UINT16          idx = 0;
    UINT16          AddrSize = 0;
    INT16           SockID = 0;
    INT16           Status = 0;
    INT16           newSockID = 0;
    UINT16          LoopCount = 0;
    INT32           nonBlocking = 1;

    for (idx=0 ; idx<BUF_SIZE ; idx++)
    {
        uBuf.BsdBuf[idx] = (char)(idx % 10);
    }

    LocalAddr.sin_family = SL_AF_INET;
    LocalAddr.sin_port = sl_Htons((UINT16)Port);
    LocalAddr.sin_addr.s_addr = 0;

    SockID = sl_Socket(SL_AF_INET,SL_SOCK_STREAM, 0);
    if( SockID < 0 )
    {
        /* error */
        return -1;
    }

    AddrSize = sizeof(SlSockAddrIn_t);
    Status = sl_Bind(SockID, (SlSockAddr_t *)&LocalAddr, AddrSize);
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    Status = sl_Listen(SockID, 0);
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    Status = sl_SetSockOpt(SockID, SL_SOL_SOCKET, SL_SO_NONBLOCKING,
                           &nonBlocking, sizeof(nonBlocking));
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    newSockID = SL_EAGAIN;
    while( newSockID < 0 )
    {
        newSockID = sl_Accept(SockID, ( struct SlSockAddr_t *)&Addr,
                                                    (SlSocklen_t*)&AddrSize);
        if( newSockID == SL_EAGAIN )
        {
            _SlNonOsMainLoopTask();
        }
        else if( newSockID < 0 )
        {
            sl_Close(SockID);
            return -1;
        }
    }

    timeVal.tv_sec = 1;
    timeVal.tv_usec = 0;
    if( newSockID >= 0 )
    {
        Status = sl_SetSockOpt(newSockID, SL_SOL_SOCKET, SL_SO_RCVTIMEO,
                                &timeVal, sizeof(timeVal));
        if( Status < 0 )
        {
            sl_Close(SockID);
            sl_Close(newSockID);
            return -1;
        }
    }

    while (LoopCount < NO_OF_PACKETS)
    {
        Status = sl_Recv(newSockID, uBuf.BsdBuf, BUF_SIZE, 0);
        if( Status <= 0 )
        {
            sl_Close(newSockID);
            sl_Close(SockID);
            return -1;
        }

        LoopCount++;
    }


    sl_Close(newSockID);
    sl_Close(SockID);

    return 0;
}


int main(void)
{
    INT16 RetVal = 0;

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* This function creates two different filters: */
    /* (1) Filter packets according to remote MAC */
    /* (2) Filter packets according to remote IP address */
    RetVal = CreateFilters();
    if (RetVal < 0)
        return -1;

    /* Activate pre-defined filters - The filters will be deleted upon reset */
    EnableAllFilters();

    /* Connecting to WLAN AP
       After this call we will be connected and have IP address */
    WlanConnect();

    /** After calling this function, you can start sending data to CC3100 IP
      * address on PORT_NUM. TCP connection will be refused if remote MAC/IP is
      * of the filtered. It's also possible to enable the filters after TCP
      * connection, resulting in TCP packets to not being received */
    BsdTcpServer(PORT_NUM);

    /* Remove all the filters */
    RemoveAllFilters();

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
