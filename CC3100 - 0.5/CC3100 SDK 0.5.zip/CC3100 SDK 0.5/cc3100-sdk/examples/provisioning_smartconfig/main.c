/*
 * main.c - smartconfig sample application
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "simplelink.h"

#define WLAN_DEL_ALL_PROFILES        0xff


enum
{
    CONNECTED = 0x1,
    IP_ACQUIRED = 0x2,
    SMARTCONFIG_DONE = 0x4,
    SMARTCONFIG_STOPPED = 0x8
}e_Stauts;

UINT8 g_Status = 0;

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
      case SL_WLAN_CONNECT_EVENT:
        g_Status |= CONNECTED;
        break;

      case SL_WLAN_DISCONNECT_EVENT:
        g_Status &= ~(CONNECTED + IP_ACQUIRED);
        break;

      case SL_WLAN_SMART_CONFIG_START_EVENT:
        /** SmartConfig operation finished
          * The new SSID that was acquired is:
          * pWlanEventHandler->EventData.smartConfigStartResponse.ssid
          * We have the possibility that also a private token was sent to the Host:
          * if(pWlanEventHandler->EventData.smartConfigStartResponse.private_token_len)
          * then the private token is populated:
          * pWlanEventHandler->EventData.smartConfigStartResponse.private_token
          */
        g_Status |= (SMARTCONFIG_DONE + SMARTCONFIG_STOPPED);
        break;

      case SL_WLAN_SMART_CONFIG_STOP_EVENT:
        /* SmartConfig stop operation was completed */
        g_Status |= SMARTCONFIG_STOPPED;
        g_Status &= ~SMARTCONFIG_DONE;
        break;

      default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
      case SL_NETAPP_IPV4_ACQUIRED:
        g_Status |= IP_ACQUIRED;
        break;

      default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
        SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this application */
}

/*!
    \brief Connecting to a WLAN Access point using SmartConfig provisioning

    This function enables SmartConfig provisioning for adding a new connection
    profile to CC3100. Since we have set the connection policy to Auto, once
    SmartConfig is complete, CC3100 will connect automatically to the new
    connection profile added by smartConfig.

    \param[in]      None

    \return         None

    \note

    \warning        If the WLAN connection fails or we don't acquire an IP
                    address, We will be stuck in this function forever.
*/
static void SmartConfigConnect()
{
    UINT8 policyVal = 0;

    /* Clear all profiles */
    /* This is of course not a must, it is used in this example to make sure
    * we will connect to the new profile added by SmartConfig
    */
    sl_WlanProfileDel(WLAN_DEL_ALL_PROFILES);

    /* set AUTO policy */
    sl_WlanPolicySet(SL_POLICY_CONNECTION,
                     SL_CONNECTION_POLICY(1, 0, 0, 0, 0),
                     &policyVal,
                     1);    /*PolicyValLen*/

    /* Start SmartConfig
     * This example uses the unsecured SmartConfig method
     */
    sl_WlanSmartConfigStart(0,                          /* groupIdBitmask */
                            SMART_CONFIG_CIPHER_NONE,   /* cipher */
                            0,                          /* publicKeyLen */
                            0,                          /* group1KeyLen */
                            0,                          /* group2KeyLen */
                            (const unsigned char *)"",  /* publicKey */
                            (const unsigned char *)"",  /* group1Key */
                            (const unsigned char *)""); /* group2Key */

    /* pending on connection success and DHCP success */
    while (!(g_Status & IP_ACQUIRED) || !(g_Status & CONNECTED))
    {
        _SlNonOsMainLoopTask();
    }
}


int main(void)
{
    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* Connect to our AP using SmartConfig method */
    SmartConfigConnect();

    /* Delete all profiles */
    sl_WlanProfileDel(WLAN_DEL_ALL_PROFILES);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
