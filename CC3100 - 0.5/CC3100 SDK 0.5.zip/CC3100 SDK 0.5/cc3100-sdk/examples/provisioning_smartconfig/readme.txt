For information on this example refer to:
docs\examples\provisioning_smartconfig.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Provisioning_Smart_Config