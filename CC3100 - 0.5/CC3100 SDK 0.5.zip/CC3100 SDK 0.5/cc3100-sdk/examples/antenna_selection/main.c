/*
 * main.c - sample application for antenna selection
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 * All rights reserved. Property of Texas Instruments Incorporated.
 * Restricted rights to use, duplicate or disclose this code are
 * granted through contract.
 *
 * The program may not be used without the written permission of
 * Texas Instruments Incorporated or against the terms and conditions
 * stipulated in the agreement under which this program has been supplied,
 * and under no circumstances can it be used with non-TI connectivity device.
 *
 */

#include <string.h>
#include "simplelink.h"
#include "cli_uart.h"


#define SSID_NAME       "<ap-name>"

#define PASSKEY         ""
#define SEC_TYPE        SL_SEC_TYPE_OPEN

#define RSSI_THRESHOLD_VALUE  -110
#define SCAN_TABLE_SIZE   20
#define RSSI_BUF_SIZE     5
#define SCAN_INTERVAL     60

enum
{
    CONNECTED = 0x1,
    IP_ACQUIRED = 0x2
}e_Stauts;

UINT8 g_Status = 0;

Sl_WlanNetworkEntry_t netEntries[SCAN_TABLE_SIZE];
const UINT8 digits[] = "0123456789";


/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
            g_Status |= CONNECTED;
            break;
        case SL_WLAN_DISCONNECT_EVENT:
            g_Status &= ~(CONNECTED + IP_ACQUIRED);
            break;
        default:
            break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_ACQUIRED;
            break;
        default:
            break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *HttpServerEvent,
                                  SlHttpServerResponse_t *HttpServerResponse)
{
    /* Unused in this application */
}

/*!
    \brief Convert integer to ASCII in decimal base

    \param[in]      cNum -  input integer number to convert
    \param[in]      cString -  pointer to output string

    \return         number of ASCII characters

    \note

    \warning
*/
UINT16 itoa(INT16 cNum, UINT8 *cString)
{
    UINT8* ptr = 0;
    INT16 uTemp = 0;
    UINT16 length = 0;

    /* value 0 is a special case */
    if (cNum == 0)
    {
        length = 1;
        *cString = '0';

        return length;
    }

    if(cNum < 0)
    {
        length++;
        *cString = '-';
        cNum *= -1;
    }

    uTemp = cNum;

    /* Find out the length of the number, in decimal base */
    while (uTemp > 0)
    {
        uTemp /= 10;
        length++;
    }

    /* Do the actual formatting, right to left */
    uTemp = cNum;
    ptr = cString + length;
    while (uTemp > 0)
    {
        --ptr;
        *ptr = digits[uTemp % 10];
        uTemp /= 10;
    }

    return length;
}

/*!
    \brief This function Get the signal strength for a SSID

    \param[in]      none

    \return         RSSI value

    \note

    \warning
*/
static INT8 GetSignalStrength()
{
    UINT8   policyOpt = 0;
    UINT32  IntervalVal = SCAN_INTERVAL;
    INT16 retVal = 0;
    INT16 idx = 0;

    policyOpt = SL_CONNECTION_POLICY(0, 0, 0, 0, 0);
    retVal = sl_WlanPolicySet(SL_POLICY_CONNECTION , policyOpt, NULL, 0);
    if(retVal < 0)
    {
        /* Error */
        return (RSSI_THRESHOLD_VALUE-1);
    }

    /* enable scan */
    policyOpt = SL_SCAN_POLICY(1);

    /* set scan policy - this starts the scan */
    retVal = sl_WlanPolicySet(SL_POLICY_SCAN , policyOpt,
                            (UINT8 *)(&IntervalVal), sizeof(IntervalVal));
    if(retVal < 0)
    {
        /* Error */
        return (RSSI_THRESHOLD_VALUE-1);
    }

    /* delay 1 second to verify scan is started */
    Delay(1000);

    memset(netEntries, '\0', (SCAN_TABLE_SIZE * sizeof(Sl_WlanNetworkEntry_t)));

    /* retVal indicates the valid number of entries */
    /* The scan results are occupied in netEntries[] */
    retVal = sl_WlanGetNetworkList(0, SCAN_TABLE_SIZE, &netEntries[0]);

    /* Stop the scan */
    policyOpt = SL_SCAN_POLICY(0);

    /* set scan policy - this will stop the scan the scan */
    sl_WlanPolicySet(SL_POLICY_SCAN , policyOpt,
                            0, 0);

    for(idx=0; idx< retVal; idx++)
    {
        if(strcmp((const char *)netEntries[idx].ssid, SSID_NAME) == 0)
            return (netEntries[idx].rssi);
    }

    return (RSSI_THRESHOLD_VALUE-1);
}

/*!
    \brief This function selects the antenna with better signal strength

    \param[in]      none

    \return         -1 if AP is not available at both antenna, 0 otherwise

    \note

    \warning
*/
static INT16 SelectAntenna()
{
    INT8 Ant1_RSSI = 0;
    INT8 Ant2_RSSI = 0;
    UINT8 pBuff[RSSI_BUF_SIZE] = {'\0'};

    CLI_Write((UINT8 *)"AP Configured: ");
    CLI_Write((UINT8 *)SSID_NAME);
    CLI_Write((UINT8 *)"\r\n\r\n");

    CLI_Write((UINT8 *)"Selecting antenna 1\r\n");
    /* Switch to Antenna 1 */
    SelAntenna(ANT1);

    /* Get signal strength at Antenna 1 */
    Ant1_RSSI = GetSignalStrength();
    memset(pBuff, '\0', RSSI_BUF_SIZE);
    itoa((int)Ant1_RSSI,pBuff);
    CLI_Write((UINT8 *)"RSSI value: ");
    CLI_Write(pBuff);
    CLI_Write((UINT8 *)"\r\n\r\n");

    CLI_Write((UINT8 *)"Selecting antenna 2\r\n");
    /*Switch to Antenna 2 */
    SelAntenna(ANT2);

    /* Get Signal Strength at Antenna 2 */
    Ant2_RSSI = GetSignalStrength();
    memset(pBuff, '\0', RSSI_BUF_SIZE);
    itoa((int)Ant2_RSSI,pBuff);
    CLI_Write((UINT8 *)"RSSI value: ");
    CLI_Write(pBuff);
    CLI_Write((UINT8 *)"\r\n\r\n");

    if(Ant2_RSSI < RSSI_THRESHOLD_VALUE  && Ant1_RSSI < RSSI_THRESHOLD_VALUE)
    {
        CLI_Write((UINT8 *)"Unable to find AP: ");
        CLI_Write((UINT8 *)SSID_NAME);
        CLI_Write((UINT8 *)"\r\n\r\n");
        CLI_Write((UINT8 *)"Continuing with antenna 1\r\n");

        /*Select Antenna 1 */
        SelAntenna(ANT1);
        return -99;
    }
    /* switch to antenna with better signal strength */
    if(Ant1_RSSI > Ant2_RSSI)
    {
        SelAntenna(ANT1);
        CLI_Write((UINT8 *)"Antenna 1 Selected\r\n");
    }
    else
    {
        CLI_Write((UINT8 *)"Antenna 2 Selected\r\n");
    }

    return 0;
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    This code example assumes the AP doesn't use WIFI security.
    The function will return once we are connected and have acquired IP address

    \param[in]  None

    \return     None

    \note

    \warning    If the WLAN connection fails or we don't acquire an IP address,
                We will be stuck in this function forever.
*/
INT32 WlanConnect()
{
    SlSecParams_t secParams;
    INT32 retVal = 0;

    secParams.Key = PASSKEY;
    secParams.KeyLen = strlen(PASSKEY);
    secParams.Type = SEC_TYPE;

    retVal = sl_WlanConnect(SSID_NAME, strlen(SSID_NAME), 0, &secParams, 0);
    if (retVal < 0) return retVal;

    while (!(g_Status & IP_ACQUIRED) || !(g_Status & CONNECTED))
    {
        _SlNonOsMainLoopTask();
    }

    return retVal;
}

int main(void)
{
    INT32 retVal = 0;

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initialize the Application Uart Interface */
    CLI_Configure();

    CLI_Write((UINT8 *)"\r\nStarting Antenna Selection Application \r\n\r\n");

    /* Initialize the antenna selection GPIO */
    initAntSelGPIO();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    while(1) /* Break on a failure */
    {
        /* Select Antenna with better signal strength*/
        retVal = SelectAntenna();
        if(retVal < 0)
        {
            if (!(retVal == -99))
                break;

            /* Else, continue w/ Antenna 1 since RSSI w/ both antenna is below threshold */
        }

        /** Connecting to WLAN AP - Set with static parameters defined at the top
          * After this call we will be connected and have IP address
          */
        retVal = WlanConnect();
        if(retVal < 0) break;

        CLI_Write((UINT8 *)"Connected to AP ");
        CLI_Write((UINT8 *)SSID_NAME);
        CLI_Write("\r\n\r\n");

        /** In case the device get disconnected from the AP, SelectAntenna() followed
          * by WlanConnect() can be called to reselect the antenna with better signal
          * strength and connect to AP.
          */
        while(1 == (g_Status & CONNECTED))
        {
            _SlNonOsMainLoopTask();
        }
    }

    return 0;
}
