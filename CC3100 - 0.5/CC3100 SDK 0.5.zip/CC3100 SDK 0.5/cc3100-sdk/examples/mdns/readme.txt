For information on this example refer to:
docs\examples\mdns.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_mDNS