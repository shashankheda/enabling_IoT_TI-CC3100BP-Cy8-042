/*
 * main.c - mDNS multicast sample application
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "simplelink.h"

#define SSID_NAME "<ap_name>"        /* Open AP name to connect to. */

/* Name of the Service to get.
   This service should be broadcasted from different device */
#define DNS_SD_SERVICE  "service-4._ipp._tcp.local"

/*  Services to be broadcasted */
#define MDNS_SERVICE_1  "cc3100-service-1._ipp._tcp.local"
#define MDNS_SERVICE_2  "cc3100-service-2._ftp._tcp.local"
#define MDNS_SERVICE_3  "cc3100-service-3._ipp._udp.local"

/* Service text */
#define MDNS_TEXT_1     "dev=CC3100"
#define MDNS_TEXT_2     "dev=CC31xx"
#define MDNS_TEXT_3     "vendor=texas instruments"

#define MDNS_PORT_1     1000
#define MDNS_PORT_2     600
#define MDNS_PORT_3     5353

#define TTL             2000
#define UNIQUE_SERVICE  1       /* Set 1 for unique services, 0 otherwise */
#define MAX_TEXT_LEN    120

enum
{
    CONNECTED = 0x1,
    IP_ACQUIRED = 0x2
}e_Stauts;

UINT8 g_Status = 0;

unsigned short ulTextLen = MAX_TEXT_LEN;
char pText[MAX_TEXT_LEN];

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvent)
{
    switch(pWlanEvent->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
            g_Status |= CONNECTED;
            break;

        case SL_WLAN_DISCONNECT_EVENT:
            g_Status &= ~(CONNECTED + IP_ACQUIRED);
            break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_ACQUIRED;
            break;

        default:
            break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
        SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in current application */
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    This code example assumes the AP doesn't use WIFI security.
    The function will return only once we are connected and have acquired IP
    address

    \param[in]      None

    \return         None

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
static void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = "";
    secParams.KeyLen = 0;
    secParams.Type = SL_SEC_TYPE_OPEN;

    sl_WlanConnect(SSID_NAME,strlen(SSID_NAME),0,&secParams,0);
    while (!(g_Status & IP_ACQUIRED ) || !(g_Status & CONNECTED))
    {
        _SlNonOsMainLoopTask();
    }
}

int main()
{
    UINT32 ipAdd = 0;
    UINT32 port = 0;
    INT16 Status = -1;

    /* Stop Watch Dog Timer */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initializing the CC3100 device */
    sl_Start(NULL, NULL, NULL);

    /* Connecting to WLAN AP - Set with static parameters defined at the top
       After this call we will be connected and have IP address */
    WlanConnect();

    /* If Services are already registered Unregister them */
    Status = sl_NetAppMDNSUnRegisterService(MDNS_SERVICE_1,strlen(MDNS_SERVICE_1));
    Status = sl_NetAppMDNSUnRegisterService(MDNS_SERVICE_2,strlen(MDNS_SERVICE_2));
    Status = sl_NetAppMDNSUnRegisterService(MDNS_SERVICE_3,strlen(MDNS_SERVICE_3));

    /*
     * Register three new services, broadcast of services will start as soon
     * as they are registered
     */
    Status = sl_NetAppMDNSRegisterService(MDNS_SERVICE_1,strlen(MDNS_SERVICE_1),
                                          MDNS_TEXT_1,strlen(MDNS_TEXT_1),
                                          MDNS_PORT_1, TTL, UNIQUE_SERVICE);
    if(Status < 0)
    {
        return -1;
    }
    Status = sl_NetAppMDNSRegisterService(MDNS_SERVICE_2,strlen(MDNS_SERVICE_2),
                                          MDNS_TEXT_2,strlen(MDNS_TEXT_2),
                                          MDNS_PORT_2, TTL, UNIQUE_SERVICE);
    if(Status < 0)
    {
        return -1;
    }
    Status = sl_NetAppMDNSRegisterService(MDNS_SERVICE_3,strlen(MDNS_SERVICE_3),
                                          MDNS_TEXT_3,strlen(MDNS_TEXT_3),
                                          MDNS_PORT_3, TTL, UNIQUE_SERVICE);
    if(Status < 0)
    {
        return -1;
    }

    Status = 1;
    /* Query to get the IP Address, Port for the service */
    while(Status )
    {
        ulTextLen = MAX_TEXT_LEN;
        Status = sl_NetAppDnsGetHostByService(DNS_SD_SERVICE, strlen(DNS_SD_SERVICE),
                                        SL_AF_INET, &ipAdd, &port, &ulTextLen, pText);
        _SlNonOsMainLoopTask();
    }

    /* Stop the CC3100 device */
    sl_Stop(0xFF);
}
