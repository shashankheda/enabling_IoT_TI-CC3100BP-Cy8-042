For information on this example refer to:
docs\examples\p2p.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_P2P_Application