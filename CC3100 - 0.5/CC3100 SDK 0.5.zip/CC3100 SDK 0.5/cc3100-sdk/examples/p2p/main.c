/*
 * main.c - sample application for using P2P
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "simplelink.h"
#include "cli_uart.h"

#define P2P_REMOTE_DEVICE  "DIRECT-" /* Dummy SSDI to start the p2p connection */
#define P2P_DEVICE_NAME    "cc3100-p2p-device"

#define DEVICE_TYPE        "1-0050F204-1"

#define SECURITY_TYPE      SL_SEC_TYPE_P2P_PBC
#define KEY                ""

#define LISTEN_CHANNEL    11
#define OPRA_CHANNEL      6
#define REGULATORY_CLASS  81


#define NO_OF_PACKETS 1000

enum
{
    CONNECTED = 0x1,
    IP_ACQUIRED_LEASED = 0x2,
    CONNECT_FAILED = 0x4,
    CONNECTION_REQUESTED = 0x8
}e_Stauts;

UINT8 g_Status = 0;

char g_p2p_dev[MAXIMAL_SSID_LENGTH + 1];

unsigned long g_DeviceIp = 0;


/* Port to be used  by TCP server*/
#define PORT_NUM        5001

#define BUF_SIZE 1400

union
{
    char BsdBuf[BUF_SIZE];
    UINT32 demobuf[BUF_SIZE/4];
} uBuf;

const char digits[] = "0123456789";

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         none

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvent)
{
    switch(pWlanEvent->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
        case SL_WLAN_STA_CONNECTED_EVENT:
            g_Status |= CONNECTED;
            break;

        case SL_WLAN_DISCONNECT_EVENT:
        case SL_WLAN_STA_DISCONNECTED_EVENT:
            g_Status &= ~(CONNECTED + IP_ACQUIRED_LEASED);
            break;

        case SL_WLAN_CONNECTION_FAILED_EVENT:
            g_Status |= CONNECT_FAILED;
            break;

        case SL_WLAN_P2P_DEV_FOUND_EVENT:
            /* Not used by this application */
            break;

       case SL_WLAN_P2P_NEG_REQ_RECEIVED_EVENT:
            g_Status |= CONNECTION_REQUESTED;
            memset(g_p2p_dev, '\0', MAXIMAL_SSID_LENGTH + 1);
            memcpy(g_p2p_dev,pWlanEvent->EventData.P2PModeNegReqReceived.go_peer_device_name,
                    pWlanEvent->EventData.P2PModeNegReqReceived.go_peer_device_name_len);
            break;

        default:
            break;

    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
        SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            /* Device is in client mode */
            g_DeviceIp = pNetAppEvent->EventData.ipAcquiredV4.ip;
        case SL_NETAPP_IP_LEASED:
            g_Status |= IP_ACQUIRED_LEASED;
            break;

        default:
            break;
    }
}

/*!
    \brief Convert integer to ASCII in decimal base

    \param[in]      cNum -  input integer number to convert
    \param[in]      cString -  pointer to output string

    \return         number of ASCII characters

    \note

    \warning
*/
static UINT8 itoa(INT16 cNum, UINT8 *cString)
{
    UINT8* ptr = 0;
    INT16 uTemp = cNum;
    UINT8 length = 0;

    /* value 0 is a special case */
    if (cNum == 0)
    {
        length = 1;
        *cString = '0';

        return length;
    }

    /* Find out the length of the number, in decimal base */
    while (uTemp > 0)
    {
        uTemp /= 10;
        length++;
    }

    /* Do the actual formatting, right to left */
    uTemp = cNum;
    ptr = cString + length;
    while (uTemp > 0)
    {
        --ptr;
        *ptr = digits[uTemp % 10];
        uTemp /= 10;
    }

    return length;
}

/*!
    \brief Display the IP Adderess of device

    \param[in]      none

    \return         none

    \note

    \warning
*/
static void DisplayIP()
{
    _NetCfgIpV4Args_t ipV4 = {0};

    UINT8 buff[18] = {'\0'};
    UINT8 *ccPtr = 0;
    UINT8 ccLen = 0;
    unsigned char len = sizeof(_NetCfgIpV4Args_t);
    unsigned char dhcpIsOn = 0;

    if(g_Status & CONNECT_FAILED)
        return;

    ccPtr = buff;

    if(g_DeviceIp == 0)
    {
        /* Device is in GO mode, Get the IP of Device */
        sl_NetCfgGet(SL_IPV4_AP_P2P_GO_GET_INFO,&dhcpIsOn,&len,(unsigned char *)&ipV4);
    }

    ccLen = itoa((char)SL_IPV4_BYTE(g_DeviceIp,3), ccPtr);
    ccPtr += ccLen;
    *ccPtr++ = '.';
    ccLen = itoa((char)SL_IPV4_BYTE(g_DeviceIp,2), ccPtr);
    ccPtr += ccLen;
    *ccPtr++ = '.';
    ccLen = itoa((char)SL_IPV4_BYTE(g_DeviceIp,1), ccPtr);
    ccPtr += ccLen;
    *ccPtr++ = '.';
    ccLen = itoa((char)SL_IPV4_BYTE(g_DeviceIp,0), ccPtr);
    ccPtr += ccLen;

    CLI_Write((unsigned char *)"Device IP: ");
    CLI_Write((unsigned char *)buff);
    CLI_Write((unsigned char *)"\r\n");
}

/*!
    \brief Connecting to a remote p2p device

    This function connects to the required p2p device (P2P_REMOTE_DEVICE).
    This code example connects using key (KEY).

    \param[in]  None

    \return     None

    \note

    \warning
*/
static void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = KEY;
    secParams.KeyLen = strlen(KEY);
    secParams.Type = SECURITY_TYPE;

    /* wlan connect call with dummy SSID to start the connection process */
    sl_WlanConnect(P2P_REMOTE_DEVICE, strlen(P2P_REMOTE_DEVICE), 0, &secParams, 0);

    while(!(g_Status & CONNECTION_REQUESTED))
    {
        _SlNonOsMainLoopTask();
    }

    /* Connect with the device requesting the connection */
    sl_WlanConnect(g_p2p_dev, strlen(g_p2p_dev), 0, &secParams, 0);

    while (!(g_Status & IP_ACQUIRED_LEASED ) || !(g_Status & CONNECTED))
    {
        _SlNonOsMainLoopTask();

        if(g_Status & CONNECT_FAILED)
        {
            /* Error, connection is failed */
            CLI_Write((unsigned char *)"Connection Failed\r\n");
            break;
        }
    }
}

/*!
    \brief Opening a server side socket and receiving data

    This function opens a TCP socket in Listen mode and waits for an incoming
    TCP connection. If a socket connection is established then the function
    will try to read 1000 TCP packets from the connected client.

    \param[in]      port number on which the server will be listening on

    \return         0 on success, -1 on Error.

    \note           This function will wait for an incoming connection till one
                    is established

    \warning
*/
static INT16 BsdTcpServer(UINT16 Port)
{
    SlSockAddrIn_t  Addr;
    SlSockAddrIn_t  LocalAddr;

    UINT16          idx = 0;
    UINT16          AddrSize = 0;
    INT16           SockID = 0;
    INT16           Status = 0;
    INT16           newSockID = 0;
    UINT16          LoopCount = 0;
    INT32           nonBlocking = 1;

    for (idx=0 ; idx<BUF_SIZE ; idx++)
    {
        uBuf.BsdBuf[idx] = (char)(idx % 10);
    }

    LocalAddr.sin_family = SL_AF_INET;
    LocalAddr.sin_port = sl_Htons((UINT16)Port);
    LocalAddr.sin_addr.s_addr = 0;

    SockID = sl_Socket(SL_AF_INET,SL_SOCK_STREAM, 0);
    if( SockID < 0 )
    {
        /* error */
        return -1;
    }

    AddrSize = sizeof(SlSockAddrIn_t);
    Status = sl_Bind(SockID, (SlSockAddr_t *)&LocalAddr, AddrSize);
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    Status = sl_Listen(SockID, 0);
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    Status = sl_SetSockOpt(SockID, SL_SOL_SOCKET, SL_SO_NONBLOCKING,
                           &nonBlocking, sizeof(nonBlocking));
    if( Status < 0 )
    {
        sl_Close(SockID);
        return -1;
    }

    newSockID = SL_EAGAIN;
    while( newSockID < 0 )
    {
        newSockID = sl_Accept(SockID, ( struct SlSockAddr_t *)&Addr,
                              (SlSocklen_t*)&AddrSize);
        if( newSockID == SL_EAGAIN )
        {
            /* Wait for 1 ms */
            Delay(1);
        }
        else if( newSockID < 0 )
        {
            sl_Close(SockID);
            return -1;
        }
    }

    while (LoopCount < NO_OF_PACKETS)
    {
        Status = sl_Recv(newSockID, uBuf.BsdBuf, BUF_SIZE, 0);
        if( Status <= 0 )
        {
            sl_Close(newSockID);
            sl_Close(SockID);
            return -1;
        }

        LoopCount++;
    }

    sl_Close(newSockID);
    sl_Close(SockID);

    return 0;
}

int main()
{
    unsigned char  paramBuff[4];

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initialize the LED */
    initLEDs();

    /* Initialize the Application Uart Interface */
    CLI_Configure();

    CLI_Write((unsigned char *)"=====P2P Sample Application======\r\n\r\n");

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* Configure P2P mode */
    sl_WlanSetMode(ROLE_P2P);

    /* Set Auto policy
     * any p2p option (SL_CONNECTION_POLICY(0,0,0,any_p2p,0)) can be used to
     * connect to first available p2p device */
    sl_WlanPolicySet(SL_POLICY_CONNECTION,SL_CONNECTION_POLICY(1,0,0,0,0),NULL,0);

    /* Set the negotiation role (SL_P2P_ROLE_NEGOTIATE).
     * CC3100 will negotiate with remote device GO/client mode.
     * Other valid options are:
     *             - SL_P2P_ROLE_GROUP_OWNER
     *             - SL_P2P_ROLE_CLIENT                           */
    sl_WlanPolicySet(SL_POLICY_P2P, SL_P2P_POLICY(SL_P2P_ROLE_NEGOTIATE,
            SL_P2P_NEG_INITIATOR_ACTIVE),NULL,0);

    /* Set P2P Device name */
    sl_NetAppSet(SL_NET_APP_DEVICE_CONFIG_ID, NETAPP_SET_GET_DEV_CONF_OPT_DEVICE_URN,
            strlen(P2P_DEVICE_NAME), (unsigned char *)P2P_DEVICE_NAME);

    /* Set P2P device type */
    sl_WlanSet(SL_WLAN_CFG_P2P_PARAM_ID, WLAN_P2P_OPT_DEV_TYPE,
            strlen(DEVICE_TYPE), DEVICE_TYPE);

    paramBuff[0] = LISTEN_CHANNEL;
    paramBuff[1] = REGULATORY_CLASS;
    paramBuff[2] = OPRA_CHANNEL;
    paramBuff[3] = REGULATORY_CLASS;

    /* Set P2P Device listen and operation channel valid channels are 1/6/11 */
    sl_WlanSet(SL_WLAN_CFG_P2P_PARAM_ID, WLAN_P2P_OPT_CHANNEL_N_REGS, 4, paramBuff);

    /* Restart as P2P device */
    sl_Stop(0xFF);
    sl_Start(NULL,NULL,NULL);

    /* Connect to configure P2P device */
    WlanConnect();

    DisplayIP();

    /*After calling this function, you can start sending data to CC3100 IP
    * address on PORT_NUM */
    if(!(g_Status & CONNECT_FAILED))
        BsdTcpServer(PORT_NUM);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
