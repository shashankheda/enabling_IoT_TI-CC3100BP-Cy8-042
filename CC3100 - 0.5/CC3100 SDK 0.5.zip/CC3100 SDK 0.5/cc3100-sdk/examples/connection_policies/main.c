/*
 * main.c - connection policy sample code
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include <string.h>
#include "simplelink.h"

#define UNSEC_SSID_NAME     "<unsecured-ap-name>"   /* Open AP name to connect to. */
#define SEC_SSID_NAME       "<secure-ap-name>"      /* AP with WPA security to connect to */
#define SEC_SSID_KEY        "<secure-ap-key>"       /* Key passphrase for secured AP */

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02

}e_Status;

UINT8 g_Status = 0;
UINT8 g_BSSID[SL_BSSID_LENGTH];

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         none

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
      case SL_WLAN_CONNECT_EVENT:
        g_Status |= CONNECTED;
        break;
      case SL_WLAN_DISCONNECT_EVENT:
        g_Status &= ~(1 << CONNECTION_STATUS_BIT | 1 << IP_AQUIRED_STATUS_BIT);
        break;
      default:
        break;
    }
}


/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
      case SL_NETAPP_IPV4_ACQUIRED:
        g_Status |= IP_AQUIRED;
        break;
      default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Not used in this application */
}

int main(void)
{
    SlSecParams_t secParams;

    sl_Memset(&secParams, 0, sizeof(secParams));
    sl_Memset(g_BSSID, 0, SL_BSSID_LENGTH);

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* Delete all profiles (0xFF) stored and reset policy settings */
    sl_WlanProfileDel(0xFF);
    sl_WlanPolicySet(SL_POLICY_CONNECTION , SL_CONNECTION_POLICY(0,0,0,0,0), 0, 0);

    /* Add unsecured AP profile with priority 6 (7 is highest) */
    secParams.Key = "";
    secParams.KeyLen = 0;
    secParams.Type = SL_SEC_TYPE_OPEN;
    sl_WlanProfileAdd((char*)UNSEC_SSID_NAME,
                      strlen(UNSEC_SSID_NAME), g_BSSID, 0, 0, 6, 0);

    /* Add WPA2 secured AP profile with priority 7 (highest) */
    secParams.Type = SL_SEC_TYPE_WPA;
    secParams.Key = SEC_SSID_KEY;
    secParams.KeyLen = strlen(SEC_SSID_KEY);
    sl_WlanProfileAdd((char*)SEC_SSID_NAME,
                      strlen(SEC_SSID_NAME), g_BSSID, &secParams, 0, 7, 0);

    /* Enable auto connect (connection to stored profiles according to priority)
     * Connection should first be established to higher (secured) profile as in
     * this example */
    sl_WlanPolicySet(SL_POLICY_CONNECTION , SL_CONNECTION_POLICY(1,0,0,0,0), 0, 0);

    /* Wait for the connection to be established */
    while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
    {
        _SlNonOsMainLoopTask();
    }

    /* Delete all profiles (0xFF) stored */
    sl_WlanProfileDel(0xFF);

    /* Remove the Fast connect policy and Set Auto Smartconfig policy */
    sl_WlanPolicySet(SL_POLICY_CONNECTION , SL_CONNECTION_POLICY(1,0,0,0,1), 0, 0);

    /* Restart the Device */
    g_Status = 0;
    sl_Stop(0xFF);
    sl_Start(0, 0, 0);

    /* After restarting Device will wait for a command for 2 second and start
     * the SmartConfig process if no command is received */

    /* Wait for smart config to complete and device to connect to AP */
    while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
    {
        _SlNonOsMainLoopTask();
    }

    /* Delete all profiles (0xFF) stored */
    sl_WlanProfileDel(0xFF);

    g_Status = 0;
    sl_Stop(0xFF);
    sl_Start(0, 0, 0);

    /* Set connection policy to Fast, Device will connect to last connected AP.
     * This feature can be used to reconnect to AP */
    sl_WlanPolicySet(SL_POLICY_CONNECTION , SL_CONNECTION_POLICY(1,1,0,0,0), 0, 0);

    /* Connect to the open AP */
    sl_WlanConnect(UNSEC_SSID_NAME,
                   strlen(UNSEC_SSID_NAME), 0, 0, 0);
    while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
    {
        _SlNonOsMainLoopTask();
    }

    /* Add unsecured AP profile with priority 6 (7 is highest)
     * Because of a limitation in SDK-0.5 which prevents the automatic addition
       of the profile (fast), the application is required to explicitly add it.
       The limitation shall be addressed in subsequent SDK release, and the below
       lines for adding the profile can be removed then...! */
    secParams.Key = "";
    secParams.KeyLen = 0;
    secParams.Type = SL_SEC_TYPE_OPEN;
    sl_WlanProfileAdd((char*)UNSEC_SSID_NAME,
                      strlen(UNSEC_SSID_NAME), g_BSSID, 0, 0, 6, 0);

    /* Restart the Device */
    g_Status = 0;
    sl_Stop(0xFF);
    sl_Start(0, 0, 0);

    /* Wait for the connection to be established */
    while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
    {
        _SlNonOsMainLoopTask();
    }

    /* Cleaning all profiles and setting the default connection policy before exiting the applicaiton */
    sl_WlanProfileDel(0xFF);
    sl_WlanPolicySet(SL_POLICY_CONNECTION , SL_CONNECTION_POLICY(1,0,0,0,0), 0, 0);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);
    return 0;
}
