/*
 * main.c - sample application for using NWP filters
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include <windows.h>
#include <stdio.h>

#include "simplelink.h"

#define MAC_ADDR_LENGTH     (6)
#define MAC_ADDR_LEN_STR    (18)    /*xx:xx:xx:xx:xx:xx*/
#define IP_ADDR_LENGTH      (4)
#define IP_ADDR_LEN_STR     (16)    /*xxx:xxx:xxx:xxx*/
#define MAX_RECV_BUF_SIZE   1536
#define SWAP_UINT32(val)    (((val>>24) & 0x000000FF) + ((val>>8) & 0x0000FF00) + \
                            ((val<<24) & 0xFF000000) + ((val<<8) & 0x00FF0000))
#define SWAP_UINT16(val)    ((((val)>>8) & 0x00FF) + (((val)<<8) & 0xFF00))

typedef char SlrxFilterOperationResult_t;

#ifdef SL_IF_TYPE_UART
#define COMM_PORT_NUM 10
SlUartIfParams_t params;
#endif /* SL_IF_TYPE_UART */

UINT32 g_ConnectionStatus = 0;
UINT8 g_Exit = 0;

typedef struct{
    UINT8   rate;          /* Recevied Rate:at ETxRateClassId format */
    UINT8   channel;       /* The received channel */
    INT8    rssi;          /* The computed RSSI value in db of current frame */
    UINT8   padding;       /* pad to align to 32 bits */
    UINT32  timestamp;     /* Timestamp in microseconds */

}TransceiverRxOverHead_t;

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
}

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *WlanEventHandler)
{
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
}

SlrxFilterID_t RxFiltersExample(INT8 input, INT8 filterNumber,
                                const UINT8 *filterParam, INT8 equalOrNot,
                                INT8 dropOrNot, INT8 parentId)
{
    SlrxFilterID_t          FilterId = 0;
    SlrxFilterRuleType_t    RuleType = 0;
    SlrxFilterFlags_t       FilterFlags;
    SlrxFilterRule_t        Rule;
    SlrxFilterTrigger_t     Trigger;
    SlrxFilterAction_t      Action;
    SlrxFilterOperationResult_t RetVal = -1;

    UINT8 MyLabCompIPAddress[4] = {0x0A,0x01,0x04,0x0A};
    UINT8 MacMAsk[6]      = {0xFF,0xFF,0xFF,0xFF,0xFF,0xFF};
    UINT8 TypeMask[1]     = {0xFF};
    UINT8 IPMask[4]       = {0xFF,0xFF,0xFF,0xFF};
    UINT8 zeroMask[4]     = {0x00,0x00,0x00,0x00};

    switch(input)
    {
        case '1': /* Create filter */
            /* Rule definition */
            RuleType = HEADER;
            FilterFlags.IntRepresentation = RX_FILTER_BINARY;
            switch (filterNumber)
            {
                case '1':
                    Rule.HeaderType.RuleHeaderfield = MAC_SRC_ADDRESS_FIELD;
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB6BytesRuleArgs[0],
                                                                       filterParam, 6);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                                           MacMAsk, 6);
                    break;
                case '2':
                    Rule.HeaderType.RuleHeaderfield = MAC_DST_ADDRESS_FIELD;
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB6BytesRuleArgs[0],
                                                                       filterParam, 6);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                                           MacMAsk, 6);
                    break;
                case '3':
                    Rule.HeaderType.RuleHeaderfield = BSSID_FIELD;
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB6BytesRuleArgs[0],
                                                                       filterParam, 6);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                                           MacMAsk, 6);
                    break;
                case '4':
                    Rule.HeaderType.RuleHeaderfield = FRAME_SUBTYPE_FIELD;
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB1BytesRuleArgs[0],
                                                                       filterParam, 1);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                                          TypeMask, 1);
                    break;
                case '5':
                    Rule.HeaderType.RuleHeaderfield = IPV4_SRC_ADRRESS_FIELD;
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB4BytesRuleArgs[0],
                                                                       filterParam, 4);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                                            IPMask, 4);
                    break;
                case '6':
                    Rule.HeaderType.RuleHeaderfield = IPV4_DST_ADDRESS_FIELD;
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB4BytesRuleArgs[0],
                                                                       filterParam, 4);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                                            IPMask, 4);
                    break;
                case '7':
                    Rule.HeaderType.RuleHeaderfield = FRAME_LENGTH_FIELD;
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB4BytesRuleArgs[0],
                                                                          zeroMask, 4);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                                            IPMask, 4);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgs.RxFilterDB4BytesRuleArgs[1],
                                                                       filterParam, 4);
                    memcpy(Rule.HeaderType.RuleHeaderArgsAndMask.RuleHeaderArgsMask,
                                                                            IPMask, 4);
                    break;
            }

            switch(equalOrNot)
            {
                case 'y':
                    Rule.HeaderType.RuleCompareFunc = COMPARE_FUNC_EQUAL;
                    break;
                case 'h':
                    Rule.HeaderType.RuleCompareFunc = COMPARE_FUNC_NOT_IN_BETWEEN;
                    break;
                case 'l':
                    Rule.HeaderType.RuleCompareFunc = COMPARE_FUNC_IN_BETWEEN;
                    break;
                case 'n':
                    Rule.HeaderType.RuleCompareFunc = COMPARE_FUNC_NOT_EQUAL_TO;
                    break;
            }

            Trigger.ParentFilterID = parentId;

            /* When RX_FILTER_COUNTER7 is bigger than 0 */
            Trigger.Trigger = NO_TRIGGER;

            /* connection state and role */
            Trigger.TriggerArgConnectionState.IntRepresentation = 0;
            Trigger.TriggerArgRoleStatus.IntRepresentation = RX_FILTER_ROLE_PROMISCUOUS;

            /* Action */
            if(dropOrNot == 'y')
            {
                Action.ActionType.IntRepresentation = RX_FILTER_ACTION_DROP;
            }
            else
            {
                Action.ActionType.IntRepresentation = RX_FILTER_ACTION_NULL;
            }

            RetVal = (SlrxFilterOperationResult_t)sl_WlanRxFilterAdd(RuleType,
                                            FilterFlags,
                                            &Rule,
                                            &Trigger,
                                            &Action,
                                            &FilterId);
            if( RetVal == 0)
                printf("\nThe filter ID is %d\n",FilterId);
            else
                printf("\nError creating the filter. Error number: %d.\n",RetVal);
            break;

        case '2': /* remove filter */
        {
                _WlanRxFilterOperationCommandBuff_t     RxFilterIdMask ;
                memset(RxFilterIdMask.FilterIdMask, 0xFF , 8);
                sl_WlanRxFilterSet(SL_REMOVE_RX_FILTER, (unsigned char *)&RxFilterIdMask,
                                    sizeof(_WlanRxFilterOperationCommandBuff_t));
        }
        return 0;

        case '3' : /* enable\disable filter */
        {
            _WlanRxFilterOperationCommandBuff_t     RxFilterIdMask ;
            memset(RxFilterIdMask.FilterIdMask, 0xFF , 8);
            sl_WlanRxFilterSet(SL_ENABLE_DISABLE_RX_FILTER, (unsigned char *)&RxFilterIdMask,
                                sizeof(_WlanRxFilterOperationCommandBuff_t));
        }

        return 0;
    }

    return FilterId;
}

void PrintFilterType(int sel)
{
    printf("\nFilter Parameter:\n");
    switch(sel)
    {
        case '1':
            printf("Source MAC Address\n");
            break;
        case '2':
            printf("Destination MAC Address\n");
            break;
        case '3':
            printf("BSSID\n");
            break;
        case '4':
            printf("Frame Subtype\n");
            break;
        case '5':
            printf("Source IP Address\n");
            break;
        case '6':
            printf("Destination IP Address\n");
            break;
        case '7':
            printf("Packet Length\n");
            break;
    }
}



void FiltersMenu()
{
    printf("\nPlease select a filter parameter:\n");
    printf("\n1. Source MAC address\n");
    printf("2. Destination MAC address\n");
    printf("3. BSSID\n");
    printf("4. Frame subtype\n");
    printf("5. Source IP address\n");
    printf("6. Destination IP address\n");
    printf("7. Packet length\n");
    printf("8. Remove filter and exit menu\n");
    printf("9. Enable filter and exit menu\n");
    printf("Selection: \n");
    while(1)
    {
        INT8    selection = -1;
        INT8    equalYesNo = -1;
        INT8    dropYesNo = -1;
        UINT32  frameTypeLength = 0;
        UINT32  fatherId = 0;
        UINT32  macAddress[MAC_ADDR_LENGTH] = {'\0'};
        UINT8   sMacAddr[MAC_ADDR_LEN_STR] = {'\0'};
        UINT32  ipAddress[IP_ADDR_LENGTH] = {'\0'};
        UINT8   sIpAddress[IP_ADDR_LEN_STR] = {'\0'};
        UINT8   filterData[MAC_ADDR_LENGTH] = {'\0'};
        INT32   i;

        fflush(stdin);
        scanf_s("%c",&selection, sizeof(selection));

        switch(selection)
        {
            case '1':
            case '2':
            case '3':
                PrintFilterType(selection);
                printf("\nEnter the MAC address (xx:xx:xx:xx:xx:xx): \n");
                fflush(stdin);
                scanf("%2x:%2x:%2x:%2x:%2x:%2x", &macAddress[0],
                                                 &macAddress[1],
                                                 &macAddress[2],
                                                 &macAddress[3],
                                                 &macAddress[4],
                                                 &macAddress[5]);
                for(i = 0 ; i < MAC_ADDR_LENGTH ; i++ )
                {
                    filterData[i] = (unsigned char)macAddress[i];
                }
                break;

            case '4':
                PrintFilterType(selection);
                printf("Enter the frame type byte: \n");
                fflush(stdin);
                scanf_s("%2x",&frameTypeLength, sizeof(frameTypeLength));
                filterData[0] = (unsigned char)frameTypeLength;
                break;

            case '5':
            case '6':
                PrintFilterType(selection);
                printf("Enter the IP address: \n");
                fflush(stdin);
                scanf("%u.%u.%u.%u",&ipAddress[0],&ipAddress[1],&ipAddress[2],
                                                                 &ipAddress[3]);
                for(i = 0 ; i < IP_ADDR_LENGTH ; i++ )
                {
                    filterData[i] = (unsigned char)ipAddress[i];
                }
                break;

            case '7':
                PrintFilterType(selection);
                printf("Enter desired length in Bytes (Maximum = 1472): \n");
                fflush(stdin);
                scanf_s("%u",&frameTypeLength, sizeof(frameTypeLength));
                *(unsigned int *)filterData = SWAP_UINT32(frameTypeLength);
                printf("Target what lengths? (h - Higher than %u | l - Lower than %u): \n",
                                                  frameTypeLength,frameTypeLength);
                fflush(stdin);
                scanf_s("%c",&equalYesNo, sizeof(equalYesNo));
                printf("Drop packets or not? (y/n): \n");
                fflush(stdin);
                scanf_s("%c",&dropYesNo, sizeof(dropYesNo));
                printf("Enter filter ID of parent. Otherwise 0: \n");
                fflush(stdin);
                scanf_s("%u", &fatherId, sizeof(fatherId));
                RxFiltersExample('1',selection,filterData,equalYesNo,dropYesNo,
                                                                   (char)fatherId);
                printf("\nPlease select a filter parameter:\n");
                printf("\n1. Source MAC address\n");
                printf("2. Destination MAC address\n");
                printf("3. BSSID\n");
                printf("4. Frame subtype\n");
                printf("5. Source IP address\n");
                printf("6. Destination IP address\n");
                printf("7. Packet length\n");
                printf("8. Remove filter and exit menu\n");
                printf("9. Enable filter and exit menu\n");
                printf("\nSelection: \n");
                continue;
                break;

            case '8':
                RxFiltersExample('2',0,NULL,0,0,0);
                printf("Press 'f' to configure MAC filters or 'q' to exit \n");
                return;
                break;

            case '9':
                RxFiltersExample('3',0,NULL,0,0,0);
                return;
                break;

            default:
                continue;

        }

        printf("Equal or not equal? (y/n): \n");
        fflush(stdin);
        scanf_s("%c",&equalYesNo, sizeof(equalYesNo));

        printf("Drop the packet? (y/n): \n");
        fflush(stdin);
        scanf_s("%c",&dropYesNo, sizeof(dropYesNo));

        printf("Enter filter ID of parent. Otherwise 0:: \n");
        fflush(stdin);
        scanf_s("%u", &fatherId, sizeof(fatherId));

        RxFiltersExample('1', selection, filterData,
                         equalYesNo, dropYesNo, (INT8)fatherId);

        printf("\nPlease select a filter parameter:\n");
        printf("\n1. Source MAC address\n");
        printf("2. Destination MAC address\n");
        printf("3. BSSID\n");
        printf("4. Frame subtype\n");
        printf("5. Source IP address\n");
        printf("6. Destination IP address\n");
        printf("7. Packet length\n");
        printf("8. Remove and exit\n");
        printf("9. Enable and exit\n");
        printf("Selection:\n");
    }

    return;
}

void ChooseFilters()
{
    INT8  ch = -1;
    printf("Enter 'f' to configure MAC filters or 'q' to exit: \n");
    fflush(stdin);

    ch = getchar();

    if(ch == 'f' || ch == 'F')
    {
        FiltersMenu();
    }
    else if(ch == 'q' || ch == 'Q')
    {
        g_Exit = 1;
    }

    Sleep(500);
}

void PrintFrameSubtype(unsigned char MAC)
{
    printf("Frame Subtype:\n");
    switch (MAC)
    {
        case 0x8:
            printf("Data (%02x)\n",MAC);
            break;

        case 0x40:
            printf("Probe Request (%02x)\n",MAC);
            break;

        case 0x50:
            printf("Probe Response (%02x)\n",MAC);
            break;

        case 0x80:
            printf("Beacon (%02x)\n",MAC);
            break;

        case 0x88:
            printf("QOS Data (%02x)\n",MAC);
            break;

        case 0xd4:
            printf("Acknowledgement (%02x)\n",MAC);
            break;

        case 0x0b:
            printf("Authentication (%02x)\n",MAC);
            break;

        case 0x1c:
            printf("Clear to Send (%02x)\n",MAC);
            break;

        case 0x1b:
            printf("Request to Send (%02x)\n",MAC);
            break;

        case 0x09:
            printf("ATIM (%02x)\n",MAC);
            break;

        case 0x19:
            printf("802.11 Block Acknowledgement (%02x)\n",MAC);
            break;

        default:
            printf("Unknown (%02x)\n",MAC);
            break;
    }
}

void Sniffer(INT32 channel,INT32 numpackets)
{
    UINT8 buffer[MAX_RECV_BUF_SIZE] = {'\0'};
    UINT8 MAC[MAX_RECV_BUF_SIZE] = {'\0'};

    UINT32 bytesSent = 0;

    INT32 recievedBytes = -1;
    INT32 hexempty = 0xcc;
    INT32 fConnected = -1;
    INT32 counter = -1;
    INT32 count = -1;
    INT32 i = -1;

    INT16 sd = -1;

    DWORD startTick = 0;

    TransceiverRxOverHead_t *frameRadioHeader;

    /********************* Open Socket for transceiver   *********************/
    sd = sl_Socket(SL_AF_RF,SL_SOCK_RAW,channel);

    /************************************ Creating filters *****************/
    ChooseFilters();

    /************ Receiving frames from the CC3100 and printing to screen*****/
    if (!g_Exit)
    {
        printf("\nCollecting Packets...\n");

        for(i = 0; i < numpackets; i++)
        {
            recievedBytes = sl_Recv(sd,buffer,MAX_RECV_BUF_SIZE,0);
            frameRadioHeader = (TransceiverRxOverHead_t *)buffer;
            printf("\nTimestamp: %i microsec\n",frameRadioHeader->timestamp);
            printf("Signal Strength: %i dB\n",frameRadioHeader->rssi);

            memcpy(MAC, buffer, sizeof(buffer));

            PrintFrameSubtype(MAC[8]);

            printf("Destination MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",
                            MAC[12],MAC[13], MAC[14],MAC[15], MAC[16],MAC[17]);

            if (MAC[18] == hexempty)
            {
                printf("Source MAC Address: Unknown\n");
            }
            else
            {
                printf("Source MAC Address: %02x:%02x:%02x:%02x:%02x:%02x\n",
                            MAC[18],MAC[19], MAC[20],MAC[21], MAC[22],MAC[23]);
            }

            Sleep(500);
        }



        system("PAUSE");
    }

    sl_Close(sd);
}

int main( int argc, char *argv[] )
{
    INT32 channel;
    INT32 numpackets;

    INT8 *pConfig = 0;

#ifdef SL_IF_TYPE_UART
    params.BaudRate = 115200;
    params.FlowControlEnable = 1;
    params.CommPort = COMM_PORT_NUM;

    pConfig = (char *)&params;
#endif /* SL_IF_TYPE_UART */

    /*This line is for Eclipse CDT only due to a known bug in console buffering
     * See https://bugs.eclipse.org/bugs/show_bug.cgi?id=173732 */
    setvbuf(stdout, NULL, _IONBF, 0);

    /* Initializing the CC3100 device */
    sl_Start(NULL, pConfig, NULL);

    system("cls");
    printf("SimpleSniffer v1.0 \n\n");
    printf("Notes: There is at least a 0.5 second delay between each packet displayed.\n");
    printf("       The command prompt can display a maximum of 50 packets.\n\n");
    printf("Please input desired channel number and click \"Enter\".\n");
    printf("Valid channels range from 1 to 13 (11 is standard): \n");
    fflush(stdin);
    scanf_s("%d",&channel, sizeof(channel));
    printf("Please input desired number of packets and click \"Enter\": \n");
    fflush(stdin);
    scanf_s("%d",&numpackets, sizeof(numpackets));
    Sniffer(channel, numpackets);
}
