/*
 * email.c - function implementation to send email
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 * All rights reserved. Property of Texas Instruments Incorporated.
 * Restricted rights to use, duplicate or disclose this code are
 * granted through contract.
 *
 * The program may not be used without the written permission of
 * Texas Instruments Incorporated or against the terms and conditions
 * stipulated in the agreement under which this program has been supplied,
 * and under no circumstances can it be used with non-TI connectivity device.
 *
 */

#include "email.h"
#include "datatypes.h"
#include "simplelink.h"
#include "protocol.h"
#include "cli_uart.h"
#include "base64.h"

/*NetApp Email protocol types */
#define SL_NET_APP_SMTP_PROTOCOL        (1)

/* Strings used to configure the Email msg in proper format */
const char smtp_helo[] = {'H','E','L','O','\0'};
const char smtp_mail_from[]={'M','A','I','L',' ','F','R','O','M',':',' ','\0'};
const char smtp_rcpt[] = {'R','C','P','T',' ','T','O',':',' ','\0'};
const char smtp_data[] = "DATA";
const char smtp_crlf[] = "\r\n";
const char smtp_dcrlf[] = "\r\n\r\n";
const char smtp_subject[] = "Subject: ";
const char smtp_to[] = "To: ";
const char smtp_from[] = "From: ";
/* <CRLF>.<CRLF> Terminates the data portion */
const char smtp_data_end[] = {'\r','\n','.','\r','\n','\0'};
const char smtp_quit[] = {'Q','U','I','T','\r','\n','\0'};

/* Return Codes */
const char smtp_code_ready[] = {'2','2','0','\0'};
const char smtp_ok_reply[] = {'2','5','0','\0'};
const char smtp_intermed_reply[] = {'3','5','4','\0'};
const char smtp_auth_reply[] = {'3','3','4','\0'};
const char smtp_auth_success[] = {'2','3','5','\0'};

/* states for smtp state machine */
typedef enum
{
    smtpINACTIVE = 0,
    smtpINIT,
    smtpHELO,
    smtpAUTH,
    smtpFROM,
    smtpRCPT,
    smtpDATA,
    smtpMESSAGE,
    smtpQUIT,
    smtpERROR
}_SlsmtpStatus_e;

/* Initialize SMTP State Machine */
unsigned int g_smtpStatus = smtpINIT;
int g_ConnectStatus = -1;

unsigned int g_EmailSetStatus = 0;

/* error handling flags for smtp state machine */
typedef enum
{
    smtpNOERROR = 0,
    atINIT,
    atHELO,
    atAUTH,
    atFROM,
    atRCPT,
    atDATA,
    atMESSAGE,
    atQUIT
}_SlsmtpERROR_e;

/* Initialize Error handling flag */
unsigned int g_smtpErrorInfo = smtpNOERROR;
long smtpSocket;
char g_cmdBuf[SMTP_BUF_LEN];
char buf[SMTP_BUF_LEN];
char basekey1[BASEKEY_LEN];
char basekey2[BASEKEY_LEN];
char message[MAX_MESSAGE_LEN];

SlNetAppEmailOpt_t g_EmailOpt;
SlNetAppSourceEmail_t g_Email;
SlNetAppSourcePassword_t g_SourcePass;
SlNetAppDestination_t g_Destination;
SlNetAppEmailSubject_t g_Subject;

char email_rfc[MAX_EMAIL_RCF_LEN];

static int _smtpConnect(void);
static int _smtpSend(void);
static void _smtpHandleERROR(char * servermessage);
static void _sendSMTPCommand(long socket, char * cmd, char * cmdparam, char * respBuf);
static void _generateBase64Key(char * basekey1, char * basekey2);


/*!
    \brief This function sets the email parameters

    \param[in]      command -   Command send for processing
    \param[in]      pValueLen - Length of data to be processed
    \param[in]      pValue -     Data to be processed

    \return         0 for success, -1 otherwise

    \note

    \warning
*/
int sl_NetAppEmailSet(unsigned char command ,unsigned char pValueLen,
                      unsigned char *pValue)
{

    SlNetAppEmailOpt_t* pEmailOpt = 0;
    SlNetAppSourceEmail_t* pSourceEmail = NULL;
    SlNetAppSourcePassword_t* pSourcePassword = NULL;
    SlNetAppDestination_t* pDestinationEmail = NULL;
    SlNetAppEmailSubject_t* pSubject = NULL;

    switch (command)
    {
      case NETAPP_ADVANCED_OPT:
        pEmailOpt = (SlNetAppEmailOpt_t*)pValue;

        g_EmailOpt.Port = pEmailOpt->Port;
        g_EmailOpt.Family = pEmailOpt->Family;
        g_EmailOpt.SecurityMethod = pEmailOpt->SecurityMethod;
        g_EmailOpt.SecurityCypher = pEmailOpt->SecurityCypher;
        g_EmailOpt.Ip = pEmailOpt->Ip;

        g_EmailSetStatus+=1;
        break;

      case NETAPP_SOURCE_EMAIL:
        pSourceEmail = (SlNetAppSourceEmail_t*)pValue;
        memset(g_Email.Username, '\0', MAX_USERNAME_LEN);
        memcpy(g_Email.Username, pSourceEmail->Username, pValueLen);

        g_EmailSetStatus+=2;

        break;

      case NETAPP_PASSWORD:
        pSourcePassword = (SlNetAppSourcePassword_t*)pValue;
        memset(g_SourcePass.Password, '\0', MAX_PASSWORD_LEN);
        memcpy(g_SourcePass.Password, pSourcePassword->Password, pValueLen);

        g_EmailSetStatus+=4;

        break;

      case NETAPP_DEST_EMAIL:
        pDestinationEmail=(SlNetAppDestination_t*)pValue;
        memset(g_Destination.Email, '\0', MAX_DEST_EMAIL_LEN);
        memcpy(g_Destination.Email, pDestinationEmail->Email, pValueLen);

        g_EmailSetStatus+=8;

        break;

      case NETAPP_SUBJECT:
        pSubject=(SlNetAppEmailSubject_t*)pValue;
        memset(g_Subject.Value, '\0', MAX_SUBJECT_LEN);
        memcpy(g_Subject.Value, pSubject->Value, pValueLen);

        g_EmailSetStatus+=16;

        break;

      case NETAPP_MESSAGE:
        if(pValueLen > (MAX_MESSAGE_LEN - 1))
        {
            return -1;
        }
        memset(message, '\0', MAX_MESSAGE_LEN);
        memcpy(message ,pValue, pValueLen);
        break;

      default:
        CLI_Write((UINT8*)"\n\rError:Default case\n\r");
        return -1;
    }

    return 0;
}

/*!
    \brief Create a secure socket and connects to SMTP server

    \param[in]      none

    \return         0 if success and negative in case of error

    \note

    \warning
*/
int sl_NetAppEmailConnect()
{
    if (!(g_EmailSetStatus >= 0x07))
    {
        CLI_Write((UINT8*)"\n\rError:Email and Subject is not configured\n\r");
        return -1;
    }

    g_ConnectStatus = _smtpConnect();
    return g_ConnectStatus;
}

/*!
    \brief Check the connection status and sends the Email

    \param[in]      none

    \return         0 if success otherwise -1

    \note

    \warning
*/
int sl_NetAppEmailSend()
{
    if(g_ConnectStatus!=0)
        return -1;

    return _smtpSend();
}


/*!
    \brief Creates a secure socket and connects to SMTP server

    \param[in]      none

    \return         0 if success and negative in case of error

    \note

    \warning
*/
static int _smtpConnect(void)
{
    SlSockAddrIn_t  LocalAddr;
    SlTimeval_t     tTimeout;
    INT32           cipher = 0;
    INT32           LocalAddrSize = 0;
    INT8            method = 0;
    INT8            Status = 0;

    LocalAddr.sin_family = g_EmailOpt.Family;
    LocalAddr.sin_port = sl_Htons(g_EmailOpt.Port);
    LocalAddr.sin_addr.s_addr = sl_Htonl(g_EmailOpt.Ip);
    LocalAddrSize = sizeof(SlSockAddrIn_t);

    /* If TLS is required */
    if(g_EmailOpt.SecurityMethod <= 5)
    {
        /* Create secure socket */
        smtpSocket = sl_Socket(SL_AF_INET, SL_SOCK_STREAM, SL_SEC_SOCKET);
        if (smtpSocket == -1)
        {
            sl_Stop(0);
            return -1;
        }

        tTimeout.tv_sec = 10;
        tTimeout.tv_usec = 90000;
        Status = sl_SetSockOpt(smtpSocket, SL_SO_RCVTIMEO, 0,
                               &tTimeout, sizeof(SlTimeval_t));

        method = g_EmailOpt.SecurityMethod;
        cipher = g_EmailOpt.SecurityCypher;

        /* Set Socket Options that were just defined */
        Status = sl_SetSockOpt(smtpSocket, SL_SOL_SOCKET, 25,
                               &method, sizeof(method));
        if( Status < 0 )
        {
            sl_Close(smtpSocket);
            return -2;
        }
        Status = sl_SetSockOpt(smtpSocket, SL_SOL_SOCKET, 26,
                               &cipher, sizeof(cipher));
        if( Status < 0 )
        {
            sl_Close(smtpSocket);
            return -2;
        }
    }
    /* If no TLS required */
    else
    {
        /* Create socket */
        smtpSocket = sl_Socket(SL_AF_INET, SL_SOCK_STREAM, SL_IPPROTO_TCP);
        if (smtpSocket == -1)
        {
            sl_Stop(0);
            return -1;
        }
    }

    /* connect to socket */
    Status = sl_Connect(smtpSocket, (SlSockAddr_t *)&LocalAddr, LocalAddrSize);
    if((Status < 0) && (SL_ESECSNOVERIFY != Status))
    {
        return -1;
    }

    return 0;
}

/*!
    \brief This function will send the email

    \param[in]      none

    \return         0 if success otherwise -1

    \note

    \warning
*/
static int _smtpSend(void)
{
    int exit = 0;
    int ret_val = 0;

    /* If socket has been opened, check for acknowledge from SMTP server */
    while(exit == 0)
    {
        switch(g_smtpStatus)
        {
            case smtpINIT:
                /* Create buffer, Read so we can chek for 220 'OK' from server */
                memset(buf, 0, SMTP_BUF_LEN);

                sl_Recv(smtpSocket, buf, sizeof(buf), 0);

                /* If buffer has 220, set state to HELO */
                if(buf[0] == smtp_code_ready[0] &&
                   buf[1] == smtp_code_ready[1] &&
                   buf[2] == smtp_code_ready[2])
                {
                    g_smtpStatus = smtpHELO;
                }
                /* Else error, set state to ERROR */
                else
                {
                    g_smtpStatus = smtpERROR;
                    g_smtpErrorInfo = atINIT;
                }
            break;

            /* Send Introductory "HELO" to SMTP server */
            case smtpHELO:
                _sendSMTPCommand(smtpSocket, "HELO localhost", NULL, buf);

                /* If response has 250, set state to AUTH */
                if(buf[0] == smtp_ok_reply[0] &&
                   buf[1] == smtp_ok_reply[1] &&
                   buf[2] == smtp_ok_reply[2])
                {
                    g_smtpStatus = smtpAUTH;
                }
                /* Else error, set state to ERROR */
                else
                {
                    g_smtpStatus = smtpERROR;
                    g_smtpErrorInfo = atHELO;
                }
            break;

            /* Handle Authentication with server username and password */
            case smtpAUTH:
                /* Function handles authentication for all services */
                _generateBase64Key((char*)g_Email.Username, basekey1);
                _generateBase64Key((char*)g_SourcePass.Password, basekey2);

                /* Send request to server for authentication */
                _sendSMTPCommand(smtpSocket, "AUTH LOGIN", NULL, buf);
                /* If response has 334, give username in base64 */
                if(buf[0] == smtp_auth_reply[0] &&
                   buf[1] == smtp_auth_reply[1] &&
                   buf[2] == smtp_auth_reply[2])
                {
                    _sendSMTPCommand(smtpSocket, basekey1, NULL, buf);
                    /* If response has 334, give password in base64 */
                    if(buf[0] == smtp_auth_reply[0] &&
                       buf[1] == smtp_auth_reply[1] &&
                       buf[2] == smtp_auth_reply[2])
                    {
                        _sendSMTPCommand(smtpSocket, basekey2, NULL, buf);
                    }
                }

                if(buf[0] == smtp_auth_success[0] &&
                   buf[1] == smtp_auth_success[1] &&
                   buf[2] == smtp_auth_success[2])
                {
                    /* Authentication was successful, set state to FROM */
                    g_smtpStatus = smtpFROM;
                }
                /* Else error, set state to ERROR */
                else
                {
                    g_smtpStatus = smtpERROR;
                    g_smtpErrorInfo = atAUTH;
                }
            break;

            /* Send source email to the SMTP server */
            case smtpFROM:
                _sendSMTPCommand(smtpSocket, (char *)smtp_mail_from,
                                 (char *)g_Email.Username, buf);

                /* If response has 250, set state to RCPT */
                if(buf[0] == smtp_ok_reply[0] &&
                   buf[1] == smtp_ok_reply[1] &&
                   buf[2] == smtp_ok_reply[2])
                {
                    g_smtpStatus = smtpRCPT;
                }
                else
                {
                    memset(email_rfc,'\0',MAX_EMAIL_RCF_LEN);
                    memcpy(email_rfc,"<",1);
                    memcpy(&email_rfc[1], (const char *)g_Email.Username,
                           strlen((const char *)g_Email.Username));
                    memcpy(&email_rfc[1+strlen((const char *)g_Email.Username)],">",1);

                    _sendSMTPCommand(smtpSocket, (char *)smtp_mail_from,
                                     email_rfc, buf);

                    if(buf[0] == smtp_ok_reply[0] &&
                       buf[1] == smtp_ok_reply[1] &&
                       buf[2] == smtp_ok_reply[2])
                    {
                        g_smtpStatus = smtpRCPT;
                    }
                    else
                    {
                        g_smtpStatus = smtpERROR;
                        g_smtpErrorInfo = atFROM;
                    }
                }
            break;

            /* Send the destination email to the smtp server */
            case smtpRCPT:
                _sendSMTPCommand(smtpSocket, (char *)smtp_rcpt,
                                 (char *)g_Destination.Email, buf);

                /* If response has 250, set state to DATA */
                if(buf[0] == smtp_ok_reply[0] &&
                   buf[1] == smtp_ok_reply[1] &&
                   buf[2] == smtp_ok_reply[2])
                {
                    g_smtpStatus = smtpDATA;
                }
                else
                {
                    memset(email_rfc,'\0',MAX_EMAIL_RCF_LEN);
                    memcpy(email_rfc,"<",1);
                    memcpy(&email_rfc[1], (const char *)g_Destination.Email,
                           strlen((const char *)g_Destination.Email));
                    memcpy(&email_rfc[1+strlen((const char *)g_Destination.Email)],">",1);
                    _sendSMTPCommand(smtpSocket, (char *)smtp_rcpt,email_rfc, buf);
                    /* If response has 250, set state to DATA */
                    if(buf[0] == smtp_ok_reply[0] &&
                       buf[1] == smtp_ok_reply[1] &&
                       buf[2] == smtp_ok_reply[2])
                    {
                        g_smtpStatus = smtpDATA;
                    }
                    else
                    {
                        g_smtpStatus = smtpERROR;
                        g_smtpErrorInfo = atRCPT;
                    }
                }
            break;

            /*Send the "DATA" message to the server, indicates client is ready
            * to construct the body of the email */
            case smtpDATA:
                _sendSMTPCommand(smtpSocket, (char *)smtp_data, NULL, buf);
                /* If Response has 250, set state to MESSAGE */
                if(buf[0] == smtp_intermed_reply[0] &&
                buf[1] == smtp_intermed_reply[1] && buf[2] == smtp_intermed_reply[2])
                {
                    g_smtpStatus = smtpMESSAGE;
                }
                else
                {
                    g_smtpStatus = smtpERROR;
                    g_smtpErrorInfo = atDATA;
                }
            break;

            case smtpMESSAGE:
                /* Send actual Message, preceded by FROM, TO and Subject */

                /* Start with E-Mail's "Subject:" field */
                _sendSMTPCommand(smtpSocket, (char *)smtp_subject,
                                                (char *)g_Subject.Value, NULL);

                /* Add E-mail's "To:" field */
                _sendSMTPCommand(smtpSocket, (char *)smtp_to,
                                            (char *)g_Destination.Email, NULL);

                /* Add E-mail's "From:" field */
                _sendSMTPCommand(smtpSocket, (char *)smtp_from,
                                                (char *)g_Email.Username, NULL);

                /* Send CRLF */
                sl_Send(smtpSocket,smtp_crlf,strlen(smtp_crlf),0);

                /* Send body of message */
                _sendSMTPCommand(smtpSocket, message, NULL, NULL);

                /* End Message */
                _sendSMTPCommand(smtpSocket,(char *)smtp_data_end,NULL,buf);

                /* Server will send 250 for successful. Move into QUIT state. */
                if(buf[0] == smtp_ok_reply[0] && buf[1] == smtp_ok_reply[1] &&
                                                        buf[2] == smtp_ok_reply[2])
                {
                    /* Disconnect from server by sending QUIT command */
                    sl_Send(smtpSocket,smtp_quit,strlen(smtp_quit),0);
                    /* Close socket and reset */
                    sl_Close(smtpSocket);
                    smtpSocket = 0xFFFFFFFF;
                    /* Reset the state machine */
                    g_smtpStatus = smtpINIT;
                    exit = 1;
                    ret_val = 0;
                }
                else
                {
                    g_smtpStatus = smtpERROR;
                    g_smtpErrorInfo = atMESSAGE;
                }
            break;

            case smtpERROR:
                /* Error Handling for SMTP */
                _smtpHandleERROR(buf);
                /* Close socket and reset */
                sl_Close(smtpSocket);
                /*Reset the state machine */
                g_smtpStatus = smtpINIT;
                exit = 1;
                ret_val = -1;
            break;

            default:
                exit = 1;
                ret_val = -1;
            break;
        }
    }

    return ret_val;
}

/*!
    \brief This function converts the string to Base64 format needed for
           authentication

    \param[in]      input - pointer to string to be converted
    \param[out]     basekey1 - Pointer to string for base64 converted output

    \return         None

    \note

    \warning
*/
static void _generateBase64Key(char *input, char *basekey1)
{
    char *pIn = (char *)input;

    /* Convert to base64 format  */
    ConvertToBase64(basekey1, (void *)pIn, strlen(input));
}

/*!
    \brief Performs Error Handling for SMTP State Machine

    \param[in]      servermessage - server response message

    \return         None

    \note

    \warning
*/
static void _smtpHandleERROR(char *servermessage)
{
    /* Errors are handled using flags set in the smtpStateMachine */
    switch(g_smtpErrorInfo)
    {
        case atINIT:
            /* Server connection could not be established */
            CLI_Write((UINT8*)"Server connection error.\r\n");
            CLI_Write((UINT8*)servermessage);
        break;

        case atHELO:
            /* Server did not accept the HELO command from server */
            CLI_Write((UINT8*)"Server did not accept HELO:\r\n");
            CLI_Write((UINT8*)servermessage);
        break;

        case atAUTH:
            /* Server did not accept authorization credentials */
            CLI_Write((UINT8*)"Authorization unsuccessful, ");
            CLI_Write((UINT8*)"check username/password.\r\n");
            CLI_Write((UINT8*)servermessage);
        break;

        case atFROM:
            /* Server did not accept source email. */
            CLI_Write((UINT8*)"Email of sender not accepted by server.\r\n");
            CLI_Write((UINT8*)servermessage);
        break;

        case atRCPT:
            /* Server did not accept destination email */
            CLI_Write((UINT8*)"Email of recipient not accepted by server.\r\n");
            CLI_Write((UINT8*)servermessage);
        break;

        case atDATA:
            /* 'DATA' command to server was unsuccessful */
            CLI_Write((UINT8*)"smtp 'DATA' command not accepted by server.\r\n");
            CLI_Write((UINT8*)servermessage);
        break;

        case atMESSAGE:
            /* Message body could not be sent to server */
            CLI_Write((UINT8*)"Email Message was not accepted by the server.\r\n");
            CLI_Write((UINT8*)servermessage);
        break;

        case atQUIT:
            /* Message could not be finalized */
            CLI_Write((UINT8*)"Connection could not be properly closed.");
            CLI_Write((UINT8*)" Message not sent.\r\n");
            CLI_Write((UINT8*)servermessage);
        break;
    }
}

/*!
    \brief  Sends the SMTP command and receives the server response.
            If cmd and cmd parameter are NULL, it will only send <CR><LF>

    \param[in]      socket - Socket Descriptor
    \param[in]      cmd -    command to be send to server
    \param[in]      cmdparam - command parameter to be send
    \param[in]      respBuf -    Pointer to buffer for SMTP server response

    \return         None

    \note

    \warning
*/
static void _sendSMTPCommand(long socket, char *cmd, char * cmdparam, char *respBuf)
{

    int sendLen = 0;
    memset(g_cmdBuf, 0, sizeof(g_cmdBuf));

    if(cmd != NULL)
    {
        sendLen = strlen(cmd);
        memcpy(g_cmdBuf,cmd,strlen(cmd));
    }

    if(cmdparam != NULL)
    {
        memcpy(&g_cmdBuf[sendLen], cmdparam, strlen(cmdparam));
        sendLen += strlen(cmdparam);
    }

    memcpy(&g_cmdBuf[sendLen], smtp_crlf, strlen(smtp_crlf));
    sendLen += strlen(smtp_crlf);
    sl_Send(socket, g_cmdBuf,sendLen,0);

    if(respBuf != NULL)
    {
        memset(respBuf,0,SMTP_BUF_LEN);
        sl_Recv(socket, respBuf,SMTP_BUF_LEN,0);
    }
}
