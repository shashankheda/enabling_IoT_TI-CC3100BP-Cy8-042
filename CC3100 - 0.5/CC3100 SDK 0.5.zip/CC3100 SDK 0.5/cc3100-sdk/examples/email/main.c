/*
 * main.c - sample application to send email
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 * All rights reserved. Property of Texas Instruments Incorporated.
 * Restricted rights to use, duplicate or disclose this code are
 * granted through contract.
 *
 * The program may not be used without the written permission of
 * Texas Instruments Incorporated or against the terms and conditions
 * stipulated in the agreement under which this program has been supplied,
 * and under no circumstances can it be used with non-TI connectivity device.
 *
 */

#include "simplelink.h"
#include "cli_uart.h"
#include "email.h"
#include "config.h"

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02

}e_Status;
UINT8 g_Status = 0;

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
            g_Status |= CONNECTED;
        break;

        case SL_WLAN_DISCONNECT_EVENT:
            g_Status &= ~(1 << CONNECTION_STATUS_BIT | 1 << IP_AQUIRED_STATUS_BIT);
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_AQUIRED;
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    The function will return only once we are connected and have acquired IP
    address

    \param[in]      None

    \return         none

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, we will be stuck in this function forever.
*/
static void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = PASSKEY;
    secParams.KeyLen = PASSKEY_LEN;
    secParams.Type = SEC_TYPE;

    sl_WlanConnect(SSID_NAME, strlen(SSID_NAME), 0, &secParams, 0);

    while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
    {
        _SlNonOsMainLoopTask();
    }
}

/*!
    \brief Disconnecting from a WLAN Access point

    This function dicconnects from the connected AP

    \param[in]      None

    \return         none

    \note

    \warning        If the WLAN disconnection fails, we will be stuck in this function forever.
*/
static void WlanDisconnect()
{
    sl_WlanDisconnect();
    while ((1 == (g_Status & CONNECTED)))
    {
        _SlNonOsMainLoopTask();
    }
}

/*!
    \brief This function configures the source email using parameters defined
           in "config.h" file

    \param[in]      none

    \return         none

    \note

    \warning
*/
static void SetEmail()
{
    SlNetAppSourceEmail_t sourceEmailId;
    SlNetAppSourcePassword_t sourceEmailPwd;
    SlNetAppEmailOpt_t eMailServerSetting;

    memcpy(sourceEmailId.Username,USER,strlen(USER)+1);
    sl_NetAppEmailSet(NETAPP_SOURCE_EMAIL,strlen(USER)+1,
                                            (unsigned char*)&sourceEmailId);

    memcpy(sourceEmailPwd.Password,PASS,strlen(PASS)+1);
    sl_NetAppEmailSet(NETAPP_PASSWORD,strlen(PASS)+1,
                                            (unsigned char*)&sourceEmailPwd);

    eMailServerSetting.Family = AF_INET;
    eMailServerSetting.Port = GMAIL_HOST_PORT;
    eMailServerSetting.Ip = SL_IPV4_VAL(74,125,129,108);
    eMailServerSetting.SecurityMethod = SL_SO_SEC_METHOD_SSLV3;
    eMailServerSetting.SecurityCypher = SL_SEC_MASK_SSL_RSA_WITH_RC4_128_MD5;

    sl_NetAppEmailSet(NETAPP_ADVANCED_OPT,sizeof(SlNetAppEmailOpt_t),
                                        (unsigned char*)&eMailServerSetting);
}

/*!
    \brief Send the email to the preconfigured email ID

    \param[in]      none

    \return         0 for success , -1 otherwise

    \note

    \warning
*/
static int SendEmail()
{
    int Status = -1;

    Status = sl_NetAppEmailSet(NETAPP_DEST_EMAIL,
                               strlen(DESTINATION_EMAIL),
                               (unsigned char *)DESTINATION_EMAIL);
    if(Status < 0) return Status;

    Status = sl_NetAppEmailSet(NETAPP_SUBJECT,
                               strlen(EMAIL_SUBJECT),
                               (unsigned char *)EMAIL_SUBJECT);
    if(Status < 0) return Status;

    Status = sl_NetAppEmailSet(NETAPP_MESSAGE,
                               strlen(EMAIL_MESSAGE),
                               (unsigned char *)EMAIL_MESSAGE);
    if(Status < 0) return Status;

    Status = sl_NetAppEmailConnect();
    if(Status < 0) return Status;

    Status = sl_NetAppEmailSend();
    if(Status < 0) return Status;

    return Status;
}

int main(void)
{
    INT32 retVal = -1;

    /* Stop Watch Dog Timer */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* initialize the LED GPIO */
    initLEDs();

    /* Initialize the Application Uart Interface - Required for logging */
    CLI_Configure();

    /* Initializing the CC3100 device */
    sl_Start(0,0,0);

    /* configure the Source email */
    SetEmail();

    /* Connect to the AP */
    WlanConnect();

    turnLedOff(LED1);
    turnLedOff(LED2);

    /* Read the command over Application UART and process it */
    retVal = SendEmail();
    if (retVal < 0) turnLedOn(LED1);    /* Indicates failed case */
    else            turnLedOn(LED2);    /* Indicates success case */

    /* Disconnect from AP */
    WlanDisconnect();
    return 0;
}
