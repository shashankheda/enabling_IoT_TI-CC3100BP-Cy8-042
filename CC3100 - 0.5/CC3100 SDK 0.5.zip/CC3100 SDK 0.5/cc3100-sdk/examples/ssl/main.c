/*
 * main.c - sample code for using secure socket
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include <string.h>
#include "simplelink.h"

#define SERVER_NAME     "www.google.com"   /* Server URL to connect to. */
#define SSID_NAME       "<ap-name>"        /* Open AP name to connect to. */

#define GOOGLE_DST_PORT     443
#define SL_SSL_CA_CERT      128   /* CA certificate file ID */

#define DATE                9    /* Current Date */
#define MONTH               5     /* Month 1-12 */
#define YEAR                2014  /* Current year */
#define HOUR                12    /* Time - hours */
#define MINUTE              32    /* Time - minutes */
#define SECOND              0     /* Time - seconds */

UINT16          g_ConnectionStatus = 0;
UINT16          g_IpObtained = 0;
char            *g_Google = SERVER_NAME;


/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    This code example assumes the AP doesn't use WIFI security.
    The function will return only once we are connected and have acquired IP
    address

    \param          None

    \return         None

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = "";
    secParams.KeyLen = 0;
    secParams.Type = SL_SEC_TYPE_OPEN;

    sl_WlanConnect(SSID_NAME,strlen(SSID_NAME),0,&secParams,0);

    /* pending on connection success and DHCP success */
    while ((g_ConnectionStatus == 0) || (g_IpObtained == 0))
    {
        _SlNonOsMainLoopTask();
    }
}

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
      case SL_WLAN_CONNECT_EVENT:
        g_ConnectionStatus = 1;
        break;

      case SL_WLAN_DISCONNECT_EVENT:
        g_ConnectionStatus = 0;
        g_IpObtained = 0;
        break;

      default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
      case SL_NETAPP_IPV4_ACQUIRED:
        g_IpObtained = 1;
        break;

      default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this application */
}

/*!
    \brief This updates the date and time of CC3100

    \param[in]      0 for success, negative otherwise

    \return         None

    \note

    \warning
*/
void SetTime()
{
    SlDateTime_t dateTime= {0};

    dateTime.sl_tm_day = DATE;
    dateTime.sl_tm_mon = MONTH;
    dateTime.sl_tm_year = YEAR;
    dateTime.sl_tm_hour = HOUR;
    dateTime.sl_tm_min = MINUTE;
    dateTime.sl_tm_sec = SECOND;

    sl_DevSet(SL_DEVICE_GENERAL_CONFIGURATION,SL_DEVICE_GENERAL_CONFIGURATION_DATE_TIME,
            sizeof(SlDateTime_t),(unsigned char *)(&dateTime));
}

/*!

 \brief  the aim of this example code is to demonstrate how certificate can be
        used with SSL. The procedure includes the following steps:
            1) connect to an open AP
            2) get the server name via a DNS request
            3) define all socket options and point to the CA certificate
            4) connect to the server via TCP

 \param  None

 \return -1 in case of error, 0 otherwise
         Also, LED1 is turned solid in case of success
         LED8 is turned solid in case of failure

 \note  1) With CA certificate, server authentication is applied by the device
        2) It is the responsibility of the user to add the server to connect to
        3) It is the responsibility of the user to add the AP to connect to


 \warning   It is assumed that a CA certificate already exists in file ID 128

*/

int main(void)
{
    SlSockSecureFiles_t sockSecureFiles;
    SlSockAddrIn_t      Addr;

    UINT32  cipher = SL_SEC_MASK_SSL_RSA_WITH_RC4_128_SHA;
    UINT32  googleIP = 0;
    UINT8   method = SL_SO_SEC_METHOD_SSLV3;

    INT32   AddrSize = -1;
    INT32   g_SockID = -1;
    INT32   retVal = -1;

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initialize the LEDs */
    initLEDs();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* connecting to an AP with Internet Uplink connection*/
    WlanConnect();

    /* Update the CC3100 time */
    SetTime();

    /* get the server name via a DNS request */
    retVal = sl_NetAppDnsGetHostByName(g_Google, strlen(g_Google),
                                       &googleIP, SL_AF_INET);
    if( retVal < 0 )
    {
        turnLedOn(LED1);
        return -1;
    }

    Addr.sin_family = SL_AF_INET;
    Addr.sin_port = sl_Htons(GOOGLE_DST_PORT);
    Addr.sin_addr.s_addr = sl_Htonl(googleIP);

    AddrSize = sizeof(SlSockAddrIn_t);

    /* opens a secure socket */
    g_SockID = sl_Socket(SL_AF_INET,SL_SOCK_STREAM, SL_SEC_SOCKET);
    if( g_SockID < 0 )
    {
        turnLedOn(LED1);
        return -1;
    }

    /* configure the socket as SSLV3.0 */
    retVal = sl_SetSockOpt(g_SockID, SL_SOL_SOCKET, SL_SO_SECMETHOD,
                           &method, sizeof(method));
    if( retVal < 0 )
    {
        turnLedOn(LED1);
        return -1;
    }

    /* configure the socket as RSA with RC4 128 SHA */
    retVal = sl_SetSockOpt(g_SockID, SL_SOL_SOCKET, SL_SO_SECURE_MASK,
                           &cipher, sizeof(cipher));
    if( retVal < 0 )
    {
        turnLedOn(LED1);
        return -1;
    }

    /* configure the socket with GOOGLE CA certificate-for server verification*/
    sockSecureFiles.secureFiles[0] = 0;
    sockSecureFiles.secureFiles[1] = 0;
    sockSecureFiles.secureFiles[2] = SL_SSL_CA_CERT;
    sockSecureFiles.secureFiles[3] = 0;
    retVal = sl_SetSockOpt(g_SockID, SL_SOL_SOCKET, SL_SO_SECURE_FILES,
                           sockSecureFiles.secureFiles, sizeof(sockSecureFiles));
    if( retVal < 0 )
    {
        turnLedOn(LED1);
        return -1;
    }

    /* connect to the peer device - GMail server */
    retVal = sl_Connect(g_SockID, ( SlSockAddr_t *)&Addr, AddrSize);
    if (retVal < 0 )
    {
        turnLedOn(LED1);
        return -1;
    }

    /* Turn On the Green LED */
    turnLedOn(LED2);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
