For information on this example refer to:
docs\examples\ssl.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_SSL_Demo_Application