/*
 * main.c - sample application for AP provisioning
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "simplelink.h"


#define AP_SSID_NAME    "CC3100_PROVISIONING_AP"
#define NO_AP        "__No_AP_Available__"

#define SCAN_TABLE_SIZE  20
#define SCAN_INTERVAL    10

#define GET_TOKEN    "__SL_G_U"

#define GET_STATUS   "__SL_G_S.0"

enum
{
    CONNECTED = 0x01,
    IP_ACQUIRED = 0x02,
    PROFILE_ADDED = 0x04,
    CONNECTED_TO_CONF_AP = 0x08,
    PROVISIONING_DONE = 0x10
}e_Stauts;

UINT8 g_Status = 0;
UINT32   g_ConnectTimeoutCnt = 0;

char g_Wlan_SSID[MAXIMAL_SSID_LENGTH + 1];
char g_Wlan_Security_Key[50];

Sl_WlanNetworkEntry_t g_netEntries[SCAN_TABLE_SIZE];
UINT8 g_ssid_list[SCAN_TABLE_SIZE][MAXIMAL_SSID_LENGTH + 1];
SlSecParams_t g_secParams;

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
      case SL_WLAN_CONNECT_EVENT:
        g_Status |= CONNECTED;
        break;

      case SL_WLAN_DISCONNECT_EVENT:
        g_Status &= ~(CONNECTED + IP_ACQUIRED);
        break;

      default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
      case SL_NETAPP_IPV4_ACQUIRED:
        g_Status |= IP_ACQUIRED;
        break;

      default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pEvent,
                                  SlHttpServerResponse_t *pResponse)
{
    switch (pEvent->Event)
    {
        case SL_NETAPP_HTTPGETTOKENVALUE:
        {
            UINT8 *ptr;
            UINT8 num = 0;

            if (0== memcmp (pEvent->EventData.httpTokenName.data,
                    GET_STATUS,pEvent->EventData.httpTokenName.len))
            {
                /* Token to get the connection status */
                if(g_Status & CONNECTED_TO_CONF_AP)
                {
                    strcpy ((char *)pResponse->ResponseData.token_value.data,
                            "TRUE");
                    pResponse->ResponseData.token_value.len = strlen("TRUE");
                }
                else
                {
                    strcpy ((char *)pResponse->ResponseData.token_value.data,
                            "FALSE");
                    pResponse->ResponseData.token_value.len = strlen("FALSE");
                }
            }
            else
            {
                /* Token to get the AP list */
                ptr = pResponse->ResponseData.token_value.data;
                pResponse->ResponseData.token_value.len = 0;
                if(memcmp(pEvent->EventData.httpTokenName.data, GET_TOKEN,strlen(GET_TOKEN)) == 0)
                {
                    num = pEvent->EventData.httpTokenName.data[8] - '0';
                    num *= 10;
                    num += pEvent->EventData.httpTokenName.data[9] - '0';

                    if(g_ssid_list[num][0] == '\0')
                    {
                        strcpy((char *)ptr, NO_AP);
                    }
                    else
                    {
                        strcpy((char *)ptr, (char *)g_ssid_list[num]);
                    }
                    pResponse->ResponseData.token_value.len = strlen((const char *)ptr);
                }
            }
            break;
        }

        case SL_NETAPP_HTTPPOSTTOKENVALUE:
        {
            if ((0 == memcmp(pEvent->EventData.httpPostData.token_name.data, "__SL_P_U.C", pEvent->EventData.httpPostData.token_name.len)) &&
                (0 == memcmp(pEvent->EventData.httpPostData.token_value.data, "Connect", pEvent->EventData.httpPostData.token_value.len)))
            {
                g_Status &= ~PROFILE_ADDED;
            }
            if (0 == memcmp (pEvent->EventData.httpPostData.token_name.data, "__SL_P_U.D", pEvent->EventData.httpPostData.token_name.len))
            {
                memcpy (g_Wlan_SSID,  pEvent->EventData.httpPostData.token_value.data, pEvent->EventData.httpPostData.token_value.len);
                g_Wlan_SSID[pEvent->EventData.httpPostData.token_value.len] = 0;
            }
            if (0 == memcmp (pEvent->EventData.httpPostData.token_name.data, "__SL_P_U.E", pEvent->EventData.httpPostData.token_name.len))
            {
                if (pEvent->EventData.httpPostData.token_value.data[0] == '0')
                {
                    g_secParams.Type =  SL_SEC_TYPE_OPEN;

                }
                else if (pEvent->EventData.httpPostData.token_value.data[0] == '1')
                {
                    g_secParams.Type =  SL_SEC_TYPE_WEP;

                }
                else if (pEvent->EventData.httpPostData.token_value.data[0] == '2')
                {
                    g_secParams.Type =  SL_SEC_TYPE_WPA;
                }
                else if (pEvent->EventData.httpPostData.token_value.data[0] == '3')
                {
                    g_secParams.Type =  SL_SEC_TYPE_WPA;
                }
            }
            if (0 == memcmp (pEvent->EventData.httpPostData.token_name.data, "__SL_P_U.F", pEvent->EventData.httpPostData.token_name.len))
            {
                memcpy (g_Wlan_Security_Key,pEvent->EventData.httpPostData.token_value.data, pEvent->EventData.httpPostData.token_value.len);
                g_Wlan_Security_Key[pEvent->EventData.httpPostData.token_value.len] = 0;
                g_secParams.Key = g_Wlan_Security_Key;
                g_secParams.KeyLen = pEvent->EventData.httpPostData.token_value.len;
            }
            if (0 == memcmp (pEvent->EventData.httpPostData.token_name.data, "__SL_P_U.0", pEvent->EventData.httpPostData.token_name.len))
            {
                g_Status |= PROVISIONING_DONE;
            }
            break;
        }
        default:
            break;
    }
}

/*!
    \brief Connecting to a WLAN Access point

    This function tries to connect to configured AP..
    The function will return once we are connected or the command is timed out

    \param          None

    \return         None

    \note
*/
static void WlanConnect()
{
    sl_WlanConnect(g_Wlan_SSID,strlen(g_Wlan_SSID),0,&g_secParams,0);

    /* pending on connection success and DHCP success */
    while (g_ConnectTimeoutCnt < 2000 &&
            (!(g_Status & IP_ACQUIRED ) || !(g_Status & CONNECTED)))
    {
        _SlNonOsMainLoopTask();
        Delay(1);
        g_ConnectTimeoutCnt++;
    }
    g_ConnectTimeoutCnt = 0;
}

/*!
    \brief Filter scanned AP list

    This function filters the list the scanned AP and remove the duplicate
    entries.

    \param          None

    \return         None

    \note
*/
static void FilterList()
{
    UINT8 idx1 = 0;
    UINT8 idx2 = 0;

    memset(g_ssid_list, '\0', (SCAN_TABLE_SIZE * (MAXIMAL_SSID_LENGTH + 1)));

    for(idx1=0; idx1 < SCAN_TABLE_SIZE; idx1++)
    {
        if(g_netEntries[idx1].ssid[0] != '\0')
        {
            for(idx2=0; idx2 < SCAN_TABLE_SIZE; idx2++)
            {
                if(strcmp((const char *)g_netEntries[idx1].ssid,
                        (const char *)g_ssid_list[idx2]) == 0)
                    break;
                if(g_ssid_list[idx2][0] == '\0')
                {
                    strcpy((char *)g_ssid_list[idx2],
                            (const char *)g_netEntries[idx1].ssid);
                    break;
                }
            }
        }
    }
}

/*!
    \brief This function implements the ProvisioningAP functionality

    This function
        1. Starts Device in STA Mode
        2. Scans and Stores all the AP
        3. Switch to AP Mode and Wait for AP Configuration from Browser
        4. Switch to STA Mode and Connect to Configured AP

    \param          None

    \return         None
*/
static void ProvisioningAP()
{
    UINT32 intervalInSeconds = SCAN_INTERVAL;
    unsigned char SecType = 0;

    g_Status |= PROFILE_ADDED;

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* Switch to station mode */
    sl_WlanSetMode(ROLE_STA);

    SecType = SL_SEC_TYPE_OPEN;
    /* configure the device SSID and security in AP mode */
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SSID,
                strlen(AP_SSID_NAME), (unsigned char *)AP_SSID_NAME);
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SECURITY_TYPE, 1,
            (unsigned char *)&SecType);

    /* Delete all stored profiles */
    sl_WlanProfileDel(0xFF);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    g_Status &= ~(IP_ACQUIRED + CONNECTED);

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);


    while(!(g_Status & PROVISIONING_DONE))
    {

        /* Set the scan policy */
        sl_WlanPolicySet(SL_POLICY_SCAN,SL_SCAN_POLICY_EN(1),
                (unsigned char *)&intervalInSeconds,sizeof(intervalInSeconds));

        /* wait for 250 ms to make sure scan has started */
        Delay(250);

        /* Get the scan results */
        sl_WlanGetNetworkList(0,20,&g_netEntries[0]);

        /* Remove duplicate entries */
        FilterList();

        /* Switch to AP Mode */
        sl_WlanSetMode(ROLE_AP);

        /* Stop the CC3100 device */
        sl_Stop(0xFF);

        g_Status &= ~(IP_ACQUIRED + CONNECTED);

        /* Initializing the CC3100 device */
        sl_Start(0, 0, 0);

        /* Wait for CC3100 to Acquired IP in AP Mode */
        while (!(g_Status & IP_ACQUIRED))
        {
            _SlNonOsMainLoopTask();
        }

        /* Wait for AP Configuration */
        while ((g_Status & PROFILE_ADDED) && !(g_Status & PROVISIONING_DONE))
        {
            _SlNonOsMainLoopTask();
        }

        g_Status |= PROFILE_ADDED;

        /* Switch to STA Mode */
        sl_WlanSetMode(ROLE_STA);

        /* AP Configured, Restart in STA Mode */
        sl_Stop(0xFF);

        g_Status &= ~(IP_ACQUIRED + CONNECTED);

        sl_Start(0, 0, 0);

        /* Tries to connect to configured AP */
        WlanConnect();

        if(g_Status & CONNECTED)
            g_Status |= CONNECTED_TO_CONF_AP;
        else
            g_Status &= ~CONNECTED_TO_CONF_AP;

        if (!(g_Status & PROVISIONING_DONE))
            sl_WlanDisconnect();
    }

    while(1)
        _SlNonOsMainLoopTask();
}




int main(void)
{
    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Switch to AP mode and wait for provisioning to complete */
    ProvisioningAP();

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
