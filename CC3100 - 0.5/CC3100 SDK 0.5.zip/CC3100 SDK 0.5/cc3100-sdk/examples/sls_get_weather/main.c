/*
 * main.c - get weather details sample application
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/


#include <string.h>
#include <windows.h>
#include <stdio.h>

#include "simplelink.h"

#define WEATHER_SERVER      "openweathermap.org"

#define BAUD_RATE           115200
#define MAX_RECV_BUFF_SIZE  1024
#define MAX_SEND_BUFF_SIZE  512
#define MAX_CITY_NAME_SIZE  64
#define MAX_HOSTNAME_SIZE   40
#define MAX_PASSKEY_SIZE    32
#define MAX_SSID_SIZE       32

#define PREFIX_BUFFER       "GET /data/2.5/weather?q="
#define POST_BUFFER         "&mode=xml&units=imperial HTTP/1.1\r\nHost:api.openweathermap.org\r\nAccept: */"
#define POST_BUFFER2        "*\r\n\r\n"

#define SUCCESS             0

#ifdef SL_IF_TYPE_UART
#define COMM_PORT_NUM 10
SlUartIfParams_t params;
#endif /* SL_IF_TYPE_UART */

typedef struct{
    UINT8 SSID[MAX_SSID_SIZE];
    INT32 encryption;
    UINT8 password[MAX_PASSKEY_SIZE];
}UserInfo;

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02

}e_Status;
UINT8 g_Status = 0;;

struct
{
    char Recvbuff[MAX_RECV_BUFF_SIZE];
    char SendBuff[MAX_SEND_BUFF_SIZE];

    char HostName[MAX_HOSTNAME_SIZE];
    char CityName[MAX_CITY_NAME_SIZE];

    unsigned long DestinationIP;
    int SockID;
}appData;

/*!
    \brief Read option fron the user

    \param[in]      none

    \return         int - user option value

    \note

    \warning
*/
int GetUserNum()
{
    UINT8 input[10] = {'\0'};
    UINT8 flag = 0;
    INT32 value = -1;

    while (!flag)
    {
        if (scanf_s("%s",input,sizeof(input)) != 0)
        {
            value = atoi(input);
            if (value > 0 && value < 5 )
            {
                flag = 1;
            }
            else
            {
                printf("Invalid entry. Please try again:\n");
            }
        }
    }

    return value;
}

/*!
    \brief Get the AP parameters from the user

    \param[in]      none

    \return         UserInfo - structure containg SSID, encryption type and
                    pass key of AP

    \note

    \warning
*/
UserInfo GetUserInput ()
{
    UserInfo UserFunction;
    INT32 eflag = -1;
    INT32 wepflag = -1;
    INT32 length = -1;

    printf("Please input the SSID you wish to connect to: \n");
    scanf_s("%s",UserFunction.SSID,MAX_SSID_SIZE);

    printf("Encryption Types:\n");
    printf("1:  Open\n");
    printf("2:  WEP\n");
    printf("3:  WPA\n");
    printf("Please enter the corresponding number for the encryption type: \n");
    UserFunction.encryption = GetUserNum();

    if (2 == UserFunction.encryption || /* WEP */
        3 == UserFunction.encryption)   /* WAP */
    {
        printf("Please enter the password: \n");
        scanf_s("%s",UserFunction.password,MAX_PASSKEY_SIZE);
    }

    return UserFunction;
}

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         none

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
        case SL_WLAN_CONNECT_EVENT:
            g_Status |= CONNECTED;
        break;

        case SL_WLAN_DISCONNECT_EVENT:
            g_Status &= ~(1 << CONNECTION_STATUS_BIT | 1 << IP_AQUIRED_STATUS_BIT);
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_AQUIRED;
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}

/*!
    \brief This function Obtains the required data from the server

    \param[in]      none

    \return         None

    \note

    \warning
*/
void GetData()
{
    INT8 *p_startPtr = NULL;
    INT8 *p_endPtr = NULL;
    INT8 *p_bufLocation = NULL;

    memset(appData.Recvbuff, 0, sizeof(appData.Recvbuff));

    /* Puts together the HTTP GET string. */
    p_bufLocation = appData.SendBuff;
    memcpy(p_bufLocation, PREFIX_BUFFER,strlen(PREFIX_BUFFER));

    p_bufLocation += strlen(PREFIX_BUFFER);
    memcpy(p_bufLocation , appData.CityName,strlen(appData.CityName));

    p_bufLocation += strlen(appData.CityName);
    memcpy(p_bufLocation, POST_BUFFER,strlen(POST_BUFFER));

    p_bufLocation += strlen(POST_BUFFER);
    memcpy(p_bufLocation, POST_BUFFER2,strlen(POST_BUFFER2));

    /* Send the HTTP GET string to the open TCP/IP socket. */
    sl_Send(appData.SockID, appData.SendBuff, strlen(appData.SendBuff), 0);

    /* Receive response */
    sl_Recv(appData.SockID, &appData.Recvbuff[0], MAX_RECV_BUFF_SIZE, 0);
    appData.Recvbuff[strlen(appData.Recvbuff)] = '\0';

    /*Get ticker name*/
    p_startPtr = strstr(appData.Recvbuff, "name=");
    if( NULL != p_startPtr )
    {
        p_startPtr = p_startPtr + strlen("name=") + 1;
        p_endPtr = strstr(p_startPtr, "\">");
        if( NULL != p_endPtr )
        {
            *p_endPtr = 0;
        }
    }

    printf("\n************************ \n\r");
    printf("City: \n");
    if(p_startPtr == NULL)
    {
        printf("N/A\n\r");
    }
    else
    {
        printf("%s\n\r",p_startPtr);
    }

    if(p_endPtr == NULL)
    {
        printf("Error during parsing the data.\r\n");
        return;
    }

    /* Get Temperature Value */
    p_startPtr = strstr(p_endPtr+1, "temperature value");
    if( NULL != p_startPtr )
    {
        p_startPtr = p_startPtr + strlen("temperature value") + 2;
        p_endPtr = strstr(p_startPtr, "\" ");
        if( NULL != p_endPtr )
        {
            *p_endPtr = 0;
        }
    }

    printf("Temperature: \n");
    if(p_startPtr == NULL)
    {
        printf("N/A\n\r");
        return;
    }
    else
    {
        printf("%s F\n\r",p_startPtr);
    }

    /* Get weather */
    p_startPtr = strstr(p_endPtr+1, "weather number");
    if( NULL != p_startPtr )
    {
        p_startPtr = p_startPtr + strlen("weather number") + 14;
        p_endPtr = strstr(p_startPtr, "\" ");
        if( NULL != p_endPtr )
        {
            *p_endPtr = 0;
        }
    }

    printf("Weather Condition: \n");
    if(p_startPtr == NULL)
    {
        printf("N/A\n\r");
    }
    else
    {
        printf("%s\n\r",p_startPtr);
    }
    printf("\n************************ \n\r");
}

/*!
    \brief Create TCP connection with openweathermap.org

    \param[in]      none

    \return         Socket descriptor for success otherwise negative

    \warning
*/
int CreateConnection()
{
    SlSockAddrIn_t  Addr;

    INT32 sd = 0;
    INT32 AddrSize = 0;
    INT16 ret_val = 0;

    Addr.sin_family = SL_AF_INET;
    Addr.sin_port = sl_Htons(80);

    /* Change the DestinationIP endianity, to big endian */
    Addr.sin_addr.s_addr = sl_Htonl(appData.DestinationIP);

    AddrSize = sizeof(SlSockAddrIn_t);

    sd = sl_Socket(SL_AF_INET,SL_SOCK_STREAM, 0);
    if( sd < 0 )
    {
        printf("Error creating socket\n\r");
        return sd;
    }

    ret_val = sl_Connect(sd, ( SlSockAddr_t *)&Addr, AddrSize);
    if( ret_val < 0 )
    {
        /* error */
        printf("Error connecting to socket\n\r");
        return ret_val;
    }

    return sd;
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the AP (SSID_NAME).
    The function will return once we are connected and have acquired IP address

    \param[in]  UserParams - Structure having SSID, security type and pass key
                of AP to connect

    \return         0 for success and negative for error

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
int WlanConnect(UserInfo UserParams)
{
    SlSecParams_t secParams;
    INT32 status = -1;

    if (UserParams.encryption == 1)
    {
        secParams.Key = "";
        secParams.KeyLen = 0;
        secParams.Type = SL_SEC_TYPE_OPEN;
    }

    else
    {
        secParams.Key = UserParams.password;
        secParams.KeyLen = strlen(UserParams.password);

        if (UserParams.encryption == 2) secParams.Type = SL_SEC_TYPE_WEP;
        if (UserParams.encryption == 3) secParams.Type = SL_SEC_TYPE_WPA;
    }


    status = sl_WlanConnect(UserParams.SSID,strlen(UserParams.SSID),
                                                        0, &secParams, 0);
    if ( status == SUCCESS )
    {
        printf("Connecting to AP %s...\n", UserParams.SSID  );
        while ((0 == (g_Status & CONNECTED)) || (0 == (g_Status & IP_AQUIRED)))
            ;

        printf("Connected to AP %s. IP acquired.\n", UserParams.SSID );
    }
    else
        printf("Can't establish connection to AP %s.\n", UserParams.SSID);

    return status;
}

/*!
    \brief This function obtains the server IP address

    \param[in]      none

    \return         zero for success and -1 for error

    \warning
*/
int GetHostIP()
{
    INT32 status = -1;

    status = sl_NetAppDnsGetHostByName(appData.HostName,
                                       strlen(appData.HostName),
                                       &appData.DestinationIP, SL_AF_INET);
    if (status != 0)
    {
        printf("Unable to reach Host\n");
        return -1;
    }

    return 0;
}

/*!
    \brief Get the Weather from server

    \param[in]      none

    \return         zero for success and -1 for error

    \warning
*/
int getWeather()
{
    UINT32 i = 0;
    UINT8 readBuff[MAX_CITY_NAME_SIZE] = {'\0'};
    UserInfo User;

    User = GetUserInput();

    memcpy(appData.HostName,WEATHER_SERVER,strlen(WEATHER_SERVER));

    if( WlanConnect(User) != SUCCESS )
        return -1;

    if(GetHostIP() == 0)
    {
        while (1)
        {
            if( (appData.SockID = CreateConnection()) < 0 ) return -1;

            printf("\n\rEnter the city name or \"QUIT\" to quit#: \n");
            scanf_s("%s",readBuff,MAX_CITY_NAME_SIZE);

            memset(appData.CityName, 0x00, sizeof(appData.CityName));

            for(i = 0; *(readBuff+i) != '\0'; i++)
            {
                appData.CityName[i] = *(readBuff+i);
            }

            if(!strcmp(appData.CityName,"QUIT") || !strcmp(appData.CityName,"quit"))
                break;

            GetData();
            sl_Close(appData.SockID);
        }
    }

    printf("\n\rThank you!\n\r\n\r");
	return 0;
}

int main(void)
{
    INT32 ret = 0;
    INT8 *pConfig = NULL;

#ifdef SL_IF_TYPE_UART
    params.BaudRate = BAUD_RATE;
    params.FlowControlEnable = 1;
    params.CommPort = COMM_PORT_NUM;

    pConfig = (char *)&params;
#endif /* SL_IF_TYPE_UART */

    /*This line is for Eclipse CDT only due to a known bug in console buffering
    * See https://bugs.eclipse.org/bugs/show_bug.cgi?id=173732 */
    setvbuf(stdout, NULL, _IONBF, 0);

    /* Initializing the CC3100 device */
    sl_Start(0, pConfig, 0);

    printf("\n\rStarted Get-Weather Application\n\r\n\r");

    ret = getWeather();

    return ret;
}

