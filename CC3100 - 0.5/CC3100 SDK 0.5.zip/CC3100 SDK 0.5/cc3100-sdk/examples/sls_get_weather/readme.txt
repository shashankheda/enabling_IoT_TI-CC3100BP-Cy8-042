For information on this example refer to:
docs\examples\sls_get_weather.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_SLS_Get_Weather_Application