/*
 * main.c - sample code for using transceiver mode
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "simplelink.h"

/* Power level tone valid range 0-15 */
#define POWER_LEVEL_TONE    1
/* Preamble value 0- short, 1- long */
#define PREAMBLE            1

#define RATE                RATE_11M

/* Channel (1-13) used during the tx and rx*/
#define CHANNEL             11

#define BUF_SIZE 1400
#define NO_OF_PACKETS 100

union
{
  char BsdBuf[BUF_SIZE];
  UINT32 demobuf[BUF_SIZE/4];
} uBuf;

enum
{
    CONNECTED = 0x1
}e_Stauts;

UINT8 g_Status = 0;

char RawData_Ping[] = {
                   0x88,   /* version , type sub type */
                   0x02,   /* Frame control flag */
                   0x2C, 0x00,
                   0x00, 0x23, 0x75, 0x55,0x55, 0x55,   /* destination */
                   0x00, 0x22, 0x75, 0x55,0x55, 0x55,   /* bssid */
                   0x00, 0x22, 0x75, 0x55,0x55, 0x55,   /* source */
                   0x80, 0x42, 0x00, 0x00,
                   0xAA, 0xAA, 0x03, 0x00, 0x00, 0x00, 0x08, 0x00, /* LLC */
                   /*---- ip header start -----*/
                   0x45, 0x00, 0x00, 0x54, 0x96, 0xA1, 0x00, 0x00, 0x40, 0x01,
                   0x57, 0xFA,                          /* checksum */
                   0xc0, 0xa8, 0x01, 0x64,              /* src ip */
                   0xc0, 0xa8, 0x01, 0x65,              /* dest ip  */
                   /* payload - ping/icmp */
                   0x08, 0x00, 0xA5, 0x51,
                   0x5E, 0x18, 0x00, 0x00, 0x41, 0x08, 0xBB, 0x8D, 0x00, 0x00,
                   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                   0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
                   0x00, 0x00, 0x00, 0x00};


/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
      case SL_WLAN_CONNECT_EVENT:
          g_Status |= CONNECTED;
        break;
      case SL_WLAN_DISCONNECT_EVENT:
          g_Status &= ~CONNECTED;
        break;
      default:
        break;
    }
}


/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    /* Not used in this application */
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
        SlHttpServerResponse_t *pHttpResponse)
{
    /* Not used in this application */
}

/*!
    \brief Entering raw Transmitter\Receiver mode in order to send raw data
           over the WLAN PHY

    This function shows how to send raw data, in this case ping packets over
    the air in transmitter mode.

    \param[in]      Channel number on which the data will be sent

    \return         0 on success, Negative on Error.

    \note

    \warning        We must be disconnected from WLAN AP in order to succeed
                    changing to transmitter mode
*/
static INT16 TxContinues(int channel)
{
    INT16 SockID = 0;
    INT16 Status = 0;
    UINT16 Len = 0;
    INT16 count = 0;

    /* validate device is not connected */
    sl_WlanDisconnect();
    while (g_Status & CONNECTED)
    {
        _SlNonOsMainLoopTask();
    }

    /* make sure device is disconnected & auto mode is off */
    SockID = sl_Socket(SL_AF_RF,SL_SOCK_RAW,channel);

    if(SockID < 0)
        return -1;

    Len = sizeof(RawData_Ping);

    while (count < NO_OF_PACKETS)
    {
        Status = sl_Send(SockID, RawData_Ping, Len,
               SL_RAW_RF_TX_PARAMS(channel, RATE, POWER_LEVEL_TONE, PREAMBLE));
        if( Status < 0 )
        {
            return -1;
        }
        count++;
        /* 100 ms Delay between each packet*/
        Delay(100);
    }

    sl_Close(SockID);

    return 0;
}


/*!
    \brief Entering raw Transmitter\Receiver mode in order to perform Rx
           statistic over a specific WLAN channel


    \param[in]      Channel number on which the statistics will be calculated

    \return         0 on success, Negative on Error.

    \note

    \warning        We must be disconnected from WLAN AP in order to succeed
                    changing to Receiver mode
*/
static INT16 RxStatisticsCollect(int channel)
{
    SlGetRxStatResponse_t rxStatResp;

    INT16 SockID = 0;
    INT16 Status = 0;

    /* validate device is not connected */
    sl_WlanDisconnect();
    while (g_Status & CONNECTED)
    {
        _SlNonOsMainLoopTask();
    }

    SockID = sl_Socket(SL_AF_RF,SL_SOCK_RAW,channel);

    if(SockID < 0)
        return -1;

    /*We need to call sl_Recv() at least once before starting Rx statistics
    * engine */
    Status = sl_Recv(SockID, uBuf.BsdBuf, BUF_SIZE, 0);
    if (Status < 0)
    {
        sl_Close(SockID);
        return Status;
    }

    /* starting to collect statistics */
    Status = sl_WlanRxStatStart();
    if (Status < 0)
    {
        sl_Close(SockID);
        return Status;
    }

    /* Delay of 2 second to give CC3100 time to collect statistics */
    Delay(2000);

    /* Get the statistics */
    Status = sl_WlanRxStatGet(&rxStatResp, 0);
    if (Status < 0)
    {
        sl_Close(SockID);
        return Status;
    }

    /* ********** Rx Statistics*********/
    /* Received Packets = rxStatResp.ReceivedValidPacketsNumber */
    /* Received FCS = rxStatResp.ReceivedFcsErrorPacketsNumber */
    /* Received PLCP = rxStatResp.ReceivedPlcpErrorPacketsNumber */
    /* Average Rssi for management = rxStatResp.AvarageMgMntRssi */
    /* Average Rssi for other packets = rxStatResp.AvarageDataCtrlRssi */
    /* Rssi Histogram cell = rxStatResp.RssiHistogram[i],
                                            i:{0,SIZE_OF_RSSI_HISTOGRAM} */
    /* Rate Histogram cell = rxStatResp.RateHistogram[i],
                                            i:{0,NUM_OF_RATE_INDEXES} */
    /* Sample Time = rxStatResp.GetTimeStamp - rxStatResp.StartTimeStamp */

    sl_WlanRxStatStop();

    sl_Close(SockID);

    return 0;
}

int main(void)
{
    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* Transmits raw packets over the configured channel. There should be
     * minimum 50 ms delay between each packet */
    TxContinues(CHANNEL);

    /* Wait 500 msec */
    Delay(500);

    RxStatisticsCollect(CHANNEL);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
