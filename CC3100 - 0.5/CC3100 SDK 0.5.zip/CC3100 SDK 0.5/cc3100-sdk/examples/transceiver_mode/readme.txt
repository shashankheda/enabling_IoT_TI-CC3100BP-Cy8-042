For information on this example refer to:
docs\examples\transceiver_mode.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Transceiver_Mode_Application