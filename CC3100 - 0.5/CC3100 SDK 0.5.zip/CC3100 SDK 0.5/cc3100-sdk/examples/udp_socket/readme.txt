For information on this example refer to:
docs\examples\udp_socket.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_UDP_Socket_Application