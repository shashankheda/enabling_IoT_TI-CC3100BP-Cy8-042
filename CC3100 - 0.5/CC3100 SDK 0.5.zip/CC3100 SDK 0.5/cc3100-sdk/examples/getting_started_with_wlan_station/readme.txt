For information on this example refer to:
docs\examples\getting_started_with_wlan_station.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Getting_Started_with_WLAN_Station