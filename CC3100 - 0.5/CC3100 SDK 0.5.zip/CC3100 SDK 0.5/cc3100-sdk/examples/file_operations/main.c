/*
 * main.c - nevmem application
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/
#include <string.h>
#include "simplelink.h"

#define SL_FILE_NAME    "MacDonalds.txt"
#define BUF_SIZE        2048

#define SIZE_64K        65536

union
{
    UINT8 g_Buf[BUF_SIZE];
    UINT32 demobuf[BUF_SIZE/4];
} uNvmemBuf;

const UINT8    oldMacDonald[] = "Old MacDonald had a farm,E-I-E-I-O, \
        And on his farm he had a cow, \
        E-I-E-I-O, \
        With a moo-moo here, \
        And a moo-moo there, \
        Here a moo, there a moo, \
        Everywhere a moo-moo. \
        Old MacDonald had a farm, \
        E-I-E-I-O. \
        Old MacDonald had a farm, \
        E-I-E-I-O, \
        And on his farm he had a pig, \
        E-I-E-I-O, \
        With an oink-oink here, \
        And an oink-oink there, \
        Here an oink, there an oink, \
        Everywhere an oink-oink. \
        Old MacDonald had a farm, \
        E-I-E-I-O. \
        Old MacDonald had a farm, \
        E-I-E-I-O, \
        And on his farm he had a duck, \
        E-I-E-I-O, \
        With a quack-quack here, \
        And a quack-quack there, \
        Here a quack, there a quack, \
        Everywhere a quack-quack. \
        Old MacDonald had a farm, \
        E-I-E-I-O. \
        Old MacDonald had a farm, \
        E-I-E-I-O, \
        And on his farm he had a horse, \
        E-I-E-I-O, \
        With a neigh-neigh here, \
        And a neigh-neigh there, \
        Here a neigh, there a neigh, \
        Everywhere a neigh-neigh. \
        Old MacDonald had a farm, \
        E-I-E-I-O. \
        Old MacDonald had a farm, \
        E-I-E-I-O, \
        And on his farm he had a donkey, \
        E-I-E-I-O, \
        With a hee-haw here, \
        And a hee-haw there, \
        Here a hee, there a hee, \
        Everywhere a hee-haw. \
        Old MacDonald had a farm, \
        E-I-E-I-O. \
        Old MacDonald had a farm, \
        E-I-E-I-O, \
        And on his farm he had some chickens, \
        E-I-E-I-O, \
        With a cluck-cluck here, \
        And a cluck-cluck there, \
        Here a cluck, there a cluck, \
        Everywhere a cluck-cluck. \
        Old MacDonald had a farm, \
        E-I-E-I-O.";


/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    /* Unused in this application */
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    /* Unused in this application */
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this application */
}

/*!

 \brief The aim of this example code is to demonstrate NVMEM capabilities of
        the device.
        The procedure includes the following steps:
            1) open/Create a user file for writing
            2) write "Old MacDonalds" child song 36 times to get just below a
               63KB file
            3) close the user file
            4) open the user file for reading
            5) read the data and compare with the stored buffer
            6) close the user file
            7) Delete the file

 \param             None

 \return            -1 or -2 in case of error, 0 otherwise
                    Also, LED2 is turned solid in case of success
                    LED1 is turned solid in case of failure

 \note

 \warning

*/

int main(void)
{
    INT32         fileHandle = -1;

    UINT32        Token = 0;
    UINT16        loop = 0;
    INT32         retVal = 0;

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initialize the LED */
    initLEDs();

    /* Initializing the CC3100 device */
    sl_Start(0, 0, 0);

    /* open a user file for writing */
    retVal = sl_FsOpen((unsigned char *)SL_FILE_NAME,
                       _FS_MODE_OPEN_WRITE, &Token, &fileHandle);
    if(retVal < 0)
    {
        /* File Doesn't exit create a new of 63 KB file */
        retVal = sl_FsOpen((unsigned char *)SL_FILE_NAME,
                           FS_MODE_OPEN_CREATE(SIZE_64K,_FS_FILE_OPEN_FLAG_COMMIT|_FS_FILE_PUBLIC_WRITE),
                           &Token, &fileHandle);
        if(retVal < 0)
        {
            turnLedOn(LED1);
            return -1;
        }
    }

    /*write "Old MacDonalds" child song 36 times to get just below a 63KB size*/
    for (loop = 0; loop < 36; loop++)
    {
        retVal = sl_FsWrite(fileHandle, (UINT32)(loop * sizeof(oldMacDonald)),
                                 (UINT8 *)oldMacDonald, sizeof(oldMacDonald));
        if (retVal < 0)
        {
            retVal = sl_FsClose(fileHandle, 0, 0, 0);
            retVal = sl_FsDel((unsigned char *)SL_FILE_NAME, Token);
            turnLedOn(LED1);
            return -1;
        }
    }

    /* close the user file */
    retVal = sl_FsClose(fileHandle, 0, 0, 0);
    if (retVal < 0)
    {
        retVal = sl_FsDel((unsigned char *)SL_FILE_NAME, Token);
        turnLedOn(LED1);
        return -1;
    }

    /* open a user file for reading */
    retVal = sl_FsOpen((unsigned char *)SL_FILE_NAME,
                       _FS_MODE_OPEN_READ, &Token, &fileHandle);
    if (retVal < 0)
    {
        retVal = sl_FsDel((unsigned char *)SL_FILE_NAME, Token);
        turnLedOn(LED1);
        return -1;
    }

    /* read the data and compare with the stored buffer */
    memset(&uNvmemBuf.g_Buf[0], '\0', BUF_SIZE);
    for (loop = 0; loop < 36; loop++)
    {
        retVal = sl_FsRead(fileHandle, (UINT32)(loop * sizeof(oldMacDonald)),
                           uNvmemBuf.g_Buf, sizeof(oldMacDonald));
        if ( (retVal < 0) ||
             (retVal != sizeof(oldMacDonald)) )
        {
            retVal = sl_FsClose(fileHandle, 0, 0, 0);
            retVal = sl_FsDel((unsigned char *)SL_FILE_NAME, Token);
            turnLedOn(LED1);
            return -1;
        }

        retVal = memcmp(oldMacDonald, uNvmemBuf.g_Buf, sizeof(oldMacDonald));
        if (retVal != 0)
        {
            turnLedOn(LED1);
            return -2;
        }
    }

    /* close the user file */
    retVal = sl_FsClose(fileHandle, 0, 0, 0);
    if (retVal < 0)
    {
        retVal = sl_FsDel((unsigned char *)SL_FILE_NAME, Token);
        turnLedOn(LED1);
        return -1;
    }

    /* Delete the user file */
    retVal = sl_FsDel((unsigned char *)SL_FILE_NAME, Token);
    if(retVal < 0)
    {
        turnLedOn(LED1);
        return -1;
    }

    /* Turn On the Green LED */
    turnLedOn(LED2);

    /* Stop the CC3100 device */
    sl_Stop(0xFF);

    return 0;
}
