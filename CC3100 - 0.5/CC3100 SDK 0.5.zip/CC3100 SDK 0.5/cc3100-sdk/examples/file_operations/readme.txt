For information on this example refer to:
docs\examples\file_operations.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_File_Operations_Application