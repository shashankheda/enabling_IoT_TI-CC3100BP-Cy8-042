For information on this example refer to:
docs\examples\provisioning_wps.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Provisioning_WPS_Application