For information on this example refer to:
docs\examples\spi_debug_tool.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_SPI_Debug_Tool