For information on this example refer to:
docs\examples\get_time.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Get_Time_Application