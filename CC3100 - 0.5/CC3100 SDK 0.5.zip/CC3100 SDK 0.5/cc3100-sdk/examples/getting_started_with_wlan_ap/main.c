/*
 * main.c - sample application to switch to AP mode and ping client
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/



#include "simplelink.h"

#define AP_SSID_NAME    "<ap-name>"         /* SSID of the CC3100 in AP mode */
#define AP_PASSWORD     "<password>"        /* Password of CC3100 AP */
#define SEC_TYPE        SL_SEC_TYPE_OPEN    /* Can take SL_SEC_TYPE_WEP or
                                               SL_SEC_TYPE_WPA as well */

#define CONFIG_IP       SL_IPV4_VAL(192,168,0,1)    /* Static IP to be configured */
#define CONFIG_MASK     SL_IPV4_VAL(255,255,255,0)  /* Subnet Mask for the station */
#define CONFIG_GATEWAY  SL_IPV4_VAL(192,168,0,2)    /* Default Gateway address */
#define CONFIG_DNS      SL_IPV4_VAL(192,168,0,3)    /* DNS Server Address */

#define DHCP_START_IP    SL_IPV4_VAL(192,168,0,100) /* DHCP start IP address */
#define DHCP_END_IP      SL_IPV4_VAL(192,168,0,200) /* DHCP End IP address */

#define IP_LEASE_TIME    3600

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
#define IP_LEASED_STATUS_BIT    2
#define PING_DONE_STATUS_BIT    3
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02,
    IP_LEASED = 0x04,
    PING_DONE = 0x08

}e_Status;
UINT8 g_Status = 0;

unsigned int g_PingPacketsRecv = 0;
unsigned long sta_IP;


/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         none

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    /* Unused in this example */
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
      case SL_NETAPP_IPV4_ACQUIRED:
        g_Status |= IP_AQUIRED;
        break;

      case SL_NETAPP_IP_LEASED:
        sta_IP = pNetAppEvent->EventData.ipLeased.ip_address;
        g_Status |= IP_LEASED;
        break;

      default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}


/*!
    \brief This function handles ping report events

    \param[in]      pPingReport holds the ping report statistics

    \return         None

    \note

    \warning
*/
void SimpleLinkPingReport(SlPingReport_t *pPingReport)
{
    g_Status |= PING_DONE;
    g_PingPacketsRecv = pPingReport->PacketsReceived;
}


int main(void)
{
    SlPingStartCommand_t PingParams;
    SlPingReport_t Report;
    _NetCfgIpV4Args_t ipV4;
    SlNetAppDhcpServerBasicOpt_t dhcpParams;

    unsigned char SecType = 0;
    INT32 mode = ROLE_STA;

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initializing the CC3100 device */
    mode = sl_Start(0, 0, 0);
    if (ROLE_AP == mode)
    {
        /* If some other application has configured the device in AP mode,
           then we need to wait for this event */
        while(0 == (g_Status & IP_AQUIRED)) _SlNonOsMainLoopTask();
    }
    else
    {
        /* Configure CC3100 to start in AP mode */
        sl_WlanSetMode(ROLE_AP);
        sl_Stop(0xFF);
        sl_Start(0, 0, 0);
    }

    /* Configure the SSID of the CC3100 */
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SSID,
            strlen(AP_SSID_NAME), (unsigned char *)AP_SSID_NAME);

    SecType = SEC_TYPE;
    /* Configure the Security parameter in he AP mode */
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SECURITY_TYPE, 1,
            (unsigned char *)&SecType);
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_PASSWORD, strlen(AP_PASSWORD),
            (unsigned char *)AP_PASSWORD);

    ipV4.ipV4 = CONFIG_IP;
    ipV4.ipV4Mask = CONFIG_MASK;
    ipV4.ipV4Gateway = CONFIG_GATEWAY;
    ipV4.ipV4DnsServer = CONFIG_DNS;

    /* Configure the Static IP */
    sl_NetCfgSet(SL_IPV4_AP_P2P_GO_STATIC_ENABLE,1,sizeof(_NetCfgIpV4Args_t),
            (unsigned char *)&ipV4);

    dhcpParams.lease_time      = IP_LEASE_TIME;
    dhcpParams.ipv4_addr_start =  DHCP_START_IP;
    dhcpParams.ipv4_addr_last  =  DHCP_END_IP;

    /* Configure DHCP address range. This step is necessary if the subnet
     * of the IP is changed */
    sl_NetAppStop(SL_NET_APP_DHCP_SERVER_ID);
    sl_NetAppSet(SL_NET_APP_DHCP_SERVER_ID, NETAPP_SET_DHCP_SRV_BASIC_OPT,
            sizeof(SlNetAppDhcpServerBasicOpt_t), (unsigned char*)&dhcpParams);
    sl_NetAppStart(SL_NET_APP_DHCP_SERVER_ID);

    g_Status = 0;

    /* Restart the CC3100 */
    sl_Stop(0x00FF);
    sl_Start(0, 0, 0);

    while((0 == (g_Status & IP_LEASED)) || (0 == (g_Status & IP_AQUIRED)))
    {
        _SlNonOsMainLoopTask();
    }

    /* Set the ping parameters */
    PingParams.PingIntervalTime = 1000;
    PingParams.PingSize = 20;
    PingParams.PingRequestTimeout = 3000;
    PingParams.TotalNumberOfAttempts = 3;
    PingParams.Flags = 0;
    PingParams.Ip = sta_IP; /* Fill the station IP address connected to CC3100 */

    /* Ping client connected to CC3100 */
    sl_NetAppPingStart((SlPingStartCommand_t*)&PingParams, SL_AF_INET,
                       (SlPingReport_t*)&Report, SimpleLinkPingReport);

    while(0 == (g_Status & PING_DONE))
    {
        _SlNonOsMainLoopTask();
    }

    if (g_PingPacketsRecv)
    {
        /* Ping successful */
        return 0;
    }
    else
    {
        /* Problem with Pinging to client */
        return -1;
    }
}
