/*
 * main.c - sample code to switch b/w STA and AP mode
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include "simplelink.h"

/* Define '__CONFIGURE_AP__' to start the CC3100 in AP mode */
//#define __CONFIGURE_AP__

#ifndef __CONFIGURE_AP__
#define SSID_NAME       "<ap-name>"        /* Open AP name to connect to */
#else /* __CONFIGURE_AP__ */
#define AP_SSID_NAME    "CC3100_DEMO_AP"   /* CC3100 SSID name in AP mode */
#endif /* __CONFIGURE_AP__ */

enum
{
    CONNECTED = 0x1,
    IP_ACQUIRED = 0x2
}e_Stauts;

UINT8 g_Status = 0;

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         none

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    switch(pWlanEvents->Event)
    {
      case SL_WLAN_CONNECT_EVENT:
          g_Status |= CONNECTED;
        break;
      case SL_WLAN_DISCONNECT_EVENT:
          g_Status &= ~(CONNECTED + IP_ACQUIRED);
        break;
      default:
        break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    switch( pNetAppEvent->Event )
    {
      case SL_NETAPP_IPV4_ACQUIRED:
          g_Status |= IP_ACQUIRED;
        break;

      default:
        break;
  }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this application */
}

#ifndef __CONFIGURE_AP__
/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    This code example assumes the AP doesn't use WIFI security.
    The function will return once we are connected and have acquired IP
    address

    \param[in]      None

    \return         None

    \note

    \warning        If the WLAN connection fails or we don't aquire an IP
                    address, We will be stuck in this function forever.
*/
static void WlanConnect()
{
    SlSecParams_t secParams;

    secParams.Key = "";
    secParams.KeyLen = 0;
    secParams.Type = SL_SEC_TYPE_OPEN;

    sl_WlanConnect(SSID_NAME, strlen(SSID_NAME), 0,&secParams,0);

    while (!(g_Status & IP_ACQUIRED ) || !(g_Status & CONNECTED))
    {
        _SlNonOsMainLoopTask();
    }
}
#endif /* __CONFIGURE_AP__ */


int main()
{
    INT16 mode;

#ifdef __CONFIGURE_AP__
    unsigned char SecType = 0;
#endif /* __CONFIGURE_AP__ */

    /* Stop WDT */
    stopWDT();

    /* Initialize the system clock of MCU */
    initClk();

    /* Initializing the CC3100 device */
    mode = sl_Start(0, 0, 0);

    if(mode == ROLE_AP)
    {
        /* wait for the IP acquire event, Not handling this event may cause
         * the SPI communication to fail */
        while (!(g_Status & IP_ACQUIRED))
        {
            _SlNonOsMainLoopTask();
        }

        g_Status &= ~IP_ACQUIRED;
    }

#ifndef __CONFIGURE_AP__
    /* if CC3100 is not in station mode, switch to station mode */
    if(mode != ROLE_STA)
    {
        sl_WlanSetMode(ROLE_STA);
        sl_Stop(0x00FF);

        /* Delay of 1 second */
        Delay(1000);
        sl_Start(0, 0, 0);
    }

    WlanConnect();
#else
    /*Configure CC3100 in AP mode */
    if(mode != ROLE_AP)
    {
        sl_WlanSetMode(ROLE_AP);
    }

    /* Configure the SSID and open security */
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SSID,
            strlen(AP_SSID_NAME), (unsigned char *)AP_SSID_NAME);

    SecType = SL_SEC_TYPE_OPEN;
    /* Configure the Security parameter in he AP mode */
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SECURITY_TYPE,
                                    1, (unsigned char *)&SecType);
    sl_Stop(0x00FF);

    /* Delay of 1 second */
    Delay(1000);
    sl_Start(0, 0, 0);

    /* wait for acquire IP event */
    while (!(g_Status & IP_ACQUIRED))
    {
        _SlNonOsMainLoopTask();
    }
#endif

    /* Stop the CC3100 device */
    sl_Stop(0xFF);
    return 0;
}

