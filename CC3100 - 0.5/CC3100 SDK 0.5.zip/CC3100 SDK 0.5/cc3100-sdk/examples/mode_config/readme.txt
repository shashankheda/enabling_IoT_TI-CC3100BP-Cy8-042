For information on this example refer to:
docs\examples\mode_config.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_Mode_Config_Application