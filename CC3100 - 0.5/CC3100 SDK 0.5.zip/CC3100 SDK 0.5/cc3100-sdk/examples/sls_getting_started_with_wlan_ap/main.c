/*
 * main.c - sample application to switch to AP mode and ping client
 *
 * Copyright (C) 2014 Texas Instruments Incorporated - http://www.ti.com/
 *
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
*/

#include <windows.h>
#include <stdio.h>

#include "simplelink.h"

#define SUCCESS         0
#define MAX_SSID_LEN    32
#define MAX_PASSKEY_LEN 32
#define BAUD_RATE       115200

#ifdef SL_IF_TYPE_UART
#define COMM_PORT_NUM 10
SlUartIfParams_t params;
#endif /* SL_IF_TYPE_UART */

typedef struct{
    UINT8 SSID[MAX_SSID_LEN];
    INT32 encryption;
    UINT8 password[MAX_PASSKEY_LEN];
}UserInfo;

#define CONNECTION_STATUS_BIT   0
#define IP_AQUIRED_STATUS_BIT   1
#define IP_LEASED_STATUS_BIT    2
#define PING_DONE_STATUS_BIT    3
typedef enum{
    CONNECTED = 0x01,
    IP_AQUIRED = 0x02,
    IP_LEASED = 0x04,
    PING_DONE = 0x08

}e_Status;
UINT8 g_Status = 0;
UINT32 g_PingPacketsRecv = 0;
UINT32 sta_IP = 0;

/*!
    \brief Read option fron the user

    \param[in]      none

    \return         int - user option value

    \note

    \warning
*/
int GetUserNum()
{
    INT32   flag = 0;
    INT8    input[20] = {'\0'};
    INT32   value = -1;

    while (!flag)
    {
        if(scanf_s("%s",input,sizeof(input)) != 0)
        {
            value = atoi(input);
            if (value > 0 && value < 5 )
            {
                flag = 1;
            }
            else
            {
                printf("Invalid entry. Please try again:\n");
            }
        }
    }

    return value;
}

/*!
    \brief Get the AP parameters from the user

    \param[in]      none

    \return         UserInfo - structure containg SSID, encryption type and
                    pass key of AP

    \note

    \warning
*/
UserInfo GetUserInput ()
{
    UserInfo UserFunction;
    INT32   eflag = -1;
    INT32   wepflag = -1;
    INT32   length = -1;

    printf("Please input the SSID name for AP mode: \n");
    scanf_s("%s",UserFunction.SSID,MAX_SSID_LEN);

    printf("Encryption Types for AP mode:\n");
    printf("1:  Open\n");
    printf("2:  WEP\n");
    printf("3:  WPA\n");
    printf("Please enter the corresponding number for the encryption type: \n");
    UserFunction.encryption = GetUserNum();

    if (UserFunction.encryption != 1)
    {
        printf ("Please enter the password for AP mode: \n");
        scanf_s("%s",UserFunction.password,MAX_PASSKEY_LEN);
    }

    return UserFunction;
}

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvents is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvents)
{
    /* Unused in this example */
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent)
{
    SlNetAppEvent_t *pNetApp = (SlNetAppEvent_t *)pNetAppEvent;

    switch( pNetApp->Event )
    {
        case SL_NETAPP_IPV4_ACQUIRED:
            g_Status |= IP_AQUIRED;
        break;

        case SL_NETAPP_IP_LEASED:
            sta_IP = pNetApp->EventData.ipLeased.ip_address;
            g_Status |= IP_LEASED;
        break;

        default:
        break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse)
{
    /* Unused in this example */
}

/*!
    \brief This function handles ping report events

    \param[in]      pPingReport holds the ping report statistics

    \return         None

    \note

    \warning
*/
void SimpleLinkPingReport(SlPingReport_t *pPingReport)
{
    g_Status |= PING_DONE;
    g_PingPacketsRecv = pPingReport->PacketsReceived;
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pServerEvent - Contains the relevant event information
    \param[in]      pServerResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void ConfigureAPmode(UserInfo UserParams)
{
    UINT8 val = SL_SEC_TYPE_OPEN;

    /* Configure the SSID of the CC3100 */
    sl_WlanSet(SL_WLAN_CFG_AP_ID, WLAN_AP_OPT_SSID,
               strlen(UserParams.SSID),
               UserParams.SSID);

    /* Configure the Security parameter in the AP mode */
    switch(UserParams.encryption)
    {
        case 1:
        {
            val = SL_SEC_TYPE_OPEN;
            sl_WlanSet(SL_WLAN_CFG_AP_ID,
                       WLAN_AP_OPT_SECURITY_TYPE,
                       1, (unsigned char *)&val);
        }
        break;

        case 2:
        {
            val = SL_SEC_TYPE_WEP;
            sl_WlanSet(SL_WLAN_CFG_AP_ID,
                       WLAN_AP_OPT_SECURITY_TYPE,
                       1, (unsigned char *)&val);
            sl_WlanSet(SL_WLAN_CFG_AP_ID,
                       WLAN_AP_OPT_PASSWORD,
                       strlen(UserParams.password),
                       (unsigned char *)UserParams.password);
        }
        break;

        case 3:
        {
            val = SL_SEC_TYPE_WPA;
            sl_WlanSet(SL_WLAN_CFG_AP_ID,
                       WLAN_AP_OPT_SECURITY_TYPE,
                       1, (unsigned char *)&val);
            sl_WlanSet(SL_WLAN_CFG_AP_ID,
                       WLAN_AP_OPT_PASSWORD,
                       strlen(UserParams.password),
                       (unsigned char *)UserParams.password);
        }
        break;
    }
}

int main(void)
{
    SlPingStartCommand_t PingParams;
    SlPingReport_t Report;
    UserInfo User;

    UINT32 IpAddr = 0;
    UINT32 Mask = 0;
    UINT32 Gw = 0;
    UINT32 Dns = 0;
    UINT8  IsDhcp = 0;

    INT32 Status = -1;
    INT32 mode = ROLE_STA;
    INT8 *pConfig = 0;

#ifdef SL_IF_TYPE_UART
    params.BaudRate = BAUD_RATE;
    params.FlowControlEnable = 1;
    params.CommPort = COMM_PORT_NUM;

    pConfig = (char *)&params;
#endif /* SL_IF_TYPE_UART */

    /*This line is for Eclipse CDT only due to a known bug in console buffering
     * See https://bugs.eclipse.org/bugs/show_bug.cgi?id=173732 */
    setvbuf(stdout, NULL, _IONBF, 0);

    printf("\nGetting Started with AP Example:\n\n");

    /* Initializing the CC3100 device */
    sl_Start(0, pConfig, 0);
    if (ROLE_AP == mode)
    {
        /* If some other application has configured the device in AP mode,
           then we need to wait for this event */
        while(0 == (g_Status & IP_AQUIRED))
            ;
    }
    else
    {
        /* Configure CC3100 to start in AP mode */
        sl_WlanSetMode(ROLE_AP);
    }

    User = GetUserInput();
    ConfigureAPmode(User);
    printf("Configured CC3100 in AP mode, Restarting CC3100 in AP mode\n");

    /* Restart the CC3100 */
    sl_Stop(0x00FF);

    g_Status &= ~(1 << IP_AQUIRED_STATUS_BIT | 1 << IP_LEASED_STATUS_BIT);

    sl_Start(0, pConfig, 0);
    printf("Connect client to AP %s\n",User.SSID);

    while((0 == (g_Status & IP_LEASED)) || (0 == (g_Status & IP_AQUIRED)))
        ;

    printf("Client connected \n");

     /* Set the ping parameters */
    PingParams.PingIntervalTime = 1000;
    PingParams.PingSize = 20;
    PingParams.PingRequestTimeout = 3000;
    PingParams.TotalNumberOfAttempts = 3;
    PingParams.Flags = 0;
    PingParams.Ip = sta_IP; /* Fill the station IP address connected to CC3100 */

    /* Ping client connected to CC3100 */
    printf("Start pinging to client\n");
    sl_NetAppPingStart((SlPingStartCommand_t*)&PingParams, SL_AF_INET,
                       (SlPingReport_t*)&Report, SimpleLinkPingReport);

    while(0 == (g_Status & PING_DONE))
        ;

    if (g_PingPacketsRecv)
    {
        /* Ping successful */
        printf("Ping successful\n");
        system("PAUSE");
        return 0;
    }
    else
    {
        /* Problem with Pinging to client */
        printf("Problem with pinging to client\n");
        system("PAUSE");
        return -1;
    }
}
