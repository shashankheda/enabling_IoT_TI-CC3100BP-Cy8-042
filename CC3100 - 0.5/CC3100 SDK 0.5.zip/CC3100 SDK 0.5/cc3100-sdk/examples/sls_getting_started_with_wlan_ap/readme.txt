For information on this example refer to:
docs\examples\sls_getting_started_with_wlan_ap.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_SLS_Getting_started_with_WLAN_AP