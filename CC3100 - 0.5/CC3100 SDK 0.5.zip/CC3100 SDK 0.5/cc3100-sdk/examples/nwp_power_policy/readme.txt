For information on this example refer to:
docs\examples\nwp_power_policy.pdf
or
http://processors.wiki.ti.com/index.php/CC31xx_NWP_Power_Policies