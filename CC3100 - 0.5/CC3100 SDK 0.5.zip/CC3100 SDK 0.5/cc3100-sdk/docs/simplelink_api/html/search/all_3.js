var searchData=
[
  ['event_5fdropped_5fdevice_5fasync_5fgeneral_5ferror',['EVENT_DROPPED_DEVICE_ASYNC_GENERAL_ERROR',['../group__device.html#ga3186925e3acec312e7d74733b8b64a87',1,'device.h']]]
];
