var searchData=
[
  ['parentfilterid',['ParentFilterID',['../struct_slrx_filter_trigger__t.html#a58947c0d33b44b6adf9e52be48442da0',1,'SlrxFilterTrigger_t']]]
];
