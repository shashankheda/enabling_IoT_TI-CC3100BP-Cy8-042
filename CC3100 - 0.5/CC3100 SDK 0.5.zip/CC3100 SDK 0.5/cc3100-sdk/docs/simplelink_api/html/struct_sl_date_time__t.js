var struct_sl_date_time__t =
[
    [ "reserved", "struct_sl_date_time__t.html#a68da162bd70f72b3cc56f4cc18d3c37a", null ],
    [ "sl_tm_day", "struct_sl_date_time__t.html#adf66d561b1798f6c6f252ae829b9e935", null ],
    [ "sl_tm_hour", "struct_sl_date_time__t.html#a486672fde9b359f385cb92f908a84f55", null ],
    [ "sl_tm_min", "struct_sl_date_time__t.html#a022d7c23200ef03f389766f07913ab54", null ],
    [ "sl_tm_mon", "struct_sl_date_time__t.html#aa35041623ea37090da1ceaa925a4c800", null ],
    [ "sl_tm_sec", "struct_sl_date_time__t.html#a98e8f643beed45e6f9721aabdbc9524d", null ],
    [ "sl_tm_week_day", "struct_sl_date_time__t.html#af26a8a3fb9ece0a3e818a43839b1d858", null ],
    [ "sl_tm_year", "struct_sl_date_time__t.html#a84fa81bf1c016ad21e7e7f283498a116", null ],
    [ "sl_tm_year_day", "struct_sl_date_time__t.html#a63a06df8a302f834cbce99865a91b97d", null ]
];