var modules =
[
    [ "Porting - User Include Files", "group__porting__user__include.html", null ],
    [ "Porting - Capabilities Set", "group__porting__capabilities.html", "group__porting__capabilities" ],
    [ "Porting - Device Enable/Disable", "group__porting__enable__device.html", "group__porting__enable__device" ],
    [ "Porting - Communication Interface", "group__porting__interface.html", "group__porting__interface" ],
    [ "Porting - Memory Management", "group__porting__mem__mgm.html", null ],
    [ "Porting - Operating System", "group__porting__os.html", "group__porting__os" ],
    [ "Porting - Event Handlers", "group__porting__events.html", "group__porting__events" ],
    [ "Device", "group__device.html", "group__device" ],
    [ "Fs", "group__fs.html", "group__fs" ],
    [ "Netapp", "group__netapp.html", "group__netapp" ],
    [ "Netcfg", "group__netcfg.html", "group__netcfg" ],
    [ "Socket", "group__socket.html", "group__socket" ],
    [ "Wlan", "group__wlan.html", "group__wlan" ]
];