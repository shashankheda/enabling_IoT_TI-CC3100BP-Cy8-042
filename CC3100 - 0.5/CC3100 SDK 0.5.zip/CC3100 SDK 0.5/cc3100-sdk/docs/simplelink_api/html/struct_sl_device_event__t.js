var struct_sl_device_event__t =
[
    [ "Event", "struct_sl_device_event__t.html#a82b85c0f983cb4be38dde9fba5968f46", null ],
    [ "EventData", "struct_sl_device_event__t.html#ad21f94439f7492df8063ac8e85aaad01", null ]
];