var group__porting__enable__device =
[
    [ "sl_DeviceDisable", "group__porting__enable__device.html#gacca1eb461c75328c51f1f31c68211f2f", null ],
    [ "sl_DeviceEnable", "group__porting__enable__device.html#ga8bbed8fdfdf8935ac0dd9a05b04d30ca", null ]
];