var struct_sl_ping_report__t =
[
    [ "AvgRoundTime", "struct_sl_ping_report__t.html#a9b0225877c0d569203f39336196ab21f", null ],
    [ "MaxRoundTime", "struct_sl_ping_report__t.html#ac3342c7087e20cd1e2a916df06994075", null ],
    [ "MinRoundTime", "struct_sl_ping_report__t.html#ac60d1067fed4458de974cb46f5bcdf40", null ],
    [ "PacketsReceived", "struct_sl_ping_report__t.html#ae099b0896b32e8462914a0764ad0d7c2", null ],
    [ "PacketsSent", "struct_sl_ping_report__t.html#a81dcc30880d7c76591ffe781b977641b", null ],
    [ "TestTime", "struct_sl_ping_report__t.html#a6565cb7d96c43c4271bd8f59bb19476a", null ]
];