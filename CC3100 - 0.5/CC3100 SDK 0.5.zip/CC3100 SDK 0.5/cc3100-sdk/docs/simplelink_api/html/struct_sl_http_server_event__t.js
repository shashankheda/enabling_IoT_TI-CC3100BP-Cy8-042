var struct_sl_http_server_event__t =
[
    [ "Event", "struct_sl_http_server_event__t.html#a82b85c0f983cb4be38dde9fba5968f46", null ],
    [ "EventData", "struct_sl_http_server_event__t.html#aea6d012a43dcb8ded6b90686ceaef0f7", null ]
];