var struct_sl_sock_addr_in__t =
[
    [ "sin_addr", "struct_sl_sock_addr_in__t.html#ac202531c3497bcb9d64a83028f036d81", null ],
    [ "sin_family", "struct_sl_sock_addr_in__t.html#ab94314390938f112761a80e5fd1582fc", null ],
    [ "sin_port", "struct_sl_sock_addr_in__t.html#a0eae6616c263e76ee1c4a13dfbcd42a5", null ],
    [ "sin_zero", "struct_sl_sock_addr_in__t.html#a019cb683bfdac71a46a437c71a792c99", null ]
];