var struct_sl___wlan_network_entry__t =
[
    [ "bssid", "group__wlan.html#ga6a3e9db687574fe89cdc84abd2fd2645", null ],
    [ "reserved", "group__wlan.html#ga7a0c313f9a023fb215e2106a6a4dac75", null ],
    [ "rssi", "group__wlan.html#ga0e8c2d628a681a89f8924f264401989a", null ],
    [ "sec_type", "group__wlan.html#ga695e3013977198a85eaaa280d6e0d2d2", null ],
    [ "ssid", "group__wlan.html#ga31cc200715c95a80075e225cabb62911", null ],
    [ "ssid_len", "group__wlan.html#ga340f18f235799c8c8b592c782ef1c079", null ]
];