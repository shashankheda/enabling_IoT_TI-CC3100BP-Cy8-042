var struct__sl_http_server_data__t =
[
    [ "name_len", "struct__sl_http_server_data__t.html#a0b3926f502b60c04240e00fea8acf532", null ],
    [ "token_name", "struct__sl_http_server_data__t.html#ace7f948c3074e87fb83dc2dfd0b671ab", null ],
    [ "token_value", "struct__sl_http_server_data__t.html#ad7b8f212b71ffd3d1b97fde21b6e8dc6", null ],
    [ "value_len", "struct__sl_http_server_data__t.html#ad58a1c8e5bf21ce9e3828aa8eb2ce18d", null ]
];