var struct_sl_timeval__t =
[
    [ "tv_sec", "struct_sl_timeval__t.html#a8f5aa475627ac4ba971fce4b1a79b673", null ],
    [ "tv_usec", "struct_sl_timeval__t.html#a1ad5c78770a3d6fd50eae96b9096830b", null ]
];