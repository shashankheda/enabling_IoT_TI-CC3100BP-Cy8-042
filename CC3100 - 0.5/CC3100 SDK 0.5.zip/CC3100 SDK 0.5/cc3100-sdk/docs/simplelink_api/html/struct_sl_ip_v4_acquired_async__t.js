var struct_sl_ip_v4_acquired_async__t =
[
    [ "dns", "struct_sl_ip_v4_acquired_async__t.html#ae5e4af58a91bf1bfb0c2e28fcfb7cc9a", null ],
    [ "gateway", "struct_sl_ip_v4_acquired_async__t.html#a338aa4fd929c5dce1a97f6cd9e1edff2", null ],
    [ "ip", "struct_sl_ip_v4_acquired_async__t.html#ad9612dd117f6968a3721342e068375c4", null ]
];