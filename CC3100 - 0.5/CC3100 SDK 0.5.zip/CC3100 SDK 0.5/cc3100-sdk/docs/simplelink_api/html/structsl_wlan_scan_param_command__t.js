var structsl_wlan_scan_param_command__t =
[
    [ "G_Channels_mask", "group__wlan.html#gaa125a7dc938f0ba1674fc2f52a40b4a3", null ],
    [ "rssiThershold", "group__wlan.html#ga2d8588fba0893b9590e3c4a1cf40735f", null ]
];