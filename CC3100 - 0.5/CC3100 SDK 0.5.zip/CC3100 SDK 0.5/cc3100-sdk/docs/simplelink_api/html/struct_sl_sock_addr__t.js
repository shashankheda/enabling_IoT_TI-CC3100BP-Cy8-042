var struct_sl_sock_addr__t =
[
    [ "sa_data", "struct_sl_sock_addr__t.html#ab19cd6b9a89330d1e0ac55da8f407da6", null ],
    [ "sa_family", "struct_sl_sock_addr__t.html#a875db191829872142a885a463810ff29", null ]
];