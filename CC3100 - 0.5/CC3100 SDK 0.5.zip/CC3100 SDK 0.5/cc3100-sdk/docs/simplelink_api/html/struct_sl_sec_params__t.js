var struct_sl_sec_params__t =
[
    [ "Key", "group__wlan.html#ga08ad9767ce01da65879eedff503dbfff", null ],
    [ "KeyLen", "group__wlan.html#gaeb6f1a41fb682dc06cfdc1d0c1bef18f", null ],
    [ "Type", "group__wlan.html#gaa8450776ab620f8870aaee14ac1747fe", null ]
];