var struct_sl_sock_secure_method =
[
    [ "secureMethod", "struct_sl_sock_secure_method.html#ac93ce2e8398137141a30b5bf7c419f73", null ]
];