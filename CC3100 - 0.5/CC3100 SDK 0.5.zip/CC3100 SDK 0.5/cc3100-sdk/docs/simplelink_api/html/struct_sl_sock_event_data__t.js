var struct_sl_sock_event_data__t =
[
    [ "sd", "struct_sl_sock_event_data__t.html#a75be96dd3dc9ae7c1825a9f283d871a7", null ],
    [ "status", "struct_sl_sock_event_data__t.html#a2daf25ceaaa514373942974922f2cba9", null ]
];