var struct__sl_http_server_post_data__t =
[
    [ "action", "struct__sl_http_server_post_data__t.html#a76122764e78b080056125b9ef28ada7b", null ],
    [ "token_name", "struct__sl_http_server_post_data__t.html#ac32e60a343288e97e368ae665adf7442", null ],
    [ "token_value", "struct__sl_http_server_post_data__t.html#ac17cbf485a7c72aa811cfda94d8649c6", null ]
];