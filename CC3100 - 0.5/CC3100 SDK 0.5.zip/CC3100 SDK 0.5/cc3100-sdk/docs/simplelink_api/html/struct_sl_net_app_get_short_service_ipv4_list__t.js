var struct_sl_net_app_get_short_service_ipv4_list__t =
[
    [ "Reserved", "struct_sl_net_app_get_short_service_ipv4_list__t.html#af5b485617755a57ee57707d690528513", null ],
    [ "service_ipv4", "struct_sl_net_app_get_short_service_ipv4_list__t.html#ae2948db6c9a1669e9ffd9b1d7b58fe0f", null ],
    [ "service_port", "struct_sl_net_app_get_short_service_ipv4_list__t.html#ac8cd510606b6132086335825ff7fe917", null ]
];