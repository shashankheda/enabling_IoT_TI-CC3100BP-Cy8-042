var struct_sl_get_rx_stat_response__t =
[
    [ "AvarageDataCtrlRssi", "group__wlan.html#gaefd98349f088e3d291d804d6ba0b3d48", null ],
    [ "AvarageMgMntRssi", "group__wlan.html#ga2e5e0ffb3b3d82d50c2ada5eabadda1d", null ],
    [ "GetTimeStamp", "group__wlan.html#ga006d3719d624e11eaa3cd1d3322f75e9", null ],
    [ "RateHistogram", "group__wlan.html#ga0a6ca65f911e49a8783217077acd1983", null ],
    [ "ReceivedFcsErrorPacketsNumber", "group__wlan.html#ga038e3b24286400fa0cd6c3a8b140f4b5", null ],
    [ "ReceivedPlcpErrorPacketsNumber", "group__wlan.html#ga95b8db41b7186377db1ba339fb82575a", null ],
    [ "ReceivedValidPacketsNumber", "group__wlan.html#ga91c1cfc333fa258db90d65de266b357e", null ],
    [ "RssiHistogram", "group__wlan.html#ga2fb3a6dd9e0b2c60a5fa3ca36b7ce291", null ],
    [ "StartTimeStamp", "group__wlan.html#gae04f4c694033e567028a01bd71ddd032", null ]
];