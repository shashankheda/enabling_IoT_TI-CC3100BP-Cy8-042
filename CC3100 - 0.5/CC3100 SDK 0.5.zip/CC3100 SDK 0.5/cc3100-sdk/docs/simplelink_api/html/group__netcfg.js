var group__netcfg =
[
    [ "_NetCfgIpV4Args_t", "struct___net_cfg_ip_v4_args__t.html", [
      [ "ipV4", "struct___net_cfg_ip_v4_args__t.html#a1ba493795d9428020a86b4e54ed4efcf", null ],
      [ "ipV4DnsServer", "struct___net_cfg_ip_v4_args__t.html#aa4c89c928180638aa36d08c89eef8afa", null ],
      [ "ipV4Gateway", "struct___net_cfg_ip_v4_args__t.html#a736ade97509fd3b361601cb14de1cb13", null ],
      [ "ipV4Mask", "struct___net_cfg_ip_v4_args__t.html#a8d81d6b444d53f3e204fbe6183d2f0f7", null ]
    ] ],
    [ "sl_NetCfgGet", "group__netcfg.html#gac0a488210314335881a602f766498484", null ],
    [ "sl_NetCfgSet", "group__netcfg.html#ga052c1318cb5e8a05a6259559a2f05554", null ]
];