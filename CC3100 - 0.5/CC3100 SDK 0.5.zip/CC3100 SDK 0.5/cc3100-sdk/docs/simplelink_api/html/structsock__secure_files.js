var structsock__secure_files =
[
    [ "secureFiles", "structsock__secure_files.html#a7449a3f04fb3aef98f62e37eb2a6c225", null ]
];