var structsl_wlan_conn_failure_async_response__t =
[
    [ "padding", "group__wlan.html#ga201aa5283495b87fc8832e9baa63aad5", null ],
    [ "status", "group__wlan.html#ga724f8cf1b8ff3d96c3a9cbcd2a6957a6", null ]
];