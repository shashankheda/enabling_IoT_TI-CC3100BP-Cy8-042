var struct_sl_fs_file_info__t =
[
    [ "AllocatedLen", "struct_sl_fs_file_info__t.html#a5fb5289c5ef2b9675a8b471128f755ef", null ],
    [ "FileLen", "struct_sl_fs_file_info__t.html#af62a565eb13e52db2eefb2f80797c18f", null ],
    [ "flags", "struct_sl_fs_file_info__t.html#a1cbb17ede73ea044a04a129bf4d86976", null ],
    [ "Token", "struct_sl_fs_file_info__t.html#a9e6b6646d5c146c93afa8ca71cc4e59f", null ]
];