var struct_sl_get_sec_params_ext__t =
[
    [ "AnonUser", "group__wlan.html#ga018057b0083c446b838740d48da05d2d", null ],
    [ "AnonUserLen", "group__wlan.html#ga46595900758e5eea2e6dcb396f65f7e8", null ],
    [ "CertIndex", "group__wlan.html#gac7dd5ef84298a6583c14cf826cd2289f", null ],
    [ "EapMethod", "group__wlan.html#gadec626c3ddd6f52858e7c2ff3fe56cb6", null ],
    [ "User", "group__wlan.html#ga1f62c2d9596765904365ac1626e95788", null ],
    [ "UserLen", "group__wlan.html#ga363b9a9d0656d0c97ff735422e0ff1c0", null ]
];