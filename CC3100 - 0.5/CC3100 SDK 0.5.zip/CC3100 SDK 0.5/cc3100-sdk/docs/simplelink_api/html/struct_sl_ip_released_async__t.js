var struct_sl_ip_released_async__t =
[
    [ "ip_address", "struct_sl_ip_released_async__t.html#ad859d6980f1584cd010dece0fd7c8bf8", null ],
    [ "mac", "struct_sl_ip_released_async__t.html#a0fc1ebcb690ec8426f156a7fd33e0913", null ],
    [ "reason", "struct_sl_ip_released_async__t.html#ad8b4d1cb6121fc7c65cdfaa95649ee21", null ]
];