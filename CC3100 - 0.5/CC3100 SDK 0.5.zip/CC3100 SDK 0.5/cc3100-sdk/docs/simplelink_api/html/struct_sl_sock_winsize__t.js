var struct_sl_sock_winsize__t =
[
    [ "Winsize", "struct_sl_sock_winsize__t.html#a5d1fdee2bc000e3dd3e33c2135c08f4a", null ]
];